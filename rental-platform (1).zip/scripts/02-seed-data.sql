-- Insert sample users
INSERT INTO users (id, email, name, phone, user_type, verified) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'maria.gonzalez@email.com', 'María González', '+57 300 123 4567', 'OWNER', true),
('550e8400-e29b-41d4-a716-446655440002', 'carlos.mendoza@email.com', 'Carlos Mendoza', '+57 301 234 5678', 'TENANT', true),
('550e8400-e29b-41d4-a716-446655440003', 'ana.lopez@email.com', 'Ana Sofía López', '+57 302 345 6789', 'TENANT', true),
('550e8400-e29b-41d4-a716-446655440004', 'luis.herrera@email.com', 'Luis Herrera', '+57 303 456 7890', 'OWNER', true),
('550e8400-e29b-41d4-a716-446655440005', 'inmobiliaria@remax.com', 'RE/MAX Colombia', '+57 304 567 8901', 'AGENCY', true);

-- Insert sample properties
INSERT INTO properties (
  id, owner_id, title, description, property_type, price, deposit, admin_fee,
  address, city, neighborhood, bedrooms, bathrooms, area, amenities, features, images, available_from
) VALUES
(
  '660e8400-e29b-41d4-a716-446655440001',
  '550e8400-e29b-41d4-a716-446655440001',
  'Apartamento Moderno en Chapinero',
  'Hermoso apartamento completamente amoblado con vista panorámica de la ciudad. Ubicado en una de las zonas más exclusivas de Bogotá, cuenta con acabados de primera calidad y acceso a todas las comodidades urbanas.',
  'Apartamento',
  1200000,
  1200000,
  150000,
  'Carrera 13 #85-32',
  'Bogotá',
  'Chapinero',
  2,
  2.0,
  80,
  ARRAY['WiFi', 'Aire Acondicionado', 'Parqueadero', 'Gimnasio', 'Seguridad 24/7'],
  ARRAY['Amoblado', 'Cocina Integral', 'Balcón', 'Vista Panorámica'],
  ARRAY['/placeholder.svg?height=400&width=600'],
  '2025-02-01'
),
(
  '660e8400-e29b-41d4-a716-446655440002',
  '550e8400-e29b-41d4-a716-446655440004',
  'Casa Familiar en El Poblado',
  'Espaciosa casa con jardín privado y garaje. Perfect para familias que buscan tranquilidad y comodidad en una de las mejores zonas de Medellín.',
  'Casa',
  1800000,
  1800000,
  200000,
  'Carrera 43A #12-45',
  'Medellín',
  'El Poblado',
  3,
  3.0,
  120,
  ARRAY['WiFi', 'Jardín', 'Parqueadero', 'Piscina', 'Seguridad 24/7'],
  ARRAY['Jardín Privado', 'Garaje', 'Chimenea', 'Terraza'],
  ARRAY['/placeholder.svg?height=400&width=600'],
  '2025-02-15'
),
(
  '660e8400-e29b-41d4-a716-446655440003',
  '550e8400-e29b-41d4-a716-446655440001',
  'Estudio en Zona Rosa',
  'Perfecto para profesionales jóvenes. Ubicación privilegiada cerca de restaurantes, bares y transporte público.',
  'Estudio',
  800000,
  800000,
  100000,
  'Calle 82 #12-34',
  'Bogotá',
  'Zona Rosa',
  1,
  1.0,
  45,
  ARRAY['WiFi', 'Aire Acondicionado', 'Gimnasio'],
  ARRAY['Amoblado', 'Cocina Integral', 'Iluminación Natural'],
  ARRAY['/placeholder.svg?height=400&width=600'],
  '2025-01-20'
),
(
  '660e8400-e29b-41d4-a716-446655440004',
  '550e8400-e29b-41d4-a716-446655440004',
  'Apartamento con Balcón en Laureles',
  'Excelente ubicación cerca del metro. Apartamento luminoso con balcón y vista a la ciudad.',
  'Apartamento',
  950000,
  950000,
  120000,
  'Carrera 70 #45-67',
  'Medellín',
  'Laureles',
  2,
  1.0,
  65,
  ARRAY['WiFi', 'Balcón', 'Cerca Metro'],
  ARRAY['Balcón', 'Vista Ciudad', 'Iluminación Natural'],
  ARRAY['/placeholder.svg?height=400&width=600'],
  '2025-03-01'
);

-- Insert sample property views
INSERT INTO property_views (property_id, user_id) VALUES
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002'),
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440003'),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002'),
('660e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003');

-- Insert sample applications
INSERT INTO applications (property_id, tenant_id, status, message) VALUES
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', 'approved', 'Estoy muy interesado en esta propiedad. Soy profesional en sistemas con ingresos estables.'),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 'pending', 'Me encanta la casa, especialmente el jardín. Tengo una familia pequeña y buscamos tranquilidad.');

-- Insert sample favorites
INSERT INTO favorites (user_id, property_id) VALUES
('550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440001'),
('550e8400-e29b-41d4-a716-446655440002', '660e8400-e29b-41d4-a716-446655440003'),
('550e8400-e29b-41d4-a716-446655440003', '660e8400-e29b-41d4-a716-446655440002');

-- Insert sample reviews
INSERT INTO reviews (property_id, reviewer_id, rating, comment) VALUES
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', 5, 'Excelente apartamento, muy bien ubicado y la propietaria es muy amable. Todo tal como se describe en la publicación.'),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', 4, 'Muy buen lugar, cómodo y seguro. La vista es espectacular. Recomendado 100%.');

-- Insert sample contracts
INSERT INTO contracts (
  property_id, tenant_id, owner_id, start_date, end_date, 
  monthly_rent, deposit, status
) VALUES
(
  '660e8400-e29b-41d4-a716-446655440001',
  '550e8400-e29b-41d4-a716-446655440002',
  '550e8400-e29b-41d4-a716-446655440001',
  '2025-02-01',
  '2026-02-01',
  1200000,
  1200000,
  'active'
);

-- Insert sample payments
INSERT INTO payments (contract_id, amount, payment_type, payment_method, status, due_date, paid_at) VALUES
(
  (SELECT id FROM contracts LIMIT 1),
  1200000,
  'rent',
  'PSE',
  'completed',
  '2025-02-01',
  '2025-01-30 10:30:00'
);
