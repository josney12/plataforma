-- Agregar tablas para funcionalidades sociales

-- Tabla de likes para propiedades
CREATE TABLE IF NOT EXISTS property_likes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    property_id UUID NOT NULL REFERENCES properties(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, property_id)
);

-- Tabla de seguidores para inmobiliarias/agencias
CREATE TABLE IF NOT EXISTS agency_followers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follower_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    agency_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(follower_id, agency_id),
    CHECK (follower_id != agency_id)
);

-- Tabla de posts/publicaciones sociales
CREATE TABLE IF NOT EXISTS social_posts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    property_id UUID REFERENCES properties(id) ON DELETE CASCADE,
    content TEXT,
    images TEXT[],
    post_type VARCHAR(50) DEFAULT 'property' CHECK (post_type IN ('property', 'announcement', 'tip', 'success_story')),
    likes_count INTEGER DEFAULT 0,
    comments_count INTEGER DEFAULT 0,
    shares_count INTEGER DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de comentarios en posts
CREATE TABLE IF NOT EXISTS post_comments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Tabla de likes en posts
CREATE TABLE IF NOT EXISTS post_likes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    post_id UUID NOT NULL REFERENCES social_posts(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(post_id, user_id)
);

-- Índices para optimización
CREATE INDEX IF NOT EXISTS idx_property_likes_property_id ON property_likes(property_id);
CREATE INDEX IF NOT EXISTS idx_property_likes_user_id ON property_likes(user_id);
CREATE INDEX IF NOT EXISTS idx_agency_followers_agency_id ON agency_followers(agency_id);
CREATE INDEX IF NOT EXISTS idx_agency_followers_follower_id ON agency_followers(follower_id);
CREATE INDEX IF NOT EXISTS idx_social_posts_user_id ON social_posts(user_id);
CREATE INDEX IF NOT EXISTS idx_social_posts_created_at ON social_posts(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_post_comments_post_id ON post_comments(post_id);
CREATE INDEX IF NOT EXISTS idx_post_likes_post_id ON post_likes(post_id);

-- Función para obtener estadísticas de agencia
CREATE OR REPLACE FUNCTION get_agency_stats(agency_user_id UUID)
RETURNS TABLE (
    total_properties BIGINT,
    active_properties BIGINT,
    followers_count BIGINT,
    total_likes BIGINT,
    avg_rating NUMERIC,
    total_reviews BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(p.id) as total_properties,
        COUNT(p.id) FILTER (WHERE p.available = true) as active_properties,
        COUNT(af.id) as followers_count,
        COUNT(pl.id) as total_likes,
        COALESCE(AVG(r.rating), 0) as avg_rating,
        COUNT(r.id) as total_reviews
    FROM users u
    LEFT JOIN properties p ON u.id = p.owner_id
    LEFT JOIN agency_followers af ON u.id = af.agency_id
    LEFT JOIN property_likes pl ON p.id = pl.property_id
    LEFT JOIN reviews r ON p.id = r.property_id
    WHERE u.id = agency_user_id
    GROUP BY u.id;
END;
$$ LANGUAGE plpgsql;

-- Función para obtener feed social
CREATE OR REPLACE FUNCTION get_social_feed(user_id_param UUID DEFAULT NULL, limit_param INTEGER DEFAULT 20, offset_param INTEGER DEFAULT 0)
RETURNS TABLE (
    post_id UUID,
    user_id UUID,
    user_name VARCHAR,
    user_avatar TEXT,
    user_type VARCHAR,
    user_verified BOOLEAN,
    property_id UUID,
    property_title VARCHAR,
    property_price INTEGER,
    property_city VARCHAR,
    property_images TEXT[],
    content TEXT,
    post_images TEXT[],
    post_type VARCHAR,
    likes_count INTEGER,
    comments_count INTEGER,
    shares_count INTEGER,
    created_at TIMESTAMP WITH TIME ZONE,
    user_liked BOOLEAN,
    user_following BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        sp.id as post_id,
        sp.user_id,
        u.name as user_name,
        u.avatar_url as user_avatar,
        u.user_type,
        u.verified as user_verified,
        sp.property_id,
        p.title as property_title,
        p.price as property_price,
        p.city as property_city,
        p.images as property_images,
        sp.content,
        sp.images as post_images,
        sp.post_type,
        sp.likes_count,
        sp.comments_count,
        sp.shares_count,
        sp.created_at,
        CASE 
            WHEN user_id_param IS NOT NULL THEN EXISTS(SELECT 1 FROM post_likes pl WHERE pl.post_id = sp.id AND pl.user_id = user_id_param)
            ELSE false
        END as user_liked,
        CASE 
            WHEN user_id_param IS NOT NULL AND u.user_type IN ('AGENCY', 'OWNER') THEN EXISTS(SELECT 1 FROM agency_followers af WHERE af.agency_id = u.id AND af.follower_id = user_id_param)
            ELSE false
        END as user_following
    FROM social_posts sp
    JOIN users u ON sp.user_id = u.id
    LEFT JOIN properties p ON sp.property_id = p.id
    ORDER BY sp.created_at DESC
    LIMIT limit_param OFFSET offset_param;
END;
$$ LANGUAGE plpgsql;

-- Triggers para actualizar contadores
CREATE OR REPLACE FUNCTION update_post_likes_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE social_posts SET likes_count = likes_count + 1 WHERE id = NEW.post_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE social_posts SET likes_count = likes_count - 1 WHERE id = OLD.post_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION update_post_comments_count()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE social_posts SET comments_count = comments_count + 1 WHERE id = NEW.post_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE social_posts SET comments_count = comments_count - 1 WHERE id = OLD.post_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Crear triggers
DROP TRIGGER IF EXISTS trigger_update_post_likes_count ON post_likes;
CREATE TRIGGER trigger_update_post_likes_count
    AFTER INSERT OR DELETE ON post_likes
    FOR EACH ROW EXECUTE FUNCTION update_post_likes_count();

DROP TRIGGER IF EXISTS trigger_update_post_comments_count ON post_comments;
CREATE TRIGGER trigger_update_post_comments_count
    AFTER INSERT OR DELETE ON post_comments
    FOR EACH ROW EXECUTE FUNCTION update_post_comments_count();

-- Crear posts automáticos cuando se crea una propiedad
CREATE OR REPLACE FUNCTION create_property_post()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO social_posts (user_id, property_id, content, post_type)
    VALUES (
        NEW.owner_id,
        NEW.id,
        '¡Nueva propiedad disponible! ' || NEW.title || ' en ' || NEW.city,
        'property'
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_create_property_post ON properties;
CREATE TRIGGER trigger_create_property_post
    AFTER INSERT ON properties
    FOR EACH ROW EXECUTE FUNCTION create_property_post();
