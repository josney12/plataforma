-- Create verification tables
CREATE TABLE IF NOT EXISTS verification_steps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    step_id VARCHAR(50) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in-progress', 'completed', 'rejected')),
    step_order INTEGER NOT NULL,
    rejection_reason TEXT,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id, step_id)
);

CREATE TABLE IF NOT EXISTS verification_documents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    step_id VARCHAR(50) NOT NULL,
    document_type VARCHAR(100) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_url TEXT,
    file_size INTEGER,
    mime_type VARCHAR(100),
    status VARCHAR(20) DEFAULT 'uploaded' CHECK (status IN ('uploaded', 'processing', 'verified', 'rejected')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS user_references (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255) NOT NULL,
    relation VARCHAR(100) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    verification_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS background_checks (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    cedula VARCHAR(20) NOT NULL,
    authorized BOOLEAN DEFAULT FALSE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
    score INTEGER,
    report_data JSONB,
    checked_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS income_verification (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    income_type VARCHAR(100) NOT NULL,
    monthly_income DECIMAL(12,2),
    verified BOOLEAN DEFAULT FALSE,
    verification_date TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_verification_steps_user_id ON verification_steps(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_documents_user_id ON verification_documents(user_id);
CREATE INDEX IF NOT EXISTS idx_user_references_user_id ON user_references(user_id);
CREATE INDEX IF NOT EXISTS idx_background_checks_user_id ON background_checks(user_id);
CREATE INDEX IF NOT EXISTS idx_income_verification_user_id ON income_verification(user_id);

-- Function to get verification progress
CREATE OR REPLACE FUNCTION get_verification_progress(p_user_id UUID)
RETURNS TABLE (
    total_steps INTEGER,
    completed_steps INTEGER,
    in_progress_steps INTEGER,
    pending_steps INTEGER,
    progress_percentage INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        COUNT(*)::INTEGER as total_steps,
        COUNT(CASE WHEN status = 'completed' THEN 1 END)::INTEGER as completed_steps,
        COUNT(CASE WHEN status = 'in-progress' THEN 1 END)::INTEGER as in_progress_steps,
        COUNT(CASE WHEN status = 'pending' THEN 1 END)::INTEGER as pending_steps,
        ROUND((COUNT(CASE WHEN status = 'completed' THEN 1 END)::DECIMAL / COUNT(*)::DECIMAL) * 100)::INTEGER as progress_percentage
    FROM verification_steps 
    WHERE user_id = p_user_id;
END;
$$ LANGUAGE plpgsql;

-- Function to initialize verification steps for a user
CREATE OR REPLACE FUNCTION initialize_verification_steps(p_user_id UUID)
RETURNS VOID AS $$
BEGIN
    INSERT INTO verification_steps (user_id, step_id, title, description, step_order)
    VALUES 
        (p_user_id, 'identity', 'Verificación de Identidad', 'Sube tu cédula de ciudadanía', 1),
        (p_user_id, 'income', 'Verificación de Ingresos', 'Certificado laboral o extractos bancarios', 2),
        (p_user_id, 'references', 'Referencias Personales', 'Contactos de referencia', 3),
        (p_user_id, 'background', 'Antecedentes Crediticios', 'Consulta en centrales de riesgo', 4)
    ON CONFLICT (user_id, step_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql;

-- Trigger to update verification status in users table
CREATE OR REPLACE FUNCTION update_user_verification_status()
RETURNS TRIGGER AS $$
DECLARE
    completed_count INTEGER;
    total_count INTEGER;
BEGIN
    -- Count completed and total steps for the user
    SELECT 
        COUNT(CASE WHEN status = 'completed' THEN 1 END),
        COUNT(*)
    INTO completed_count, total_count
    FROM verification_steps 
    WHERE user_id = NEW.user_id;
    
    -- Update user verification status
    IF completed_count = total_count THEN
        UPDATE users 
        SET verified = TRUE, verification_status = 'completed'
        WHERE id = NEW.user_id;
    ELSIF completed_count > 0 THEN
        UPDATE users 
        SET verification_status = 'in_progress'
        WHERE id = NEW.user_id;
    ELSE
        UPDATE users 
        SET verification_status = 'not_started'
        WHERE id = NEW.user_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS trigger_update_verification_status ON verification_steps;
CREATE TRIGGER trigger_update_verification_status
    AFTER INSERT OR UPDATE ON verification_steps
    FOR EACH ROW
    EXECUTE FUNCTION update_user_verification_status();
