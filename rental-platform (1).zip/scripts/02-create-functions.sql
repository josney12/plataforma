-- Function to get property statistics
CREATE OR REPLACE FUNCTION get_property_stats(property_uuid UUID)
RETURNS TABLE(
    view_count BIGINT,
    application_count BIGINT,
    average_rating DECIMAL(3,2),
    review_count BIGINT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*) FROM property_views WHERE property_id = property_uuid),
        (SELECT COUNT(*) FROM applications WHERE property_id = property_uuid),
        (SELECT ROUND(AVG(rating::DECIMAL), 2) FROM reviews WHERE property_id = property_uuid),
        (SELECT COUNT(*) FROM reviews WHERE property_id = property_uuid);
END;
$$ LANGUAGE plpgsql;

-- Function to get user analytics for owners
CREATE OR REPLACE FUNCTION get_owner_analytics(owner_uuid UUID)
RETURNS TABLE(
    total_properties BIGINT,
    active_properties BIGINT,
    total_views BIGINT,
    total_applications BIGINT,
    active_contracts BIGINT,
    total_revenue INTEGER
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (SELECT COUNT(*) FROM properties WHERE owner_id = owner_uuid),
        (SELECT COUNT(*) FROM properties WHERE owner_id = owner_uuid AND available = true),
        (SELECT COUNT(*) FROM property_views pv 
         JOIN properties p ON pv.property_id = p.id 
         WHERE p.owner_id = owner_uuid),
        (SELECT COUNT(*) FROM applications a 
         JOIN properties p ON a.property_id = p.id 
         WHERE p.owner_id = owner_uuid),
        (SELECT COUNT(*) FROM contracts WHERE owner_id = owner_uuid AND status = 'active'),
        (SELECT COALESCE(SUM(monthly_rent), 0) FROM contracts 
         WHERE owner_id = owner_uuid AND status = 'active');
END;
$$ LANGUAGE plpgsql;

-- Function to create notification
CREATE OR REPLACE FUNCTION create_notification(
    user_uuid UUID,
    notification_title VARCHAR(255),
    notification_message TEXT,
    notification_type VARCHAR(50),
    notification_data JSONB DEFAULT '{}'
)
RETURNS UUID AS $$
DECLARE
    notification_id UUID;
BEGIN
    INSERT INTO notifications (user_id, title, message, type, data)
    VALUES (user_uuid, notification_title, notification_message, notification_type, notification_data)
    RETURNING id INTO notification_id;
    
    RETURN notification_id;
END;
$$ LANGUAGE plpgsql;

-- Function to automatically create payments for new contracts
CREATE OR REPLACE FUNCTION create_contract_payments()
RETURNS TRIGGER AS $$
BEGIN
    -- Create deposit payment
    INSERT INTO payments (contract_id, amount, payment_type, status, due_date)
    VALUES (NEW.id, NEW.deposit, 'deposit', 'pending', NEW.start_date);
    
    -- Create first month rent payment
    INSERT INTO payments (contract_id, amount, payment_type, status, due_date)
    VALUES (NEW.id, NEW.monthly_rent, 'rent', 'pending', NEW.start_date);
    
    -- Create notification for tenant
    PERFORM create_notification(
        NEW.tenant_id,
        'Nuevo Contrato Creado',
        'Se ha creado un nuevo contrato para tu propiedad. Revisa los detalles y realiza los pagos correspondientes.',
        'contract_created',
        json_build_object('contract_id', NEW.id)::jsonb
    );
    
    -- Create notification for owner
    PERFORM create_notification(
        NEW.owner_id,
        'Contrato Firmado',
        'Un inquilino ha firmado el contrato para tu propiedad.',
        'contract_signed',
        json_build_object('contract_id', NEW.id)::jsonb
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_create_contract_payments
    AFTER INSERT ON contracts
    FOR EACH ROW
    EXECUTE FUNCTION create_contract_payments();

-- Function to notify on new applications
CREATE OR REPLACE FUNCTION notify_new_application()
RETURNS TRIGGER AS $$
DECLARE
    property_owner_id UUID;
    property_title VARCHAR(255);
BEGIN
    -- Get property owner and title
    SELECT owner_id, title INTO property_owner_id, property_title
    FROM properties WHERE id = NEW.property_id;
    
    -- Create notification for property owner
    PERFORM create_notification(
        property_owner_id,
        'Nueva Solicitud de Arrendamiento',
        'Has recibido una nueva solicitud para tu propiedad: ' || property_title,
        'new_application',
        json_build_object('application_id', NEW.id, 'property_id', NEW.property_id)::jsonb
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_new_application
    AFTER INSERT ON applications
    FOR EACH ROW
    EXECUTE FUNCTION notify_new_application();
