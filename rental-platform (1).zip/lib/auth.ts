import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { pool } from "./database"
import type { User } from "./database"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

export function generateToken(userId: string): string {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "7d" })
}

export function verifyToken(token: string): { userId: string } | null {
  try {
    return jwt.verify(token, JWT_SECRET) as { userId: string }
  } catch {
    return null
  }
}

export async function createUser(userData: {
  email: string
  password: string
  name: string
  phone?: string
  user_type: User["user_type"]
}): Promise<User> {
  const hashedPassword = await hashPassword(userData.password)

  const query = `
    INSERT INTO users (email, password_hash, name, phone, user_type)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING id, email, name, phone, user_type, verified, avatar_url, created_at, updated_at
  `

  const values = [userData.email, hashedPassword, userData.name, userData.phone, userData.user_type]

  try {
    const result = await pool.query(query, values)
    return result.rows[0]
  } catch (error: any) {
    if (error.code === "23505") {
      // Unique violation
      throw new Error("El email ya está registrado")
    }
    throw error
  }
}

export async function authenticateUser(email: string, password: string): Promise<{ user: User; token: string } | null> {
  const query = `
    SELECT id, email, password_hash, name, phone, user_type, verified, avatar_url, created_at, updated_at
    FROM users 
    WHERE email = $1
  `

  const result = await pool.query(query, [email])

  if (result.rows.length === 0) {
    return null
  }

  const user = result.rows[0]
  const isValidPassword = await verifyPassword(password, user.password_hash)

  if (!isValidPassword) {
    return null
  }

  const token = generateToken(user.id)

  // Remove password_hash from user object
  const { password_hash, ...userWithoutPassword } = user

  return { user: userWithoutPassword, token }
}

export async function getUserById(userId: string): Promise<User | null> {
  const query = `
    SELECT id, email, name, phone, user_type, verified, avatar_url, created_at, updated_at
    FROM users 
    WHERE id = $1
  `

  const result = await pool.query(query, [userId])

  if (result.rows.length === 0) {
    return null
  }

  return result.rows[0]
}

export async function createSession(userId: string): Promise<string> {
  const sessionToken = generateToken(userId)
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

  const query = `
    INSERT INTO user_sessions (user_id, session_token, expires_at)
    VALUES ($1, $2, $3)
    ON CONFLICT (session_token) DO UPDATE SET expires_at = $3
    RETURNING session_token
  `

  await pool.query(query, [userId, sessionToken, expiresAt])
  return sessionToken
}

export async function validateSession(sessionToken: string): Promise<User | null> {
  const query = `
    SELECT u.id, u.email, u.name, u.phone, u.user_type, u.verified, u.avatar_url, u.created_at, u.updated_at
    FROM users u
    JOIN user_sessions s ON u.id = s.user_id
    WHERE s.session_token = $1 AND s.expires_at > NOW()
  `

  const result = await pool.query(query, [sessionToken])

  if (result.rows.length === 0) {
    return null
  }

  return result.rows[0]
}

export async function deleteSession(sessionToken: string): Promise<void> {
  const query = `DELETE FROM user_sessions WHERE session_token = $1`
  await pool.query(query, [sessionToken])
}
