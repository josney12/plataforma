import { Pool } from "pg"

const pool = new Pool({
  user: process.env.DB_USER,
  host: process.env.DB_HOST,
  database: process.env.DB_NAME,
  password: process.env.DB_PASSWORD,
  port: Number.parseInt(process.env.DB_PORT || "5432"),
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

export { pool }

// Types
export interface User {
  id: string
  email: string
  name: string
  phone?: string
  user_type: "TENANT" | "OWNER" | "AGENCY"
  verified: boolean
  avatar_url?: string
  verification_documents?: any
  created_at: string
  updated_at: string
}

export interface Property {
  id: string
  owner_id: string
  title: string
  description?: string
  property_type: string
  price: number
  deposit?: number
  admin_fee?: number
  address: string
  city: string
  neighborhood?: string
  bedrooms?: number
  bathrooms?: number
  area?: number
  amenities?: string[]
  features?: string[]
  images?: string[]
  available: boolean
  available_from?: string
  latitude?: number
  longitude?: number
  created_at: string
  updated_at: string
  owner?: User
  view_count?: number
  application_count?: number
  average_rating?: number
  review_count?: number
  is_favorite?: boolean
}

export interface Application {
  id: string
  property_id: string
  tenant_id: string
  status: "pending" | "approved" | "rejected" | "withdrawn"
  message?: string
  documents?: any
  created_at: string
  updated_at: string
  property?: Property
  tenant?: User
}

export interface Contract {
  id: string
  property_id: string
  tenant_id: string
  owner_id: string
  start_date: string
  end_date: string
  monthly_rent: number
  deposit: number
  status: "draft" | "pending" | "active" | "expired" | "terminated"
  contract_url?: string
  special_clauses?: string
  signed_at?: string
  created_at: string
  updated_at: string
  property?: Property
  tenant?: User
  owner?: User
}

export interface Payment {
  id: string
  contract_id: string
  amount: number
  payment_type: "rent" | "deposit" | "admin" | "other"
  payment_method?: string
  status: "pending" | "completed" | "failed" | "refunded"
  due_date?: string
  paid_at?: string
  transaction_id?: string
  payment_reference?: string
  created_at: string
  contract?: Contract
}

export interface Review {
  id: string
  property_id: string
  reviewer_id: string
  rating: number
  comment?: string
  images?: string[]
  created_at: string
  reviewer?: User
}

export interface Notification {
  id: string
  user_id: string
  title: string
  message: string
  type: string
  data?: any
  read_at?: string
  created_at: string
}
