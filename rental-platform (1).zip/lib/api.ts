import { supabase, type User, type Property, type Application, type Contract, type Payment } from "./supabase"

// Auth functions
export async function signUp(email: string, password: string, userData: Partial<User>) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  })

  if (error) throw error

  if (data.user) {
    // Insert user data into our users table
    const { error: insertError } = await supabase.from("users").insert({
      id: data.user.id,
      email,
      ...userData,
    })

    if (insertError) throw insertError
  }

  return data
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) throw error
  return data
}

export async function signOut() {
  const { error } = await supabase.auth.signOut()
  if (error) throw error
}

export async function getCurrentUser() {
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data: userData, error } = await supabase.from("users").select("*").eq("id", user.id).single()

  if (error) throw error
  return userData as User
}

// Properties functions
export async function getProperties(filters?: {
  city?: string
  minPrice?: number
  maxPrice?: number
  propertyType?: string
  bedrooms?: number
}) {
  let query = supabase
    .from("properties")
    .select(`
      *,
      owner:users!properties_owner_id_fkey(name, verified),
      view_count:property_views(count)
    `)
    .eq("available", true)

  if (filters?.city) {
    query = query.ilike("city", `%${filters.city}%`)
  }
  if (filters?.minPrice) {
    query = query.gte("price", filters.minPrice)
  }
  if (filters?.maxPrice) {
    query = query.lte("price", filters.maxPrice)
  }
  if (filters?.propertyType) {
    query = query.eq("property_type", filters.propertyType)
  }
  if (filters?.bedrooms) {
    query = query.eq("bedrooms", filters.bedrooms)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) throw error
  return data as Property[]
}

export async function getProperty(id: string, userId?: string) {
  const { data, error } = await supabase
    .from("properties")
    .select(`
      *,
      owner:users!properties_owner_id_fkey(*),
      reviews:reviews(*, reviewer:users!reviews_reviewer_id_fkey(name, avatar_url))
    `)
    .eq("id", id)
    .single()

  if (error) throw error

  // Track view if user is provided
  if (userId) {
    await supabase.from("property_views").insert({ property_id: id, user_id: userId })
  }

  // Check if property is favorited by user
  if (userId) {
    const { data: favorite } = await supabase
      .from("favorites")
      .select("id")
      .eq("user_id", userId)
      .eq("property_id", id)
      .single()

    data.is_favorite = !!favorite
  }

  return data as Property
}

export async function createProperty(propertyData: Omit<Property, "id" | "created_at" | "updated_at">) {
  const { data, error } = await supabase.from("properties").insert(propertyData).select().single()

  if (error) throw error
  return data as Property
}

export async function updateProperty(id: string, updates: Partial<Property>) {
  const { data, error } = await supabase
    .from("properties")
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data as Property
}

// Applications functions
export async function createApplication(applicationData: {
  property_id: string
  tenant_id: string
  message?: string
}) {
  const { data, error } = await supabase.from("applications").insert(applicationData).select().single()

  if (error) throw error
  return data as Application
}

export async function getApplications(userId: string, userType: "tenant" | "owner") {
  let query = supabase.from("applications").select(`
      *,
      property:properties(*),
      tenant:users!applications_tenant_id_fkey(*)
    `)

  if (userType === "tenant") {
    query = query.eq("tenant_id", userId)
  } else {
    query = query.eq("property.owner_id", userId)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) throw error
  return data as Application[]
}

export async function updateApplicationStatus(id: string, status: Application["status"]) {
  const { data, error } = await supabase
    .from("applications")
    .update({ status, updated_at: new Date().toISOString() })
    .eq("id", id)
    .select()
    .single()

  if (error) throw error
  return data as Application
}

// Favorites functions
export async function toggleFavorite(userId: string, propertyId: string) {
  const { data: existing } = await supabase
    .from("favorites")
    .select("id")
    .eq("user_id", userId)
    .eq("property_id", propertyId)
    .single()

  if (existing) {
    const { error } = await supabase.from("favorites").delete().eq("id", existing.id)

    if (error) throw error
    return false
  } else {
    const { error } = await supabase.from("favorites").insert({ user_id: userId, property_id: propertyId })

    if (error) throw error
    return true
  }
}

export async function getFavorites(userId: string) {
  const { data, error } = await supabase
    .from("favorites")
    .select(`
      *,
      property:properties(*, owner:users!properties_owner_id_fkey(name, verified))
    `)
    .eq("user_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data.map((item) => item.property) as Property[]
}

// Contracts functions
export async function getContracts(userId: string, userType: "tenant" | "owner") {
  let query = supabase.from("contracts").select(`
      *,
      property:properties(*),
      tenant:users!contracts_tenant_id_fkey(*),
      owner:users!contracts_owner_id_fkey(*)
    `)

  if (userType === "tenant") {
    query = query.eq("tenant_id", userId)
  } else {
    query = query.eq("owner_id", userId)
  }

  const { data, error } = await query.order("created_at", { ascending: false })

  if (error) throw error
  return data as Contract[]
}

// Payments functions
export async function getPayments(userId: string) {
  const { data, error } = await supabase
    .from("payments")
    .select(`
      *,
      contract:contracts(
        *,
        property:properties(title),
        tenant:users!contracts_tenant_id_fkey(name)
      )
    `)
    .eq("contract.tenant_id", userId)
    .order("created_at", { ascending: false })

  if (error) throw error
  return data as Payment[]
}

export async function createPayment(paymentData: {
  contract_id: string
  amount: number
  payment_type: Payment["payment_type"]
  payment_method?: string
  due_date?: string
}) {
  const { data, error } = await supabase.from("payments").insert(paymentData).select().single()

  if (error) throw error
  return data as Payment
}

// Analytics functions
export async function getOwnerAnalytics(ownerId: string) {
  // Get properties count
  const { count: propertiesCount } = await supabase
    .from("properties")
    .select("*", { count: "exact", head: true })
    .eq("owner_id", ownerId)

  // Get total views
  const { data: viewsData } = await supabase
    .from("property_views")
    .select("property_id, properties!inner(owner_id)")
    .eq("properties.owner_id", ownerId)

  // Get applications count
  const { count: applicationsCount } = await supabase
    .from("applications")
    .select("*, properties!inner(owner_id)", { count: "exact", head: true })
    .eq("properties.owner_id", ownerId)

  // Get average rent
  const { data: rentData } = await supabase.from("properties").select("price").eq("owner_id", ownerId)

  const averageRent = rentData?.length ? Math.round(rentData.reduce((sum, p) => sum + p.price, 0) / rentData.length) : 0

  return {
    propertiesCount: propertiesCount || 0,
    totalViews: viewsData?.length || 0,
    applicationsCount: applicationsCount || 0,
    averageRent,
  }
}
