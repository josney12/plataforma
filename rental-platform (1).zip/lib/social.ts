import { pool } from "./database"

export interface SocialPost {
  post_id: string
  user_id: string
  user_name: string
  user_avatar?: string
  user_type: string
  user_verified: boolean
  property_id?: string
  property_title?: string
  property_price?: number
  property_city?: string
  property_images?: string[]
  content?: string
  post_images?: string[]
  post_type: string
  likes_count: number
  comments_count: number
  shares_count: number
  created_at: string
  user_liked: boolean
  user_following: boolean
}

export interface AgencyStats {
  total_properties: number
  active_properties: number
  followers_count: number
  total_likes: number
  avg_rating: number
  total_reviews: number
}

export interface AgencyProfile {
  id: string
  name: string
  email: string
  phone?: string
  avatar_url?: string
  verified: boolean
  created_at: string
  bio?: string
  website?: string
  stats: AgencyStats
  top_properties: any[]
  is_following?: boolean
}

export async function getSocialFeed(userId?: string, limit = 20, offset = 0): Promise<SocialPost[]> {
  const query = `SELECT * FROM get_social_feed($1, $2, $3)`
  const result = await pool.query(query, [userId || null, limit, offset])

  return result.rows.map((row) => ({
    post_id: row.post_id,
    user_id: row.user_id,
    user_name: row.user_name,
    user_avatar: row.user_avatar,
    user_type: row.user_type,
    user_verified: row.user_verified,
    property_id: row.property_id,
    property_title: row.property_title,
    property_price: row.property_price,
    property_city: row.property_city,
    property_images: row.property_images,
    content: row.content,
    post_images: row.post_images,
    post_type: row.post_type,
    likes_count: row.likes_count,
    comments_count: row.comments_count,
    shares_count: row.shares_count,
    created_at: row.created_at,
    user_liked: row.user_liked,
    user_following: row.user_following,
  }))
}

export async function togglePostLike(userId: string, postId: string): Promise<boolean> {
  const checkQuery = `SELECT id FROM post_likes WHERE user_id = $1 AND post_id = $2`
  const checkResult = await pool.query(checkQuery, [userId, postId])

  if (checkResult.rows.length > 0) {
    // Remove like
    const deleteQuery = `DELETE FROM post_likes WHERE user_id = $1 AND post_id = $2`
    await pool.query(deleteQuery, [userId, postId])
    return false
  } else {
    // Add like
    const insertQuery = `INSERT INTO post_likes (user_id, post_id) VALUES ($1, $2)`
    await pool.query(insertQuery, [userId, postId])
    return true
  }
}

export async function togglePropertyLike(userId: string, propertyId: string): Promise<boolean> {
  const checkQuery = `SELECT id FROM property_likes WHERE user_id = $1 AND property_id = $2`
  const checkResult = await pool.query(checkQuery, [userId, propertyId])

  if (checkResult.rows.length > 0) {
    // Remove like
    const deleteQuery = `DELETE FROM property_likes WHERE user_id = $1 AND property_id = $2`
    await pool.query(deleteQuery, [userId, propertyId])
    return false
  } else {
    // Add like
    const insertQuery = `INSERT INTO property_likes (user_id, property_id) VALUES ($1, $2)`
    await pool.query(insertQuery, [userId, propertyId])
    return true
  }
}

export async function followAgency(followerId: string, agencyId: string): Promise<boolean> {
  const checkQuery = `SELECT id FROM agency_followers WHERE follower_id = $1 AND agency_id = $2`
  const checkResult = await pool.query(checkQuery, [followerId, agencyId])

  if (checkResult.rows.length > 0) {
    // Unfollow
    const deleteQuery = `DELETE FROM agency_followers WHERE follower_id = $1 AND agency_id = $2`
    await pool.query(deleteQuery, [followerId, agencyId])
    return false
  } else {
    // Follow
    const insertQuery = `INSERT INTO agency_followers (follower_id, agency_id) VALUES ($1, $2)`
    await pool.query(insertQuery, [followerId, agencyId])
    return true
  }
}

export async function getAgencyProfile(agencyId: string, viewerId?: string): Promise<AgencyProfile | null> {
  // Get agency basic info
  const agencyQuery = `
    SELECT id, name, email, phone, avatar_url, verified, created_at
    FROM users 
    WHERE id = $1 AND user_type IN ('AGENCY', 'OWNER')
  `
  const agencyResult = await pool.query(agencyQuery, [agencyId])

  if (agencyResult.rows.length === 0) {
    return null
  }

  const agency = agencyResult.rows[0]

  // Get agency stats
  const statsQuery = `SELECT * FROM get_agency_stats($1)`
  const statsResult = await pool.query(statsQuery, [agencyId])
  const stats = statsResult.rows[0] || {
    total_properties: 0,
    active_properties: 0,
    followers_count: 0,
    total_likes: 0,
    avg_rating: 0,
    total_reviews: 0,
  }

  // Get top properties
  const propertiesQuery = `
    SELECT 
      p.*,
      COALESCE(pl_count.likes, 0) as likes_count,
      COALESCE(pv_count.views, 0) as views_count
    FROM properties p
    LEFT JOIN (
      SELECT property_id, COUNT(*) as likes
      FROM property_likes
      GROUP BY property_id
    ) pl_count ON p.id = pl_count.property_id
    LEFT JOIN (
      SELECT property_id, COUNT(*) as views
      FROM property_views
      GROUP BY property_id
    ) pv_count ON p.id = pv_count.property_id
    WHERE p.owner_id = $1 AND p.available = true
    ORDER BY pl_count.likes DESC, pv_count.views DESC
    LIMIT 6
  `
  const propertiesResult = await pool.query(propertiesQuery, [agencyId])

  // Check if viewer is following
  let isFollowing = false
  if (viewerId) {
    const followQuery = `SELECT id FROM agency_followers WHERE follower_id = $1 AND agency_id = $2`
    const followResult = await pool.query(followQuery, [viewerId, agencyId])
    isFollowing = followResult.rows.length > 0
  }

  return {
    id: agency.id,
    name: agency.name,
    email: agency.email,
    phone: agency.phone,
    avatar_url: agency.avatar_url,
    verified: agency.verified,
    created_at: agency.created_at,
    stats: {
      total_properties: Number.parseInt(stats.total_properties) || 0,
      active_properties: Number.parseInt(stats.active_properties) || 0,
      followers_count: Number.parseInt(stats.followers_count) || 0,
      total_likes: Number.parseInt(stats.total_likes) || 0,
      avg_rating: Number.parseFloat(stats.avg_rating) || 0,
      total_reviews: Number.parseInt(stats.total_reviews) || 0,
    },
    top_properties: propertiesResult.rows,
    is_following: isFollowing,
  }
}

export async function createSocialPost(postData: {
  user_id: string
  property_id?: string
  content?: string
  images?: string[]
  post_type?: string
}): Promise<any> {
  const query = `
    INSERT INTO social_posts (user_id, property_id, content, images, post_type)
    VALUES ($1, $2, $3, $4, $5)
    RETURNING *
  `

  const values = [
    postData.user_id,
    postData.property_id || null,
    postData.content || null,
    postData.images || [],
    postData.post_type || "announcement",
  ]

  const result = await pool.query(query, values)
  return result.rows[0]
}

export async function getAgencies(limit = 20, offset = 0): Promise<AgencyProfile[]> {
  const query = `
    SELECT 
      u.id, u.name, u.email, u.phone, u.avatar_url, u.verified, u.created_at,
      stats.*
    FROM users u
    LEFT JOIN LATERAL get_agency_stats(u.id) stats ON true
    WHERE u.user_type IN ('AGENCY', 'OWNER')
    ORDER BY stats.followers_count DESC, stats.active_properties DESC
    LIMIT $1 OFFSET $2
  `

  const result = await pool.query(query, [limit, offset])

  return result.rows.map((row) => ({
    id: row.id,
    name: row.name,
    email: row.email,
    phone: row.phone,
    avatar_url: row.avatar_url,
    verified: row.verified,
    created_at: row.created_at,
    stats: {
      total_properties: Number.parseInt(row.total_properties) || 0,
      active_properties: Number.parseInt(row.active_properties) || 0,
      followers_count: Number.parseInt(row.followers_count) || 0,
      total_likes: Number.parseInt(row.total_likes) || 0,
      avg_rating: Number.parseFloat(row.avg_rating) || 0,
      total_reviews: Number.parseInt(row.total_reviews) || 0,
    },
    top_properties: [],
  }))
}
