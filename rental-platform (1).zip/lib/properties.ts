import { pool } from "./database"
import type { Property, Application } from "./database"

export async function createProperty(
  propertyData: Omit<Property, "id" | "created_at" | "updated_at">,
): Promise<Property> {
  const query = `
    INSERT INTO properties (
      owner_id, title, description, property_type, price, deposit, admin_fee,
      address, city, neighborhood, bedrooms, bathrooms, area, amenities, features, 
      images, available_from, latitude, longitude
    )
    VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19)
    RETURNING *
  `

  const values = [
    propertyData.owner_id,
    propertyData.title,
    propertyData.description,
    propertyData.property_type,
    propertyData.price,
    propertyData.deposit,
    propertyData.admin_fee,
    propertyData.address,
    propertyData.city,
    propertyData.neighborhood,
    propertyData.bedrooms,
    propertyData.bathrooms,
    propertyData.area,
    propertyData.amenities,
    propertyData.features,
    propertyData.images,
    propertyData.available_from,
    propertyData.latitude,
    propertyData.longitude,
  ]

  const result = await pool.query(query, values)
  return result.rows[0]
}

export async function getProperties(
  filters: {
    city?: string
    minPrice?: number
    maxPrice?: number
    propertyType?: string
    bedrooms?: number
    limit?: number
    offset?: number
  } = {},
): Promise<Property[]> {
  let query = `
    SELECT 
      p.*,
      u.name as owner_name,
      u.verified as owner_verified,
      u.avatar_url as owner_avatar,
      stats.view_count,
      stats.application_count,
      stats.average_rating,
      stats.review_count
    FROM properties p
    LEFT JOIN users u ON p.owner_id = u.id
    LEFT JOIN LATERAL get_property_stats(p.id) stats ON true
    WHERE p.available = true
  `

  const values: any[] = []
  let paramCount = 0

  if (filters.city) {
    paramCount++
    query += ` AND LOWER(p.city) LIKE LOWER($${paramCount})`
    values.push(`%${filters.city}%`)
  }

  if (filters.minPrice) {
    paramCount++
    query += ` AND p.price >= $${paramCount}`
    values.push(filters.minPrice)
  }

  if (filters.maxPrice) {
    paramCount++
    query += ` AND p.price <= $${paramCount}`
    values.push(filters.maxPrice)
  }

  if (filters.propertyType) {
    paramCount++
    query += ` AND p.property_type = $${paramCount}`
    values.push(filters.propertyType)
  }

  if (filters.bedrooms) {
    paramCount++
    query += ` AND p.bedrooms = $${paramCount}`
    values.push(filters.bedrooms)
  }

  query += ` ORDER BY p.created_at DESC`

  if (filters.limit) {
    paramCount++
    query += ` LIMIT $${paramCount}`
    values.push(filters.limit)
  }

  if (filters.offset) {
    paramCount++
    query += ` OFFSET $${paramCount}`
    values.push(filters.offset)
  }

  const result = await pool.query(query, values)

  return result.rows.map((row) => ({
    id: row.id,
    owner_id: row.owner_id,
    title: row.title,
    description: row.description,
    property_type: row.property_type,
    price: row.price,
    deposit: row.deposit,
    admin_fee: row.admin_fee,
    address: row.address,
    city: row.city,
    neighborhood: row.neighborhood,
    bedrooms: row.bedrooms,
    bathrooms: row.bathrooms,
    area: row.area,
    amenities: row.amenities,
    features: row.features,
    images: row.images,
    available: row.available,
    available_from: row.available_from,
    latitude: row.latitude,
    longitude: row.longitude,
    created_at: row.created_at,
    updated_at: row.updated_at,
    owner: {
      name: row.owner_name,
      verified: row.owner_verified,
      avatar_url: row.owner_avatar,
    },
    view_count: Number.parseInt(row.view_count) || 0,
    application_count: Number.parseInt(row.application_count) || 0,
    average_rating: Number.parseFloat(row.average_rating) || 0,
    review_count: Number.parseInt(row.review_count) || 0,
  }))
}

export async function getProperty(id: string, userId?: string): Promise<Property | null> {
  // Record view if user is provided
  if (userId) {
    await recordPropertyView(id, userId)
  }

  const query = `
    SELECT 
      p.*,
      u.id as owner_id,
      u.name as owner_name,
      u.email as owner_email,
      u.phone as owner_phone,
      u.verified as owner_verified,
      u.avatar_url as owner_avatar,
      stats.view_count,
      stats.application_count,
      stats.average_rating,
      stats.review_count
    FROM properties p
    LEFT JOIN users u ON p.owner_id = u.id
    LEFT JOIN LATERAL get_property_stats(p.id) stats ON true
    WHERE p.id = $1
  `

  const result = await pool.query(query, [id])

  if (result.rows.length === 0) {
    return null
  }

  const row = result.rows[0]

  // Check if property is favorited by user
  let isFavorite = false
  if (userId) {
    const favoriteQuery = `SELECT id FROM favorites WHERE user_id = $1 AND property_id = $2`
    const favoriteResult = await pool.query(favoriteQuery, [userId, id])
    isFavorite = favoriteResult.rows.length > 0
  }

  return {
    id: row.id,
    owner_id: row.owner_id,
    title: row.title,
    description: row.description,
    property_type: row.property_type,
    price: row.price,
    deposit: row.deposit,
    admin_fee: row.admin_fee,
    address: row.address,
    city: row.city,
    neighborhood: row.neighborhood,
    bedrooms: row.bedrooms,
    bathrooms: row.bathrooms,
    area: row.area,
    amenities: row.amenities,
    features: row.features,
    images: row.images,
    available: row.available,
    available_from: row.available_from,
    latitude: row.latitude,
    longitude: row.longitude,
    created_at: row.created_at,
    updated_at: row.updated_at,
    owner: {
      id: row.owner_id,
      name: row.owner_name,
      email: row.owner_email,
      phone: row.owner_phone,
      verified: row.owner_verified,
      avatar_url: row.owner_avatar,
    },
    view_count: Number.parseInt(row.view_count) || 0,
    application_count: Number.parseInt(row.application_count) || 0,
    average_rating: Number.parseFloat(row.average_rating) || 0,
    review_count: Number.parseInt(row.review_count) || 0,
    is_favorite: isFavorite,
  }
}

export async function recordPropertyView(
  propertyId: string,
  userId?: string,
  ipAddress?: string,
  userAgent?: string,
): Promise<void> {
  const query = `
    INSERT INTO property_views (property_id, user_id, ip_address, user_agent)
    VALUES ($1, $2, $3, $4)
  `

  await pool.query(query, [propertyId, userId, ipAddress, userAgent])
}

export async function createApplication(applicationData: {
  property_id: string
  tenant_id: string
  message?: string
  documents?: any
}): Promise<Application> {
  const query = `
    INSERT INTO applications (property_id, tenant_id, message, documents)
    VALUES ($1, $2, $3, $4)
    RETURNING *
  `

  const values = [
    applicationData.property_id,
    applicationData.tenant_id,
    applicationData.message,
    JSON.stringify(applicationData.documents || {}),
  ]

  const result = await pool.query(query, values)
  return result.rows[0]
}

export async function getApplications(userId: string, userType: "tenant" | "owner"): Promise<Application[]> {
  let query = `
    SELECT 
      a.*,
      p.title as property_title,
      p.price as property_price,
      p.city as property_city,
      p.images as property_images,
      u.name as tenant_name,
      u.email as tenant_email,
      u.phone as tenant_phone,
      u.verified as tenant_verified
    FROM applications a
    LEFT JOIN properties p ON a.property_id = p.id
    LEFT JOIN users u ON a.tenant_id = u.id
  `

  if (userType === "tenant") {
    query += ` WHERE a.tenant_id = $1`
  } else {
    query += ` WHERE p.owner_id = $1`
  }

  query += ` ORDER BY a.created_at DESC`

  const result = await pool.query(query, [userId])

  return result.rows.map((row) => ({
    id: row.id,
    property_id: row.property_id,
    tenant_id: row.tenant_id,
    status: row.status,
    message: row.message,
    documents: row.documents,
    created_at: row.created_at,
    updated_at: row.updated_at,
    property: {
      title: row.property_title,
      price: row.property_price,
      city: row.property_city,
      images: row.property_images,
    },
    tenant: {
      name: row.tenant_name,
      email: row.tenant_email,
      phone: row.tenant_phone,
      verified: row.tenant_verified,
    },
  }))
}

export async function toggleFavorite(userId: string, propertyId: string): Promise<boolean> {
  // Check if already favorited
  const checkQuery = `SELECT id FROM favorites WHERE user_id = $1 AND property_id = $2`
  const checkResult = await pool.query(checkQuery, [userId, propertyId])

  if (checkResult.rows.length > 0) {
    // Remove favorite
    const deleteQuery = `DELETE FROM favorites WHERE user_id = $1 AND property_id = $2`
    await pool.query(deleteQuery, [userId, propertyId])
    return false
  } else {
    // Add favorite
    const insertQuery = `INSERT INTO favorites (user_id, property_id) VALUES ($1, $2)`
    await pool.query(insertQuery, [userId, propertyId])
    return true
  }
}

export async function getFavorites(userId: string): Promise<Property[]> {
  const query = `
    SELECT 
      p.*,
      u.name as owner_name,
      u.verified as owner_verified,
      u.avatar_url as owner_avatar,
      stats.view_count,
      stats.application_count,
      stats.average_rating,
      stats.review_count
    FROM favorites f
    JOIN properties p ON f.property_id = p.id
    LEFT JOIN users u ON p.owner_id = u.id
    LEFT JOIN LATERAL get_property_stats(p.id) stats ON true
    WHERE f.user_id = $1
    ORDER BY f.created_at DESC
  `

  const result = await pool.query(query, [userId])

  return result.rows.map((row) => ({
    id: row.id,
    owner_id: row.owner_id,
    title: row.title,
    description: row.description,
    property_type: row.property_type,
    price: row.price,
    deposit: row.deposit,
    admin_fee: row.admin_fee,
    address: row.address,
    city: row.city,
    neighborhood: row.neighborhood,
    bedrooms: row.bedrooms,
    bathrooms: row.bathrooms,
    area: row.area,
    amenities: row.amenities,
    features: row.features,
    images: row.images,
    available: row.available,
    available_from: row.available_from,
    latitude: row.latitude,
    longitude: row.longitude,
    created_at: row.created_at,
    updated_at: row.updated_at,
    owner: {
      name: row.owner_name,
      verified: row.owner_verified,
      avatar_url: row.owner_avatar,
    },
    view_count: Number.parseInt(row.view_count) || 0,
    application_count: Number.parseInt(row.application_count) || 0,
    average_rating: Number.parseFloat(row.average_rating) || 0,
    review_count: Number.parseInt(row.review_count) || 0,
    is_favorite: true,
  }))
}
