"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Home,
  Users,
  Target,
  Award,
  Globe,
  Shield,
  Zap,
  Heart,
  TrendingUp,
  MapPin,
  Mail,
  Phone,
  Linkedin,
  Twitter,
  Calendar,
  Building,
  Lightbulb,
  Rocket,
} from "lucide-react"
import Link from "next/link"

const team = [
  {
    name: "María Elena Rodríguez",
    role: "CEO & Co-fundadora",
    image: "/placeholder.svg?height=200&width=200",
    bio: "Ex-directora de innovación en Bancolombia. MBA de INCAE. Experta en transformación digital del sector financiero.",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Carlos Andrés Mejía",
    role: "CTO & Co-fundador",
    image: "/placeholder.svg?height=200&width=200",
    bio: "Ingeniero de sistemas de la Universidad Nacional. Ex-líder técnico en Rappi. Especialista en arquitecturas escalables.",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Ana Sofía Vargas",
    role: "Head of Product",
    image: "/placeholder.svg?height=200&width=200",
    bio: "Diseñadora UX con 8 años de experiencia. Ex-Google. Especialista en productos digitales para mercados emergentes.",
    linkedin: "#",
    twitter: "#",
  },
  {
    name: "Diego Alejandro Sánchez",
    role: "Head of Growth",
    image: "/placeholder.svg?height=200&width=200",
    bio: "Especialista en marketing digital y growth hacking. Ex-Platzi. Experto en adquisición de usuarios en LatAm.",
    linkedin: "#",
    twitter: "#",
  },
]

const values = [
  {
    icon: Shield,
    title: "Confianza",
    description: "Construimos relaciones basadas en transparencia y seguridad digital",
  },
  {
    icon: Zap,
    title: "Innovación",
    description: "Utilizamos tecnología de punta para simplificar procesos complejos",
  },
  {
    icon: Heart,
    title: "Empatía",
    description: "Entendemos las necesidades reales de inquilinos y propietarios",
  },
  {
    icon: Users,
    title: "Comunidad",
    description: "Creamos conexiones genuinas entre personas y vecindarios",
  },
]

const milestones = [
  {
    year: "2023",
    title: "Fundación",
    description: "Nace RentaColombia con la visión de digitalizar el mercado inmobiliario",
    icon: Rocket,
  },
  {
    year: "2024",
    title: "Lanzamiento MVP",
    description: "Primera versión de la plataforma con 1,000 usuarios beta",
    icon: Lightbulb,
  },
  {
    year: "2024",
    title: "Serie A",
    description: "Levantamos $2M USD para expansión nacional",
    icon: TrendingUp,
  },
  {
    year: "2025",
    title: "Expansión",
    description: "Presencia en 5 ciudades principales de Colombia",
    icon: Globe,
  },
]

const stats = [
  { number: "50,000+", label: "Usuarios Registrados", icon: Users },
  { number: "15,000+", label: "Propiedades Activas", icon: Home },
  { number: "5", label: "Ciudades", icon: MapPin },
  { number: "98%", label: "Satisfacción", icon: Award },
]

const investors = [
  { name: "Accel Partners", logo: "/placeholder.svg?height=60&width=120" },
  { name: "Kaszek Ventures", logo: "/placeholder.svg?height=60&width=120" },
  { name: "Monashees", logo: "/placeholder.svg?height=60&width=120" },
  { name: "iNNpulsa Colombia", logo: "/placeholder.svg?height=60&width=120" },
]

const awards = [
  {
    title: "Mejor Startup PropTech 2024",
    organization: "Colombia Fintech",
    year: "2024",
  },
  {
    title: "Innovación Digital",
    organization: "Cámara de Comercio de Bogotá",
    year: "2024",
  },
  {
    title: "Top 10 Startups LatAm",
    organization: "TechCrunch",
    year: "2024",
  },
]

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/properties" className="text-gray-600 hover:text-blue-600">
              Propiedades
            </Link>
            <Link href="/how-it-works" className="text-gray-600 hover:text-blue-600">
              Cómo Funciona
            </Link>
            <Link href="/about" className="text-blue-600 font-medium">
              Nosotros
            </Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/auth/login">
              <Button variant="ghost">Iniciar Sesión</Button>
            </Link>
            <Link href="/auth/register">
              <Button>Comenzar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-blue-100 text-blue-800">
              <Building className="h-4 w-4 mr-1" />
              Transformando el Mercado Inmobiliario
            </Badge>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Sobre
              <span className="text-blue-600 block">RentaColombia</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8">
              Somos una startup colombiana que está revolucionando la forma en que las personas buscan, encuentran y
              arriendan propiedades en Colombia. Nuestra misión es hacer que el proceso de arrendamiento sea más
              transparente, eficiente y seguro para todos.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="text-lg px-8 py-4">
                <Users className="mr-2 h-5 w-5" />
                Conoce al Equipo
              </Button>
              <Button size="lg" variant="outline" className="text-lg px-8 py-4">
                <Mail className="mr-2 h-5 w-5" />
                Contáctanos
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <stat.icon className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                  <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                  <div className="text-gray-600">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestra Misión y Visión</h2>
              <p className="text-gray-600">Los principios que guían nuestro trabajo diario</p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <Card className="h-full">
                <CardHeader>
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                    <Target className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-2xl">Misión</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 text-lg leading-relaxed">
                    Democratizar el acceso a la vivienda en Colombia mediante tecnología innovadora que conecte de
                    manera segura y eficiente a propietarios e inquilinos, eliminando las barreras tradicionales del
                    mercado inmobiliario.
                  </p>
                </CardContent>
              </Card>

              <Card className="h-full">
                <CardHeader>
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mb-4">
                    <Globe className="h-8 w-8 text-purple-600" />
                  </div>
                  <CardTitle className="text-2xl">Visión</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-700 text-lg leading-relaxed">
                    Ser la plataforma líder de arrendamientos en América Latina para 2030, transformando la experiencia
                    inmobiliaria a través de inteligencia artificial, blockchain y una comunidad sólida de usuarios
                    verificados.
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestros Valores</h2>
            <p className="text-gray-600">Los principios que definen nuestra cultura y forma de trabajar</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{value.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestra Historia</h2>
            <p className="text-gray-600">Los hitos más importantes en nuestro crecimiento</p>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="space-y-8">
              {milestones.map((milestone, index) => (
                <div key={index} className="flex items-start space-x-6">
                  <div className="flex-shrink-0">
                    <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center">
                      <milestone.icon className="h-8 w-8 text-white" />
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-4 mb-2">
                      <Badge variant="outline" className="text-blue-600 border-blue-600">
                        {milestone.year}
                      </Badge>
                      <h3 className="text-xl font-semibold">{milestone.title}</h3>
                    </div>
                    <p className="text-gray-600">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestro Equipo</h2>
            <p className="text-gray-600">Los líderes que están construyendo el futuro del mercado inmobiliario</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <img
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    className="w-32 h-32 rounded-full mx-auto mb-4 object-cover"
                  />
                  <h3 className="text-xl font-semibold mb-2">{member.name}</h3>
                  <p className="text-blue-600 font-medium mb-3">{member.role}</p>
                  <p className="text-gray-600 text-sm mb-4">{member.bio}</p>
                  <div className="flex justify-center space-x-3">
                    <Link href={member.linkedin}>
                      <Button variant="outline" size="sm">
                        <Linkedin className="h-4 w-4" />
                      </Button>
                    </Link>
                    <Link href={member.twitter}>
                      <Button variant="outline" size="sm">
                        <Twitter className="h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Investors */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Nuestros Inversionistas</h2>
            <p className="text-gray-600">Respaldados por los mejores fondos de venture capital de la región</p>
          </div>

          <div className="grid md:grid-cols-4 gap-8 items-center">
            {investors.map((investor, index) => (
              <div key={index} className="text-center">
                <img
                  src={investor.logo || "/placeholder.svg"}
                  alt={investor.name}
                  className="h-16 mx-auto mb-4 object-contain filter grayscale hover:grayscale-0 transition-all"
                />
                <p className="text-gray-600 font-medium">{investor.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Awards */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Reconocimientos</h2>
            <p className="text-gray-600">Premios y reconocimientos que hemos recibido</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {awards.map((award, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <Award className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">{award.title}</h3>
                  <p className="text-gray-600 mb-2">{award.organization}</p>
                  <Badge variant="outline">{award.year}</Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">¿Quieres Saber Más?</h2>
            <p className="text-xl text-blue-100 mb-8">
              Estamos siempre abiertos a conversar sobre el futuro del mercado inmobiliario
            </p>

            <div className="grid md:grid-cols-3 gap-8 mb-8">
              <div className="text-center">
                <Mail className="h-8 w-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Email</h3>
                <p className="text-blue-100">hola@rentacolombia.com</p>
              </div>
              <div className="text-center">
                <Phone className="h-8 w-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Teléfono</h3>
                <p className="text-blue-100">+57 (1) 234-5678</p>
              </div>
              <div className="text-center">
                <MapPin className="h-8 w-8 mx-auto mb-4" />
                <h3 className="font-semibold mb-2">Oficina</h3>
                <p className="text-blue-100">Bogotá, Colombia</p>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
                <Calendar className="mr-2 h-5 w-5" />
                Agendar Reunión
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 text-white border-white hover:bg-white hover:text-blue-600"
              >
                <Mail className="mr-2 h-5 w-5" />
                Enviar Email
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Home className="h-6 w-6" />
                <span className="text-xl font-bold">RentaColombia</span>
              </div>
              <p className="text-gray-400">La plataforma digital líder en arrendamientos para Colombia</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Plataforma</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/properties">Propiedades</Link>
                </li>
                <li>
                  <Link href="/how-it-works">Cómo Funciona</Link>
                </li>
                <li>
                  <Link href="/pricing">Precios</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Soporte</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help">Centro de Ayuda</Link>
                </li>
                <li>
                  <Link href="/contact">Contacto</Link>
                </li>
                <li>
                  <Link href="/legal">Legal</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about">Nosotros</Link>
                </li>
                <li>
                  <Link href="/careers">Carreras</Link>
                </li>
                <li>
                  <Link href="/press">Prensa</Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 RentaColombia. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
