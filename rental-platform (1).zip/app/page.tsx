import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Search, Shield, Users, Zap, ArrowRight, Home, Building, Key } from "lucide-react"
import Link from "next/link"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Home className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-900">RentaColombia</span>
          </div>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/properties" className="text-gray-600 hover:text-blue-600">
              Propiedades
            </Link>
            <Link href="/how-it-works" className="text-gray-600 hover:text-blue-600">
              Cómo Funciona
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-blue-600">
              Nosotros
            </Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/auth/login">
              <Button variant="ghost">Iniciar Sesión</Button>
            </Link>
            <Link href="/auth/register">
              <Button>Registrarse</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-800 hover:bg-blue-100">
            🚀 La primera comunidad digital de arrendamientos en Colombia
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            Encuentra tu hogar ideal
            <span className="text-blue-600 block">sin complicaciones</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Digitaliza completamente tu proceso de arrendamiento. Conecta con propietarios verificados, firma contratos
            digitales y gestiona todo desde una sola plataforma.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/properties">
              <Button size="lg" className="text-lg px-8 py-4">
                <Search className="mr-2 h-5 w-5" />
                Buscar Propiedades
              </Button>
            </Link>
            <Link href="/auth/register?type=owner">
              <Button size="lg" variant="outline" className="text-lg px-8 py-4">
                <Building className="mr-2 h-5 w-5" />
                Publicar Propiedad
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Por qué elegir RentaColombia?</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Revolucionamos el mercado inmobiliario con tecnología de punta y un enfoque social único
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Shield className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <CardTitle>100% Verificado</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Todos los usuarios y propiedades pasan por un proceso de verificación digital completo
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Zap className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <CardTitle>Proceso Digital</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Desde la búsqueda hasta la firma del contrato, todo 100% digital sin papeleo
                </CardDescription>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardHeader>
                <Users className="h-12 w-12 text-blue-600 mx-auto mb-4" />
                <CardTitle>Comunidad Social</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Conecta con tu comunidad, comparte experiencias y encuentra recomendaciones
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 bg-blue-600 text-white">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">15,000+</div>
              <div className="text-blue-100">Propiedades Activas</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50,000+</div>
              <div className="text-blue-100">Usuarios Registrados</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">98%</div>
              <div className="text-blue-100">Satisfacción</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">24/7</div>
              <div className="text-blue-100">Soporte</div>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Cómo funciona</h2>
            <p className="text-gray-600">Simple, rápido y seguro</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Search className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">1. Busca</h3>
              <p className="text-gray-600">Utiliza nuestros filtros avanzados para encontrar la propiedad perfecta</p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">2. Conecta</h3>
              <p className="text-gray-600">Comunícate directamente con propietarios verificados</p>
            </div>

            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
                <Key className="h-8 w-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">3. Arrienda</h3>
              <p className="text-gray-600">Firma tu contrato digital y recibe las llaves</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Listo para comenzar?</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Únete a miles de colombianos que ya encontraron su hogar ideal con RentaColombia
          </p>
          <Link href="/auth/register">
            <Button size="lg" className="text-lg px-8 py-4">
              Comenzar Ahora
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12 px-4">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Home className="h-6 w-6" />
                <span className="text-xl font-bold">RentaColombia</span>
              </div>
              <p className="text-gray-400">La plataforma digital líder en arrendamientos para Colombia</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Plataforma</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/properties">Propiedades</Link>
                </li>
                <li>
                  <Link href="/how-it-works">Cómo Funciona</Link>
                </li>
                <li>
                  <Link href="/pricing">Precios</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Soporte</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help">Centro de Ayuda</Link>
                </li>
                <li>
                  <Link href="/contact">Contacto</Link>
                </li>
                <li>
                  <Link href="/legal">Legal</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about">Nosotros</Link>
                </li>
                <li>
                  <Link href="/careers">Carreras</Link>
                </li>
                <li>
                  <Link href="/press">Prensa</Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 RentaColombia. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
