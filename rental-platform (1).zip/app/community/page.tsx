"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  MessageSquare,
  MapPin,
  ThumbsUp,
  Share2,
  Home,
  Calendar,
  Shield,
  Plus,
  Bell,
  Heart,
  Camera,
  Send,
} from "lucide-react"
import Link from "next/link"

const communities = [
  {
    id: 1,
    name: "Chapinero Conecta",
    location: "Chapinero, Bogotá",
    members: 1247,
    posts: 89,
    description: "Comunidad de residentes y futuros inquilinos de Chapinero",
    image: "/placeholder.svg?height=100&width=100",
    category: "Barrio",
    active: true,
  },
  {
    id: 2,
    name: "El Poblado Social",
    location: "El Poblado, Medellín",
    members: 892,
    posts: 156,
    description: "Conecta con tu vecindario en El Poblado",
    image: "/placeholder.svg?height=100&width=100",
    category: "Barrio",
    active: false,
  },
  {
    id: 3,
    name: "Profesionales Jóvenes",
    location: "Nacional",
    members: 2341,
    posts: 234,
    description: "Red de profesionales buscando vivienda",
    image: "/placeholder.svg?height=100&width=100",
    category: "Interés",
    active: true,
  },
]

const posts = [
  {
    id: 1,
    user: {
      name: "María González",
      avatar: "/placeholder.svg?height=40&width=40",
      verified: true,
      role: "Propietaria",
    },
    community: "Chapinero Conecta",
    content:
      "¡Hola vecinos! Acabo de renovar mi apartamento y está disponible para arriendo. Excelente ubicación cerca del TransMilenio. ¿Alguien interesado?",
    images: ["/placeholder.svg?height=200&width=300"],
    likes: 23,
    comments: 8,
    shares: 3,
    time: "Hace 2 horas",
    tags: ["Arriendo", "Chapinero", "TransMilenio"],
  },
  {
    id: 2,
    user: {
      name: "Carlos Mendoza",
      avatar: "/placeholder.svg?height=40&width=40",
      verified: false,
      role: "Inquilino",
    },
    community: "Profesionales Jóvenes",
    content:
      "Busco compañero de apartamento para compartir gastos. Soy profesional en sistemas, trabajo remoto y muy ordenado. Presupuesto hasta $600k por persona.",
    images: [],
    likes: 15,
    comments: 12,
    shares: 5,
    time: "Hace 4 horas",
    tags: ["Compañero", "Sistemas", "Remoto"],
  },
  {
    id: 3,
    user: {
      name: "Ana Sofía López",
      avatar: "/placeholder.svg?height=40&width=40",
      verified: true,
      role: "Residente",
    },
    community: "El Poblado Social",
    content:
      "¿Alguien sabe de un buen lugar para desayunar cerca del Parque Lleras? Acabo de mudarme y quiero conocer la zona 😊",
    images: [],
    likes: 31,
    comments: 18,
    shares: 2,
    time: "Hace 6 horas",
    tags: ["Recomendación", "Desayuno", "Parque Lleras"],
  },
]

const events = [
  {
    id: 1,
    title: "Feria de Arrendamientos Chapinero",
    date: "15 Feb 2025",
    time: "10:00 AM",
    location: "Centro Comercial Andino",
    attendees: 45,
    organizer: "Chapinero Conecta",
  },
  {
    id: 2,
    title: "Networking Profesionales Jóvenes",
    date: "20 Feb 2025",
    time: "6:00 PM",
    location: "Zona Rosa",
    attendees: 78,
    organizer: "Profesionales Jóvenes",
  },
]

export default function CommunityPage() {
  const [selectedCommunity, setSelectedCommunity] = useState(1)
  const [newPost, setNewPost] = useState("")
  const [showCreatePost, setShowCreatePost] = useState(false)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Bell className="h-4 w-4 mr-2" />
              Notificaciones
            </Button>
            <Badge className="bg-green-100 text-green-800">
              <Users className="h-4 w-4 mr-1" />
              Comunidad Activa
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Comunidad RentaColombia</h1>
            <p className="text-gray-600">
              Conecta con tu vecindario, comparte experiencias y encuentra recomendaciones
            </p>
          </div>

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="space-y-6">
              {/* My Communities */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center justify-between">
                    <span>Mis Comunidades</span>
                    <Button size="sm" variant="outline">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {communities.map((community) => (
                    <div
                      key={community.id}
                      className={`p-3 rounded-lg cursor-pointer transition-colors ${
                        selectedCommunity === community.id ? "bg-blue-50 border border-blue-200" : "hover:bg-gray-50"
                      }`}
                      onClick={() => setSelectedCommunity(community.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <img
                          src={community.image || "/placeholder.svg"}
                          alt={community.name}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-medium text-sm truncate">{community.name}</h3>
                            {community.active && <div className="w-2 h-2 bg-green-500 rounded-full" />}
                          </div>
                          <p className="text-xs text-gray-600">{community.members} miembros</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Upcoming Events */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Próximos Eventos</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {events.map((event) => (
                    <div key={event.id} className="p-3 border rounded-lg">
                      <h4 className="font-medium text-sm mb-2">{event.title}</h4>
                      <div className="space-y-1 text-xs text-gray-600">
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          {event.date} • {event.time}
                        </div>
                        <div className="flex items-center">
                          <MapPin className="h-3 w-3 mr-1" />
                          {event.location}
                        </div>
                        <div className="flex items-center">
                          <Users className="h-3 w-3 mr-1" />
                          {event.attendees} asistirán
                        </div>
                      </div>
                      <Button size="sm" variant="outline" className="w-full mt-2">
                        Asistir
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Community Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Estadísticas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Posts esta semana:</span>
                    <span className="font-medium">47</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Nuevos miembros:</span>
                    <span className="font-medium">12</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Eventos activos:</span>
                    <span className="font-medium">3</span>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-6">
              {/* Community Header */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-4">
                    <img
                      src={communities.find((c) => c.id === selectedCommunity)?.image || "/placeholder.svg"}
                      alt="Community"
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h2 className="text-2xl font-bold">
                        {communities.find((c) => c.id === selectedCommunity)?.name}
                      </h2>
                      <p className="text-gray-600 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {communities.find((c) => c.id === selectedCommunity)?.location}
                      </p>
                      <p className="text-sm text-gray-600 mt-1">
                        {communities.find((c) => c.id === selectedCommunity)?.description}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-blue-600">
                        {communities.find((c) => c.id === selectedCommunity)?.members}
                      </div>
                      <div className="text-sm text-gray-600">miembros</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Create Post */}
              <Card>
                <CardContent className="p-4">
                  {!showCreatePost ? (
                    <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setShowCreatePost(true)}>
                      <Avatar>
                        <AvatarImage src="/placeholder.svg" />
                        <AvatarFallback>TU</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 bg-gray-100 rounded-full px-4 py-2 text-gray-600">
                        ¿Qué quieres compartir con la comunidad?
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-start space-x-3">
                        <Avatar>
                          <AvatarImage src="/placeholder.svg" />
                          <AvatarFallback>TU</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <Textarea
                            placeholder="Comparte algo con tu comunidad..."
                            value={newPost}
                            onChange={(e) => setNewPost(e.target.value)}
                            rows={3}
                          />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Camera className="h-4 w-4 mr-2" />
                            Foto
                          </Button>
                          <Button variant="outline" size="sm">
                            <MapPin className="h-4 w-4 mr-2" />
                            Ubicación
                          </Button>
                        </div>
                        <div className="flex space-x-2">
                          <Button variant="outline" onClick={() => setShowCreatePost(false)}>
                            Cancelar
                          </Button>
                          <Button>
                            <Send className="h-4 w-4 mr-2" />
                            Publicar
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Posts Feed */}
              <div className="space-y-6">
                {posts.map((post) => (
                  <Card key={post.id}>
                    <CardContent className="p-6">
                      {/* Post Header */}
                      <div className="flex items-start space-x-3 mb-4">
                        <Avatar>
                          <AvatarImage src={post.user.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{post.user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center space-x-2">
                            <h3 className="font-semibold">{post.user.name}</h3>
                            {post.user.verified && <Shield className="h-4 w-4 text-blue-600" />}
                            <Badge variant="secondary" className="text-xs">
                              {post.user.role}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600">
                            {post.community} • {post.time}
                          </p>
                        </div>
                      </div>

                      {/* Post Content */}
                      <div className="mb-4">
                        <p className="text-gray-900 mb-3">{post.content}</p>

                        {post.images.length > 0 && (
                          <div className="grid grid-cols-1 gap-2">
                            {post.images.map((image, index) => (
                              <img
                                key={index}
                                src={image || "/placeholder.svg"}
                                alt="Post image"
                                className="w-full h-64 object-cover rounded-lg"
                              />
                            ))}
                          </div>
                        )}

                        {post.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2 mt-3">
                            {post.tags.map((tag, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                #{tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Post Actions */}
                      <div className="flex items-center justify-between pt-3 border-t">
                        <div className="flex space-x-6">
                          <Button variant="ghost" size="sm" className="text-gray-600">
                            <ThumbsUp className="h-4 w-4 mr-2" />
                            {post.likes}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-600">
                            <MessageSquare className="h-4 w-4 mr-2" />
                            {post.comments}
                          </Button>
                          <Button variant="ghost" size="sm" className="text-gray-600">
                            <Share2 className="h-4 w-4 mr-2" />
                            {post.shares}
                          </Button>
                        </div>
                        <Button variant="ghost" size="sm">
                          <Heart className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Load More */}
              <div className="text-center">
                <Button variant="outline">Cargar más publicaciones</Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
