"use client"

import React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Search,
  UserCheck,
  FileText,
  Key,
  Home,
  Shield,
  Smartphone,
  Clock,
  DollarSign,
  Users,
  CheckCircle,
  ArrowRight,
  Play,
  Star,
  Quote,
  Zap,
  Brain,
  Camera,
} from "lucide-react"
import Link from "next/link"

const tenantSteps = [
  {
    step: 1,
    title: "Regístrate y Verifica tu Perfil",
    description: "Crea tu cuenta y completa la verificación digital en minutos",
    icon: UserCheck,
    details: [
      "Registro con email o redes sociales",
      "Verificación de identidad con cédula",
      "Validación de ingresos",
      "Referencias personales",
    ],
    time: "5-10 minutos",
    color: "bg-blue-100 text-blue-600",
  },
  {
    step: 2,
    title: "Busca tu Hogar Ideal",
    description: "Utiliza nuestros filtros inteligentes y recomendaciones de IA",
    icon: Search,
    details: [
      "Búsqueda avanzada con filtros",
      "Recomendaciones personalizadas",
      "Tours virtuales 360°",
      "Comparación de propiedades",
    ],
    time: "Variable",
    color: "bg-green-100 text-green-600",
  },
  {
    step: 3,
    title: "Aplica y Negocia",
    description: "Envía tu aplicación y negocia términos directamente con el propietario",
    icon: FileText,
    details: [
      "Aplicación con un clic",
      "Chat directo con propietario",
      "Negociación de términos",
      "Programación de visitas",
    ],
    time: "1-3 días",
    color: "bg-purple-100 text-purple-600",
  },
  {
    step: 4,
    title: "Firma Digital y Mudanza",
    description: "Firma tu contrato digitalmente y recibe las llaves",
    icon: Key,
    details: [
      "Contrato digital legalmente válido",
      "Firma electrónica segura",
      "Pago del depósito online",
      "Coordinación de entrega de llaves",
    ],
    time: "1-2 días",
    color: "bg-yellow-100 text-yellow-600",
  },
]

const ownerSteps = [
  {
    step: 1,
    title: "Publica tu Propiedad",
    description: "Crea una publicación atractiva con fotos profesionales y tour virtual",
    icon: Camera,
    details: [
      "Formulario guiado paso a paso",
      "Fotografía profesional opcional",
      "Tour virtual 360° gratuito",
      "Optimización automática de precio",
    ],
    time: "15-30 minutos",
    color: "bg-blue-100 text-blue-600",
  },
  {
    step: 2,
    title: "Recibe Aplicaciones Verificadas",
    description: "Solo inquilinos verificados pueden aplicar a tu propiedad",
    icon: Shield,
    details: [
      "Inquilinos pre-verificados",
      "Análisis de solvencia automático",
      "Puntuación de confiabilidad",
      "Historial de arrendamientos",
    ],
    time: "Automático",
    color: "bg-green-100 text-green-600",
  },
  {
    step: 3,
    title: "Selecciona tu Inquilino",
    description: "Revisa perfiles, chatea y selecciona al mejor candidato",
    icon: Users,
    details: [
      "Perfiles detallados de candidatos",
      "Chat integrado seguro",
      "Verificación de referencias",
      "Herramientas de comparación",
    ],
    time: "2-7 días",
    color: "bg-purple-100 text-purple-600",
  },
  {
    step: 4,
    title: "Gestiona tu Propiedad",
    description: "Administra pagos, contratos y mantenimiento desde un solo lugar",
    icon: DollarSign,
    details: [
      "Pagos automáticos mensuales",
      "Gestión de contratos digitales",
      "Reportes de mantenimiento",
      "Analytics de rendimiento",
    ],
    time: "Continuo",
    color: "bg-yellow-100 text-yellow-600",
  },
]

const features = [
  {
    icon: Shield,
    title: "100% Seguro",
    description: "Verificación completa de usuarios y transacciones protegidas",
  },
  {
    icon: Zap,
    title: "Proceso Rápido",
    description: "Desde búsqueda hasta firma en menos de una semana",
  },
  {
    icon: Brain,
    title: "IA Personalizada",
    description: "Recomendaciones inteligentes basadas en tus preferencias",
  },
  {
    icon: Smartphone,
    title: "100% Digital",
    description: "Todo el proceso desde tu celular, sin papeleos",
  },
]

const testimonials = [
  {
    name: "María González",
    role: "Propietaria",
    image: "/placeholder.svg?height=60&width=60",
    quote:
      "En solo 3 días encontré el inquilino perfecto para mi apartamento. La verificación digital me dio mucha tranquilidad.",
    rating: 5,
  },
  {
    name: "Carlos Mendoza",
    role: "Inquilino",
    image: "/placeholder.svg?height=60&width=60",
    quote:
      "El tour virtual me permitió ver la propiedad desde casa y el proceso de aplicación fue súper fácil. ¡Recomendado!",
    rating: 5,
  },
  {
    name: "Ana Sofía López",
    role: "Inmobiliaria",
    image: "/placeholder.svg?height=60&width=60",
    quote:
      "Como inmobiliaria, RentaColombia nos ha permitido gestionar más propiedades con menos tiempo y mayor eficiencia.",
    rating: 5,
  },
]

const stats = [
  { number: "50,000+", label: "Usuarios Activos" },
  { number: "15,000+", label: "Propiedades" },
  { number: "98%", label: "Satisfacción" },
  { number: "24/7", label: "Soporte" },
]

export default function HowItWorksPage() {
  const [activeTab, setActiveTab] = useState("tenant")
  const [selectedStep, setSelectedStep] = useState(1)

  const currentSteps = activeTab === "tenant" ? tenantSteps : ownerSteps

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/properties" className="text-gray-600 hover:text-blue-600">
              Propiedades
            </Link>
            <Link href="/how-it-works" className="text-blue-600 font-medium">
              Cómo Funciona
            </Link>
            <Link href="/about" className="text-gray-600 hover:text-blue-600">
              Nosotros
            </Link>
          </nav>
          <div className="flex items-center space-x-4">
            <Link href="/auth/login">
              <Button variant="ghost">Iniciar Sesión</Button>
            </Link>
            <Link href="/auth/register">
              <Button>Comenzar</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-4 bg-blue-100 text-blue-800">
            <Zap className="h-4 w-4 mr-1" />
            Proceso 100% Digital
          </Badge>
          <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
            ¿Cómo Funciona
            <span className="text-blue-600 block">RentaColombia?</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Revolucionamos el proceso de arrendamiento con tecnología de punta. Desde la búsqueda hasta la firma del
            contrato, todo 100% digital y seguro.
          </p>
          <Button size="lg" className="text-lg px-8 py-4">
            <Play className="mr-2 h-5 w-5" />
            Ver Video Explicativo
          </Button>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            {stats.map((stat, index) => (
              <div key={index}>
                <div className="text-4xl font-bold mb-2">{stat.number}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Proceso Paso a Paso</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Selecciona tu perfil para ver cómo funciona el proceso específicamente para ti
            </p>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="max-w-6xl mx-auto">
            <TabsList className="grid w-full grid-cols-2 mb-12">
              <TabsTrigger value="tenant" className="text-lg py-3">
                <Users className="h-5 w-5 mr-2" />
                Soy Inquilino
              </TabsTrigger>
              <TabsTrigger value="owner" className="text-lg py-3">
                <Home className="h-5 w-5 mr-2" />
                Soy Propietario
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tenant">
              <ProcessSteps steps={tenantSteps} selectedStep={selectedStep} setSelectedStep={setSelectedStep} />
            </TabsContent>

            <TabsContent value="owner">
              <ProcessSteps steps={ownerSteps} selectedStep={selectedStep} setSelectedStep={setSelectedStep} />
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">¿Por qué Elegir RentaColombia?</h2>
            <p className="text-gray-600">Ventajas que nos hacen únicos en el mercado</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="text-center hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className={`w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center bg-blue-100`}>
                    <feature.icon className="h-8 w-8 text-blue-600" />
                  </div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Lo que Dicen Nuestros Usuarios</h2>
            <p className="text-gray-600">Experiencias reales de quienes ya usan RentaColombia</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="relative">
                <CardContent className="p-6">
                  <Quote className="h-8 w-8 text-blue-600 mb-4" />
                  <p className="text-gray-700 mb-6 italic">"{testimonial.quote}"</p>
                  <div className="flex items-center space-x-4">
                    <img
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <div className="font-semibold">{testimonial.name}</div>
                      <div className="text-sm text-gray-600">{testimonial.role}</div>
                      <div className="flex mt-1">
                        {[...Array(testimonial.rating)].map((_, i) => (
                          <Star key={i} className="h-4 w-4 text-yellow-400 fill-current" />
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">¿Listo para Comenzar?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Únete a miles de colombianos que ya transformaron su experiencia de arrendamiento
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth/register?type=tenant">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4">
                <Users className="mr-2 h-5 w-5" />
                Buscar Propiedad
              </Button>
            </Link>
            <Link href="/auth/register?type=owner">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 text-white border-white hover:bg-white hover:text-blue-600"
              >
                <Home className="mr-2 h-5 w-5" />
                Publicar Propiedad
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <Home className="h-6 w-6" />
                <span className="text-xl font-bold">RentaColombia</span>
              </div>
              <p className="text-gray-400">La plataforma digital líder en arrendamientos para Colombia</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Plataforma</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/properties">Propiedades</Link>
                </li>
                <li>
                  <Link href="/how-it-works">Cómo Funciona</Link>
                </li>
                <li>
                  <Link href="/pricing">Precios</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Soporte</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/help">Centro de Ayuda</Link>
                </li>
                <li>
                  <Link href="/contact">Contacto</Link>
                </li>
                <li>
                  <Link href="/legal">Legal</Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4">Empresa</h3>
              <ul className="space-y-2 text-gray-400">
                <li>
                  <Link href="/about">Nosotros</Link>
                </li>
                <li>
                  <Link href="/careers">Carreras</Link>
                </li>
                <li>
                  <Link href="/press">Prensa</Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 RentaColombia. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}

function ProcessSteps({
  steps,
  selectedStep,
  setSelectedStep,
}: {
  steps: any[]
  selectedStep: number
  setSelectedStep: (step: number) => void
}) {
  return (
    <div className="space-y-8">
      {/* Steps Navigation */}
      <div className="flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
        {steps.map((step, index) => (
          <div key={step.step} className="flex items-center">
            <button
              onClick={() => setSelectedStep(step.step)}
              className={`flex items-center space-x-3 p-4 rounded-lg transition-all ${
                selectedStep === step.step
                  ? "bg-blue-50 border-2 border-blue-200"
                  : "hover:bg-gray-50 border-2 border-transparent"
              }`}
            >
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center ${
                  selectedStep === step.step ? step.color : "bg-gray-100 text-gray-600"
                }`}
              >
                <step.icon className="h-6 w-6" />
              </div>
              <div className="text-left">
                <div className="font-semibold">Paso {step.step}</div>
                <div className="text-sm text-gray-600 hidden md:block">{step.time}</div>
              </div>
            </button>
            {index < steps.length - 1 && <ArrowRight className="h-6 w-6 text-gray-400 mx-4 hidden md:block" />}
          </div>
        ))}
      </div>

      {/* Selected Step Details */}
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <div className="flex items-center space-x-4">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${steps[selectedStep - 1].color}`}>
              {React.createElement(steps[selectedStep - 1].icon, { className: "h-8 w-8" })}
            </div>
            <div>
              <CardTitle className="text-2xl">{steps[selectedStep - 1].title}</CardTitle>
              <CardDescription className="text-lg">{steps[selectedStep - 1].description}</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h4 className="font-semibold mb-4">¿Qué incluye este paso?</h4>
              <ul className="space-y-3">
                {steps[selectedStep - 1].details.map((detail: string, index: number) => (
                  <li key={index} className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>{detail}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-gray-50 p-6 rounded-lg">
              <h4 className="font-semibold mb-4">Tiempo Estimado</h4>
              <div className="flex items-center space-x-2 mb-4">
                <Clock className="h-5 w-5 text-blue-600" />
                <span className="text-lg font-medium">{steps[selectedStep - 1].time}</span>
              </div>
              <p className="text-gray-600 mb-4">
                Este paso es{" "}
                {selectedStep === 1
                  ? "el primer paso"
                  : selectedStep === steps.length
                    ? "el último paso"
                    : "un paso intermedio"}{" "}
                del proceso.
              </p>
              <Button className="w-full">{selectedStep === 1 ? "Comenzar Ahora" : "Continuar Proceso"}</Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
