"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import {
  Heart,
  MessageCircle,
  Share2,
  Home,
  MapPin,
  Camera,
  Send,
  UserPlus,
  UserCheck,
  Star,
  Building2,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useInView } from "react-intersection-observer"

interface SocialPost {
  post_id: string
  user_id: string
  user_name: string
  user_avatar?: string
  user_type: string
  user_verified: boolean
  property_id?: string
  property_title?: string
  property_price?: number
  property_city?: string
  property_images?: string[]
  content?: string
  post_images?: string[]
  post_type: string
  likes_count: number
  comments_count: number
  shares_count: number
  created_at: string
  user_liked: boolean
  user_following: boolean
}

export default function FeedPage() {
  const [posts, setPosts] = useState<SocialPost[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const [newPost, setNewPost] = useState("")
  const [showCreatePost, setShowCreatePost] = useState(false)
  const [user, setUser] = useState<any>(null)

  const { ref, inView } = useInView({
    threshold: 0,
    triggerOnce: false,
  })

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
    fetchPosts()
  }, [])

  useEffect(() => {
    if (inView && hasMore && !loadingMore) {
      loadMorePosts()
    }
  }, [inView, hasMore, loadingMore])

  const fetchPosts = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/social/feed")
      const result = await response.json()

      if (result.success) {
        setPosts(result.data)
        setHasMore(result.data.length === 20)
      }
    } catch (error) {
      console.error("Error fetching posts:", error)
    } finally {
      setLoading(false)
    }
  }

  const loadMorePosts = async () => {
    try {
      setLoadingMore(true)
      const response = await fetch(`/api/social/feed?offset=${posts.length}`)
      const result = await response.json()

      if (result.success) {
        setPosts((prev) => [...prev, ...result.data])
        setHasMore(result.data.length === 20)
      }
    } catch (error) {
      console.error("Error loading more posts:", error)
    } finally {
      setLoadingMore(false)
    }
  }

  const handleLike = async (postId: string) => {
    if (!user) return

    try {
      const response = await fetch("/api/social/like", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId, type: "post" }),
      })

      const result = await response.json()
      if (result.success) {
        setPosts((prev) =>
          prev.map((post) =>
            post.post_id === postId
              ? {
                  ...post,
                  user_liked: result.liked,
                  likes_count: result.liked ? post.likes_count + 1 : post.likes_count - 1,
                }
              : post,
          ),
        )
      }
    } catch (error) {
      console.error("Error liking post:", error)
    }
  }

  const handleFollow = async (userId: string) => {
    if (!user) return

    try {
      const response = await fetch("/api/social/follow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agencyId: userId }),
      })

      const result = await response.json()
      if (result.success) {
        setPosts((prev) =>
          prev.map((post) => (post.user_id === userId ? { ...post, user_following: result.following } : post)),
        )
      }
    } catch (error) {
      console.error("Error following user:", error)
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60))

    if (diffInHours < 1) return "Hace unos minutos"
    if (diffInHours < 24) return `Hace ${diffInHours}h`
    if (diffInHours < 168) return `Hace ${Math.floor(diffInHours / 24)}d`
    return date.toLocaleDateString()
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando feed...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link href="/agencies">
              <Button variant="ghost" size="sm">
                <Building2 className="h-4 w-4 mr-2" />
                Inmobiliarias
              </Button>
            </Link>
            <Link href="/properties">
              <Button variant="ghost" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Propiedades
              </Button>
            </Link>
            {user && (
              <Avatar>
                <AvatarImage src={user.avatar_url || "/placeholder.svg"} />
                <AvatarFallback>{user.name?.charAt(0)}</AvatarFallback>
              </Avatar>
            )}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        {/* Create Post */}
        {user && (
          <Card className="mb-6">
            <CardContent className="p-4">
              {!showCreatePost ? (
                <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setShowCreatePost(true)}>
                  <Avatar>
                    <AvatarImage src={user.avatar_url || "/placeholder.svg"} />
                    <AvatarFallback>{user.name?.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 bg-gray-100 rounded-full px-4 py-3 text-gray-600 hover:bg-gray-200 transition-colors">
                    ¿Qué quieres compartir sobre propiedades?
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-start space-x-3">
                    <Avatar>
                      <AvatarImage src={user.avatar_url || "/placeholder.svg"} />
                      <AvatarFallback>{user.name?.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <Textarea
                        placeholder="Comparte algo interesante..."
                        value={newPost}
                        onChange={(e) => setNewPost(e.target.value)}
                        rows={3}
                      />
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Camera className="h-4 w-4 mr-2" />
                        Foto
                      </Button>
                      <Button variant="outline" size="sm">
                        <Home className="h-4 w-4 mr-2" />
                        Propiedad
                      </Button>
                    </div>
                    <div className="flex space-x-2">
                      <Button variant="outline" onClick={() => setShowCreatePost(false)}>
                        Cancelar
                      </Button>
                      <Button>
                        <Send className="h-4 w-4 mr-2" />
                        Publicar
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Posts Feed */}
        <div className="space-y-6">
          {posts.map((post) => (
            <Card key={post.post_id} className="overflow-hidden">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center space-x-3">
                    <Link href={`/agencies/${post.user_id}`}>
                      <Avatar className="cursor-pointer">
                        <AvatarImage src={post.user_avatar || "/placeholder.svg"} />
                        <AvatarFallback>{post.user_name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    </Link>
                    <div>
                      <div className="flex items-center space-x-2">
                        <Link href={`/agencies/${post.user_id}`} className="font-semibold hover:underline">
                          {post.user_name}
                        </Link>
                        {post.user_verified && (
                          <Badge variant="secondary" className="text-xs">
                            <Star className="h-3 w-3 mr-1" />
                            Verificado
                          </Badge>
                        )}
                        <Badge variant="outline" className="text-xs">
                          {post.user_type === "AGENCY" ? "Inmobiliaria" : "Propietario"}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">{formatTimeAgo(post.created_at)}</p>
                    </div>
                  </div>

                  {user && post.user_id !== user.id && (post.user_type === "AGENCY" || post.user_type === "OWNER") && (
                    <Button
                      variant={post.user_following ? "outline" : "default"}
                      size="sm"
                      onClick={() => handleFollow(post.user_id)}
                    >
                      {post.user_following ? (
                        <>
                          <UserCheck className="h-4 w-4 mr-2" />
                          Siguiendo
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Seguir
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Post Content */}
                {post.content && <p className="text-gray-900 mb-4">{post.content}</p>}

                {/* Property Card */}
                {post.property_id && (
                  <Link href={`/properties/${post.property_id}`}>
                    <div className="border rounded-lg p-4 hover:bg-gray-50 transition-colors cursor-pointer mb-4">
                      <div className="flex space-x-4">
                        {post.property_images && post.property_images.length > 0 && (
                          <Image
                            src={post.property_images[0] || "/placeholder.svg"}
                            alt={post.property_title || "Propiedad"}
                            width={120}
                            height={90}
                            className="rounded-lg object-cover"
                          />
                        )}
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg mb-2">{post.property_title}</h3>
                          <div className="flex items-center text-gray-600 mb-2">
                            <MapPin className="h-4 w-4 mr-1" />
                            {post.property_city}
                          </div>
                          <div className="text-2xl font-bold text-blue-600">
                            ${post.property_price?.toLocaleString()}/mes
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                )}

                {/* Post Images */}
                {post.post_images && post.post_images.length > 0 && (
                  <div className="grid grid-cols-1 gap-2 mb-4">
                    {post.post_images.map((image, index) => (
                      <Image
                        key={index}
                        src={image || "/placeholder.svg"}
                        alt="Post image"
                        width={600}
                        height={400}
                        className="w-full rounded-lg object-cover"
                      />
                    ))}
                  </div>
                )}

                {/* Post Actions */}
                <div className="flex items-center justify-between pt-3 border-t">
                  <div className="flex space-x-6">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleLike(post.post_id)}
                      className={`${post.user_liked ? "text-red-500" : "text-gray-600"}`}
                    >
                      <Heart className={`h-4 w-4 mr-2 ${post.user_liked ? "fill-current" : ""}`} />
                      {post.likes_count}
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-600">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      {post.comments_count}
                    </Button>
                    <Button variant="ghost" size="sm" className="text-gray-600">
                      <Share2 className="h-4 w-4 mr-2" />
                      {post.shares_count}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Loading More */}
        {hasMore && (
          <div ref={ref} className="text-center py-8">
            {loadingMore ? (
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            ) : (
              <p className="text-gray-600">Cargando más publicaciones...</p>
            )}
          </div>
        )}

        {!hasMore && posts.length > 0 && (
          <div className="text-center py-8">
            <p className="text-gray-600">¡Has visto todas las publicaciones!</p>
          </div>
        )}
      </div>
    </div>
  )
}
