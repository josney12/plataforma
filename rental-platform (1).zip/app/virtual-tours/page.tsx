"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Camera,
  Play,
  Pause,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize,
  Home,
  Eye,
  Clock,
  MapPin,
  Ruler,
  Share2,
  Heart,
  Calendar,
} from "lucide-react"
import Link from "next/link"

const virtualTours = [
  {
    id: 1,
    property: "Apartamento Moderno Chapinero",
    location: "Chapinero, Bogotá",
    price: 1200000,
    duration: "8:30",
    views: 245,
    created: "2025-01-15",
    thumbnail: "/placeholder.svg?height=200&width=300",
    rooms: ["Sala", "Cocina", "Habitación Principal", "Habitación 2", "Baño Principal", "Baño Social", "Balcón"],
    features: ["360°", "4K", "Medición AR", "Sonido Ambiental"],
  },
  {
    id: 2,
    property: "Casa Familiar El Poblado",
    location: "El Poblado, Medellín",
    price: 1800000,
    duration: "12:45",
    views: 189,
    created: "2025-01-10",
    thumbnail: "/placeholder.svg?height=200&width=300",
    rooms: ["Sala", "Comedor", "Cocina", "Habitación Principal", "Habitación 2", "Habitación 3", "Estudio", "Jardín"],
    features: ["360°", "4K", "Medición AR", "Tour Guiado"],
  },
]

export default function VirtualToursPage() {
  const [selectedTour, setSelectedTour] = useState<number | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentRoom, setCurrentRoom] = useState(0)

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/properties" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <Badge className="bg-purple-100 text-purple-800">
            <Camera className="h-4 w-4 mr-1" />
            Tours Virtuales 360°
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {!selectedTour ? (
            <>
              {/* Header */}
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Tours Virtuales 360°</h1>
                <p className="text-gray-600">
                  Explora propiedades desde la comodidad de tu hogar con tecnología inmersiva
                </p>
              </div>

              {/* Featured Tour */}
              <Card className="mb-8 overflow-hidden">
                <div className="relative">
                  <img
                    src="/placeholder.svg?height=400&width=800"
                    alt="Tour destacado"
                    className="w-full h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <Button
                      size="lg"
                      className="bg-white text-black hover:bg-gray-100"
                      onClick={() => setSelectedTour(1)}
                    >
                      <Play className="h-6 w-6 mr-2" />
                      Iniciar Tour Virtual
                    </Button>
                  </div>
                  <Badge className="absolute top-4 left-4 bg-red-600">Tour Destacado</Badge>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h3 className="text-xl font-bold">Apartamento Moderno Chapinero</h3>
                    <p className="text-sm opacity-90">Chapinero, Bogotá • $1,200,000/mes</p>
                  </div>
                </div>
              </Card>

              {/* Tours Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {virtualTours.map((tour) => (
                  <Card key={tour.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative">
                      <img
                        src={tour.thumbnail || "/placeholder.svg"}
                        alt={tour.property}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all flex items-center justify-center">
                        <Button
                          className="opacity-0 hover:opacity-100 transition-opacity"
                          onClick={() => setSelectedTour(tour.id)}
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Ver Tour
                        </Button>
                      </div>
                      <Badge className="absolute top-2 right-2 bg-black bg-opacity-70 text-white">
                        <Clock className="h-3 w-3 mr-1" />
                        {tour.duration}
                      </Badge>
                      <Button variant="ghost" size="sm" className="absolute top-2 left-2 bg-white bg-opacity-80">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>

                    <CardHeader>
                      <CardTitle className="text-lg line-clamp-1">{tour.property}</CardTitle>
                      <div className="flex items-center text-sm text-gray-600">
                        <MapPin className="h-4 w-4 mr-1" />
                        {tour.location}
                      </div>
                    </CardHeader>

                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-2xl font-bold text-blue-600">${tour.price.toLocaleString()}</span>
                          <div className="flex items-center text-sm text-gray-600">
                            <Eye className="h-4 w-4 mr-1" />
                            {tour.views} vistas
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {tour.features.map((feature, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex justify-between items-center pt-2">
                          <span className="text-sm text-gray-600">{tour.rooms.length} espacios</span>
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Share2 className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Calendar className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            <VirtualTourViewer
              tour={virtualTours.find((t) => t.id === selectedTour)!}
              onClose={() => setSelectedTour(null)}
              isPlaying={isPlaying}
              setIsPlaying={setIsPlaying}
              currentRoom={currentRoom}
              setCurrentRoom={setCurrentRoom}
            />
          )}
        </div>
      </div>
    </div>
  )
}

function VirtualTourViewer({
  tour,
  onClose,
  isPlaying,
  setIsPlaying,
  currentRoom,
  setCurrentRoom,
}: {
  tour: any
  onClose: () => void
  isPlaying: boolean
  setIsPlaying: (playing: boolean) => void
  currentRoom: number
  setCurrentRoom: (room: number) => void
}) {
  const [zoom, setZoom] = useState(1)
  const [rotation, setRotation] = useState(0)
  const [showMeasurements, setShowMeasurements] = useState(false)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">{tour.property}</h1>
          <p className="text-gray-600 flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            {tour.location}
          </p>
        </div>
        <Button variant="outline" onClick={onClose}>
          Cerrar Tour
        </Button>
      </div>

      {/* Main Viewer */}
      <Card className="overflow-hidden">
        <div className="relative bg-black" style={{ height: "60vh" }}>
          {/* 360° Viewer Placeholder */}
          <div className="absolute inset-0 flex items-center justify-center">
            <img
              src="/placeholder.svg?height=600&width=800"
              alt={`${tour.property} - ${tour.rooms[currentRoom]}`}
              className="max-w-full max-h-full object-contain"
              style={{ transform: `scale(${zoom}) rotate(${rotation}deg)` }}
            />
          </div>

          {/* Overlay Controls */}
          <div className="absolute top-4 left-4 flex space-x-2">
            <Button variant="secondary" size="sm" onClick={() => setIsPlaying(!isPlaying)}>
              {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setRotation(0)}>
              <RotateCcw className="h-4 w-4" />
            </Button>
          </div>

          <div className="absolute top-4 right-4 flex space-x-2">
            <Button variant="secondary" size="sm" onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}>
              <ZoomOut className="h-4 w-4" />
            </Button>
            <Button variant="secondary" size="sm" onClick={() => setZoom(Math.min(3, zoom + 0.1))}>
              <ZoomIn className="h-4 w-4" />
            </Button>
            <Button variant="secondary" size="sm">
              <Maximize className="h-4 w-4" />
            </Button>
          </div>

          {/* Room Navigation */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2">
            <div className="bg-black bg-opacity-70 rounded-lg p-2">
              <div className="flex space-x-2">
                {tour.rooms.map((room, index) => (
                  <Button
                    key={index}
                    variant={currentRoom === index ? "default" : "secondary"}
                    size="sm"
                    onClick={() => setCurrentRoom(index)}
                    className="text-white"
                  >
                    {room}
                  </Button>
                ))}
              </div>
            </div>
          </div>

          {/* Measurement Points */}
          {showMeasurements && (
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/3 left-1/4 bg-yellow-400 text-black px-2 py-1 rounded text-xs">3.2m</div>
              <div className="absolute top-2/3 right-1/3 bg-yellow-400 text-black px-2 py-1 rounded text-xs">2.8m</div>
            </div>
          )}
        </div>
      </Card>

      {/* Controls Panel */}
      <div className="grid lg:grid-cols-4 gap-6">
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Controles del Tour</span>
                <Badge>{tour.rooms[currentRoom]}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-4">
                <Button
                  variant="outline"
                  className="flex items-center justify-center"
                  onClick={() => setShowMeasurements(!showMeasurements)}
                >
                  <Ruler className="h-4 w-4 mr-2" />
                  {showMeasurements ? "Ocultar" : "Mostrar"} Medidas
                </Button>
                <Button variant="outline" className="flex items-center justify-center">
                  <Camera className="h-4 w-4 mr-2" />
                  Captura
                </Button>
                <Button variant="outline" className="flex items-center justify-center">
                  <Share2 className="h-4 w-4 mr-2" />
                  Compartir
                </Button>
                <Button variant="outline" className="flex items-center justify-center">
                  <Calendar className="h-4 w-4 mr-2" />
                  Agendar Visita
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Información</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-2xl font-bold text-blue-600">${tour.price.toLocaleString()}</div>
                <div className="text-sm text-gray-600">por mes</div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Duración:</span>
                  <span className="font-medium">{tour.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Vistas:</span>
                  <span className="font-medium">{tour.views}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Espacios:</span>
                  <span className="font-medium">{tour.rooms.length}</span>
                </div>
              </div>

              <div className="space-y-2">
                <Button className="w-full">Contactar Propietario</Button>
                <Button variant="outline" className="w-full">
                  <Heart className="h-4 w-4 mr-2" />
                  Guardar
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
