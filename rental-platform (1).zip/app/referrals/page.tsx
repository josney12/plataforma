"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Progress } from "@/components/ui/progress"
import {
  Gift,
  Users,
  DollarSign,
  Trophy,
  Star,
  Home,
  Share2,
  Copy,
  Mail,
  MessageSquare,
  Crown,
  Target,
  Zap,
  Award,
} from "lucide-react"
import Link from "next/link"

const referralData = {
  totalReferrals: 12,
  successfulReferrals: 8,
  totalEarnings: 480000,
  currentLevel: "Gold",
  nextLevel: "Platinum",
  pointsToNext: 150,
  currentPoints: 850,
  referralCode: "RENT2025-MARIA",
}

const levels = [
  { name: "Bronze", minPoints: 0, benefits: ["5% comisión", "Soporte básico"], color: "bg-orange-100 text-orange-800" },
  {
    name: "Silver",
    minPoints: 200,
    benefits: ["7% comisión", "Soporte prioritario"],
    color: "bg-gray-100 text-gray-800",
  },
  { name: "Gold", minPoints: 500, benefits: ["10% comisión", "Acceso VIP"], color: "bg-yellow-100 text-yellow-800" },
  {
    name: "Platinum",
    minPoints: 1000,
    benefits: ["15% comisión", "Gestor personal"],
    color: "bg-purple-100 text-purple-800",
  },
  {
    name: "Diamond",
    minPoints: 2000,
    benefits: ["20% comisión", "Beneficios exclusivos"],
    color: "bg-blue-100 text-blue-800",
  },
]

const recentReferrals = [
  {
    id: 1,
    name: "Carlos Mendoza",
    email: "carlos@email.com",
    status: "completed",
    date: "2025-01-15",
    earnings: 60000,
    type: "tenant",
  },
  {
    id: 2,
    name: "Ana López",
    email: "ana@email.com",
    status: "pending",
    date: "2025-01-20",
    earnings: 0,
    type: "owner",
  },
  {
    id: 3,
    name: "Diego Ramírez",
    email: "diego@email.com",
    status: "completed",
    date: "2025-01-10",
    earnings: 60000,
    type: "tenant",
  },
]

const rewards = [
  { points: 100, reward: "Descuento 10% en servicios premium", claimed: true },
  { points: 250, reward: "Consulta gratuita con experto inmobiliario", claimed: true },
  { points: 500, reward: "Fotografía profesional gratuita", claimed: false },
  { points: 750, reward: "Tour virtual 360° gratuito", claimed: false },
  { points: 1000, reward: "Gestión completa de propiedad por 1 mes", claimed: false },
]

export default function ReferralsPage() {
  const [shareMethod, setShareMethod] = useState("link")
  const [email, setEmail] = useState("")

  const copyReferralCode = () => {
    navigator.clipboard.writeText(`https://rentacolombia.com/ref/${referralData.referralCode}`)
    alert("¡Enlace copiado al portapapeles!")
  }

  const getCurrentLevel = () => {
    return (
      levels.find(
        (level) =>
          referralData.currentPoints >= level.minPoints &&
          referralData.currentPoints < (levels[levels.indexOf(level) + 1]?.minPoints || Number.POSITIVE_INFINITY),
      ) || levels[0]
    )
  }

  const getNextLevel = () => {
    const currentLevelIndex = levels.findIndex((level) => level.name === getCurrentLevel().name)
    return levels[currentLevelIndex + 1] || null
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <Badge className="bg-gradient-to-r from-yellow-100 to-orange-100 text-orange-800">
            <Gift className="h-4 w-4 mr-1" />
            Programa de Referidos
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Programa de Referidos</h1>
            <p className="text-gray-600">Gana dinero invitando amigos y familiares a RentaColombia</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-8">
              {/* Stats Overview */}
              <div className="grid md:grid-cols-4 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Referidos</CardTitle>
                    <Users className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{referralData.totalReferrals}</div>
                    <p className="text-xs text-muted-foreground">{referralData.successfulReferrals} exitosos</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Ganancias Totales</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">${referralData.totalEarnings.toLocaleString()}</div>
                    <p className="text-xs text-muted-foreground">Este mes: $120,000</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Nivel Actual</CardTitle>
                    <Trophy className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">{referralData.currentLevel}</div>
                    <p className="text-xs text-muted-foreground">{referralData.currentPoints} puntos</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Tasa de Éxito</CardTitle>
                    <Target className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">
                      {Math.round((referralData.successfulReferrals / referralData.totalReferrals) * 100)}%
                    </div>
                    <p className="text-xs text-muted-foreground">Muy buena</p>
                  </CardContent>
                </Card>
              </div>

              {/* Share Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Share2 className="h-5 w-5 mr-2" />
                    Comparte y Gana
                  </CardTitle>
                  <CardDescription>Invita amigos y gana hasta $60,000 por cada referido exitoso</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg">
                    <h3 className="font-semibold text-lg mb-2">Tu Código de Referido</h3>
                    <div className="flex items-center space-x-2 mb-4">
                      <Input
                        value={`https://rentacolombia.com/ref/${referralData.referralCode}`}
                        readOnly
                        className="flex-1"
                      />
                      <Button onClick={copyReferralCode}>
                        <Copy className="h-4 w-4 mr-2" />
                        Copiar
                      </Button>
                    </div>
                    <p className="text-sm text-gray-600">
                      Comparte este enlace y gana cuando alguien se registre y complete una transacción
                    </p>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <Button variant="outline" className="flex items-center justify-center p-6 h-auto">
                      <div className="text-center">
                        <Share2 className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                        <div className="font-medium">Redes Sociales</div>
                        <div className="text-sm text-gray-600">WhatsApp, Facebook, Twitter</div>
                      </div>
                    </Button>

                    <Button variant="outline" className="flex items-center justify-center p-6 h-auto">
                      <div className="text-center">
                        <Mail className="h-8 w-8 mx-auto mb-2 text-green-600" />
                        <div className="font-medium">Email</div>
                        <div className="text-sm text-gray-600">Envía invitaciones por correo</div>
                      </div>
                    </Button>

                    <Button variant="outline" className="flex items-center justify-center p-6 h-auto">
                      <div className="text-center">
                        <MessageSquare className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                        <div className="font-medium">Mensaje Directo</div>
                        <div className="text-sm text-gray-600">SMS o mensajería</div>
                      </div>
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <h4 className="font-medium">Invitar por Email</h4>
                    <div className="flex space-x-2">
                      <Input
                        placeholder="email@ejemplo.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        className="flex-1"
                      />
                      <Button>Enviar Invitación</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Recent Referrals */}
              <Card>
                <CardHeader>
                  <CardTitle>Referidos Recientes</CardTitle>
                  <CardDescription>Historial de tus invitaciones</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentReferrals.map((referral) => (
                      <div key={referral.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                            <Users className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium">{referral.name}</div>
                            <div className="text-sm text-gray-600">{referral.email}</div>
                            <div className="text-xs text-gray-500">{referral.date}</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge
                            className={
                              referral.status === "completed"
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }
                          >
                            {referral.status === "completed" ? "Completado" : "Pendiente"}
                          </Badge>
                          {referral.earnings > 0 && (
                            <div className="text-sm font-medium text-green-600 mt-1">
                              +${referral.earnings.toLocaleString()}
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Level Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Crown className="h-5 w-5 mr-2 text-yellow-500" />
                    Progreso de Nivel
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <Badge className={getCurrentLevel().color} size="lg">
                      {getCurrentLevel().name}
                    </Badge>
                    <div className="text-2xl font-bold mt-2">{referralData.currentPoints}</div>
                    <div className="text-sm text-gray-600">puntos acumulados</div>
                  </div>

                  {getNextLevel() && (
                    <>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progreso a {getNextLevel()?.name}</span>
                          <span>{referralData.pointsToNext} puntos restantes</span>
                        </div>
                        <Progress
                          value={
                            ((referralData.currentPoints - getCurrentLevel().minPoints) /
                              ((getNextLevel()?.minPoints || 0) - getCurrentLevel().minPoints)) *
                            100
                          }
                        />
                      </div>

                      <div className="bg-blue-50 p-3 rounded-lg">
                        <h4 className="font-medium text-blue-900 mb-2">Beneficios {getNextLevel()?.name}</h4>
                        <ul className="text-sm text-blue-800 space-y-1">
                          {getNextLevel()?.benefits.map((benefit, index) => (
                            <li key={index} className="flex items-center">
                              <Star className="h-3 w-3 mr-2" />
                              {benefit}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              {/* Rewards */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Gift className="h-5 w-5 mr-2" />
                    Recompensas
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {rewards.map((reward, index) => (
                    <div
                      key={index}
                      className={`p-3 border rounded-lg ${
                        reward.claimed
                          ? "bg-gray-50 opacity-60"
                          : referralData.currentPoints >= reward.points
                            ? "bg-green-50 border-green-200"
                            : ""
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">{reward.points} puntos</span>
                        {reward.claimed ? (
                          <Badge variant="secondary">Reclamado</Badge>
                        ) : referralData.currentPoints >= reward.points ? (
                          <Button size="sm">Reclamar</Button>
                        ) : (
                          <Badge variant="outline">Bloqueado</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-600">{reward.reward}</p>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* How it Works */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">¿Cómo Funciona?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        1
                      </div>
                      <div>
                        <div className="font-medium text-sm">Comparte tu enlace</div>
                        <div className="text-xs text-gray-600">Invita amigos con tu código único</div>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        2
                      </div>
                      <div>
                        <div className="font-medium text-sm">Ellos se registran</div>
                        <div className="text-xs text-gray-600">Crean cuenta usando tu enlace</div>
                      </div>
                    </div>

                    <div className="flex items-start space-x-3">
                      <div className="w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        3
                      </div>
                      <div>
                        <div className="font-medium text-sm">Tú ganas</div>
                        <div className="text-xs text-gray-600">Recibes comisión por cada transacción</div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-yellow-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Zap className="h-4 w-4 text-yellow-600" />
                      <span className="text-sm font-medium text-yellow-800">¡Gana hasta $60,000 por referido!</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Leaderboard */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Award className="h-5 w-5 mr-2" />
                    Top Referidores
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {[
                    { name: "María G.", referrals: 45, position: 1 },
                    { name: "Carlos M.", referrals: 38, position: 2 },
                    { name: "Ana L.", referrals: 32, position: 3 },
                    { name: "Tú", referrals: referralData.successfulReferrals, position: 8 },
                  ].map((user, index) => (
                    <div
                      key={index}
                      className={`flex items-center justify-between p-2 rounded ${
                        user.name === "Tú" ? "bg-blue-50 border border-blue-200" : ""
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                            user.position <= 3 ? "bg-yellow-100 text-yellow-800" : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {user.position}
                        </div>
                        <span className="text-sm font-medium">{user.name}</span>
                      </div>
                      <span className="text-sm text-gray-600">{user.referrals} referidos</span>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
