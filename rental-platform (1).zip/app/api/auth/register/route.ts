import { type NextRequest, NextResponse } from "next/server"
import { createUser, createSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, name, phone, userType } = body

    // Validate required fields
    if (!email || !password || !name || !userType) {
      return NextResponse.json(
        { success: false, error: "Todos los campos requeridos deben ser completados" },
        { status: 400 },
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json({ success: false, error: "Formato de email inválido" }, { status: 400 })
    }

    // Validate password strength
    if (password.length < 8) {
      return NextResponse.json(
        { success: false, error: "La contraseña debe tener al menos 8 caracteres" },
        { status: 400 },
      )
    }

    // Create user
    const user = await createUser({
      email: email.toLowerCase(),
      password,
      name,
      phone,
      user_type: userType,
    })

    // Create session
    const sessionToken = await createSession(user.id)

    // Set cookie
    const response = NextResponse.json({
      success: true,
      data: { user, token: sessionToken },
    })

    response.cookies.set("session", sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 7 * 24 * 60 * 60, // 7 days
    })

    return response
  } catch (error: any) {
    console.error("Registration error:", error)
    return NextResponse.json({ success: false, error: error.message || "Error interno del servidor" }, { status: 500 })
  }
}
