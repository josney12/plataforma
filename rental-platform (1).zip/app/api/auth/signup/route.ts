import { type NextRequest, NextResponse } from "next/server"
import { signUp } from "@/lib/api"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password, name, phone, userType } = body

    const result = await signUp(email, password, {
      name,
      phone,
      user_type: userType,
    })

    return NextResponse.json({ success: true, data: result })
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 })
  }
}
