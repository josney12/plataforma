import { type NextRequest, NextResponse } from "next/server"
import { getAgencyProfile } from "@/lib/social"
import { validateSession } from "@/lib/auth"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Get viewer from session if available
    let viewerId: string | undefined
    const sessionToken = request.cookies.get("session")?.value
    if (sessionToken) {
      try {
        const user = await validateSession(sessionToken)
        viewerId = user?.id
      } catch (error) {
        // Continue without viewer context
      }
    }

    const agency = await getAgencyProfile(params.id, viewerId)

    if (!agency) {
      return NextResponse.json({ success: false, error: "Inmobiliaria no encontrada" }, { status: 404 })
    }

    return NextResponse.json({ success: true, data: agency })
  } catch (error: any) {
    console.error("Get agency profile error:", error)
    return NextResponse.json({ success: false, error: "Error al obtener perfil de inmobiliaria" }, { status: 500 })
  }
}
