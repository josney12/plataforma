import { type NextRequest, NextResponse } from "next/server"
import { getAgencies } from "@/lib/social"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    const agencies = await getAgencies(limit, offset)

    return NextResponse.json({ success: true, data: agencies })
  } catch (error: any) {
    console.error("Get agencies error:", error)
    return NextResponse.json({ success: false, error: "Error al obtener inmobiliarias" }, { status: 500 })
  }
}
