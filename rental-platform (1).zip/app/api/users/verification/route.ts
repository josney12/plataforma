import { type NextRequest, NextResponse } from "next/server"

// Simulación de datos para desarrollo
const mockVerificationSteps = [
  {
    id: "identity",
    title: "Verificación de Identidad",
    description: "Sube tu cédula de ciudadanía",
    status: "pending",
    icon: "User",
  },
  {
    id: "income",
    title: "Verificación de Ingresos",
    description: "Certificado laboral o extractos bancarios",
    status: "pending",
    icon: "CreditCard",
  },
  {
    id: "references",
    title: "Referencias Personales",
    description: "Contactos de referencia",
    status: "pending",
    icon: "Phone",
  },
  {
    id: "background",
    title: "Antecedentes Crediticios",
    description: "Consulta en centrales de riesgo",
    status: "pending",
    icon: "FileText",
  },
]

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // En un entorno de desarrollo, usamos datos simulados
    // En producción, esto se conectaría a la base de datos real
    return NextResponse.json({
      verified: false,
      verificationStatus: "not_started",
      steps: mockVerificationSteps,
      documents: [],
    })
  } catch (error) {
    console.error("Verification status fetch error:", error)
    // Aseguramos que siempre devolvemos un JSON válido
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
