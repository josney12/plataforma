import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

export async function PUT(request: NextRequest) {
  try {
    const formData = await request.formData()
    const userId = formData.get("userId") as string
    const name = formData.get("name") as string
    const phone = formData.get("phone") as string
    const address = formData.get("address") as string
    const bio = formData.get("bio") as string
    const occupation = formData.get("occupation") as string
    const preferencesJson = formData.get("preferences") as string
    const preferences = JSON.parse(preferencesJson || "{}")
    const avatar = formData.get("avatar") as File | null

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    // Validate user exists
    const { data: existingUser, error: userError } = await supabase.from("users").select("id").eq("id", userId).single()

    if (userError || !existingUser) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    // Handle avatar upload if provided
    let avatarUrl = null
    if (avatar) {
      const fileExt = avatar.name.split(".").pop()
      const fileName = `${userId}-${Date.now()}.${fileExt}`
      const { data: uploadData, error: uploadError } = await supabase.storage.from("avatars").upload(fileName, avatar)

      if (uploadError) {
        console.error("Avatar upload error:", uploadError)
        return NextResponse.json({ error: "Failed to upload avatar" }, { status: 500 })
      }

      // Get public URL
      const { data: publicUrlData } = supabase.storage.from("avatars").getPublicUrl(fileName)
      avatarUrl = publicUrlData.publicUrl
    }

    // Update user profile
    const updateData: any = {
      name,
      phone,
      address,
      bio,
      occupation,
      preferences,
      updated_at: new Date().toISOString(),
    }

    if (avatarUrl) {
      updateData.avatar_url = avatarUrl
    }

    const { data, error } = await supabase.from("users").update(updateData).eq("id", userId).select().single()

    if (error) {
      console.error("Profile update error:", error)
      return NextResponse.json({ error: "Failed to update profile" }, { status: 500 })
    }

    return NextResponse.json({
      message: "Profile updated successfully",
      user: data,
    })
  } catch (error) {
    console.error("Profile update error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function GET(request: NextRequest) {
  try {
    const userId = request.nextUrl.searchParams.get("userId")

    if (!userId) {
      return NextResponse.json({ error: "User ID is required" }, { status: 400 })
    }

    const { data, error } = await supabase.from("users").select("*").eq("id", userId).single()

    if (error) {
      return NextResponse.json({ error: "User not found" }, { status: 404 })
    }

    return NextResponse.json({ user: data })
  } catch (error) {
    console.error("Profile fetch error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
