import { type NextRequest, NextResponse } from "next/server"
import { getProperty, updateProperty } from "@/lib/api"

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get("userId") || undefined

    const property = await getProperty(params.id, userId)

    return NextResponse.json({ success: true, data: property })
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()

    const property = await updateProperty(params.id, body)

    return NextResponse.json({ success: true, data: property })
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 400 })
  }
}
