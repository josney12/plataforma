import { type NextRequest, NextResponse } from "next/server"
import { getProperties, createProperty } from "@/lib/properties"
import { validateSession } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)

    const filters = {
      city: searchParams.get("city") || undefined,
      minPrice: searchParams.get("minPrice") ? Number.parseInt(searchParams.get("minPrice")!) : undefined,
      maxPrice: searchParams.get("maxPrice") ? Number.parseInt(searchParams.get("maxPrice")!) : undefined,
      propertyType: searchParams.get("propertyType") || undefined,
      bedrooms: searchParams.get("bedrooms") ? Number.parseInt(searchParams.get("bedrooms")!) : undefined,
      limit: searchParams.get("limit") ? Number.parseInt(searchParams.get("limit")!) : 20,
      offset: searchParams.get("offset") ? Number.parseInt(searchParams.get("offset")!) : 0,
    }

    const properties = await getProperties(filters)

    return NextResponse.json({ success: true, data: properties })
  } catch (error: any) {
    console.error("Get properties error:", error)
    return NextResponse.json({ success: false, error: "Error al obtener propiedades" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session")?.value

    if (!sessionToken) {
      return NextResponse.json({ success: false, error: "No autorizado" }, { status: 401 })
    }

    const user = await validateSession(sessionToken)
    if (!user || (user.user_type !== "OWNER" && user.user_type !== "AGENCY")) {
      return NextResponse.json({ success: false, error: "No autorizado para crear propiedades" }, { status: 403 })
    }

    const body = await request.json()

    // Validate required fields
    const requiredFields = ["title", "property_type", "price", "address", "city"]
    for (const field of requiredFields) {
      if (!body[field]) {
        return NextResponse.json({ success: false, error: `El campo ${field} es requerido` }, { status: 400 })
      }
    }

    const propertyData = {
      ...body,
      owner_id: user.id,
      price: Number.parseInt(body.price),
      deposit: body.deposit ? Number.parseInt(body.deposit) : null,
      admin_fee: body.admin_fee ? Number.parseInt(body.admin_fee) : null,
      bedrooms: body.bedrooms ? Number.parseInt(body.bedrooms) : null,
      bathrooms: body.bathrooms ? Number.parseFloat(body.bathrooms) : null,
      area: body.area ? Number.parseInt(body.area) : null,
      available: true,
    }

    const property = await createProperty(propertyData)

    return NextResponse.json({ success: true, data: property })
  } catch (error: any) {
    console.error("Create property error:", error)
    return NextResponse.json({ success: false, error: "Error al crear propiedad" }, { status: 500 })
  }
}
