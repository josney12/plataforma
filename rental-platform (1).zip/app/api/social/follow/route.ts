import { type NextRequest, NextResponse } from "next/server"
import { followAgency } from "@/lib/social"
import { validateSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session")?.value

    if (!sessionToken) {
      return NextResponse.json({ success: false, error: "No autorizado" }, { status: 401 })
    }

    const user = await validateSession(sessionToken)
    if (!user) {
      return NextResponse.json({ success: false, error: "Sesión inválida" }, { status: 401 })
    }

    const body = await request.json()
    const { agencyId } = body

    if (!agencyId) {
      return NextResponse.json({ success: false, error: "ID de agencia requerido" }, { status: 400 })
    }

    if (agencyId === user.id) {
      return NextResponse.json({ success: false, error: "No puedes seguirte a ti mismo" }, { status: 400 })
    }

    const following = await followAgency(user.id, agencyId)

    return NextResponse.json({ success: true, following })
  } catch (error: any) {
    console.error("Follow agency error:", error)
    return NextResponse.json({ success: false, error: "Error al seguir agencia" }, { status: 500 })
  }
}
