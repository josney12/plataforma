import { type NextRequest, NextResponse } from "next/server"
import { togglePostLike, togglePropertyLike } from "@/lib/social"
import { validateSession } from "@/lib/auth"

export async function POST(request: NextRequest) {
  try {
    const sessionToken = request.cookies.get("session")?.value

    if (!sessionToken) {
      return NextResponse.json({ success: false, error: "No autorizado" }, { status: 401 })
    }

    const user = await validateSession(sessionToken)
    if (!user) {
      return NextResponse.json({ success: false, error: "Sesión inválida" }, { status: 401 })
    }

    const body = await request.json()
    const { postId, propertyId, type } = body

    let liked: boolean

    if (type === "post" && postId) {
      liked = await togglePostLike(user.id, postId)
    } else if (type === "property" && propertyId) {
      liked = await togglePropertyLike(user.id, propertyId)
    } else {
      return NextResponse.json({ success: false, error: "Tipo de like inválido" }, { status: 400 })
    }

    return NextResponse.json({ success: true, liked })
  } catch (error: any) {
    console.error("Toggle like error:", error)
    return NextResponse.json({ success: false, error: "Error al procesar like" }, { status: 500 })
  }
}
