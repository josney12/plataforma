import { type NextRequest, NextResponse } from "next/server"
import { getSocialFeed } from "@/lib/social"
import { validateSession } from "@/lib/auth"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Number.parseInt(searchParams.get("limit") || "20")
    const offset = Number.parseInt(searchParams.get("offset") || "0")

    // Get user from session if available
    let userId: string | undefined
    const sessionToken = request.cookies.get("session")?.value
    if (sessionToken) {
      try {
        const user = await validateSession(sessionToken)
        userId = user?.id
      } catch (error) {
        // Continue without user context
      }
    }

    const posts = await getSocialFeed(userId, limit, offset)

    return NextResponse.json({ success: true, data: posts })
  } catch (error: any) {
    console.error("Get social feed error:", error)
    return NextResponse.json({ success: false, error: "Error al obtener el feed" }, { status: 500 })
  }
}
