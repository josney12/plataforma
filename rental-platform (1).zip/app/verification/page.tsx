"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { toast } from "@/components/ui/use-toast"
import {
  Shield,
  Upload,
  CheckCircle,
  Clock,
  AlertCircle,
  Camera,
  CreditCard,
  FileText,
  User,
  Phone,
  ArrowLeft,
  Eye,
  Loader2,
} from "lucide-react"
import Link from "next/link"

interface VerificationStep {
  id: string
  title: string
  description: string
  icon: any
  status: "pending" | "in-progress" | "completed" | "rejected"
  rejectionReason?: string
}

interface VerificationDocument {
  id: string
  stepId: string
  file?: File
  preview: string
  name: string
  uploadProgress?: number
  status?: "uploading" | "complete" | "error"
}

export default function VerificationPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [verificationSteps, setVerificationSteps] = useState<VerificationStep[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [uploadedDocuments, setUploadedDocuments] = useState<VerificationDocument[]>([])
  const [verificationScore, setVerificationScore] = useState(0)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [references, setReferences] = useState([
    { name: "", phone: "", email: "", relation: "Familiar" },
    { name: "", phone: "", email: "", relation: "Familiar" },
  ])

  useEffect(() => {
    // Get user from localStorage
    const userData = localStorage.getItem("user")
    if (!userData) {
      // Para desarrollo, creamos un usuario simulado si no existe
      const mockUser = { id: "user_123", name: "Usuario Prueba", email: "usuario@ejemplo.com" }
      localStorage.setItem("user", JSON.stringify(mockUser))
      setUser(mockUser)
      fetchVerificationStatus(mockUser.id)
      return
    }

    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
      fetchVerificationStatus(parsedUser.id)
    } catch (error) {
      console.error("Error parsing user data:", error)
      // Para desarrollo, creamos un usuario simulado si hay error
      const mockUser = { id: "user_123", name: "Usuario Prueba", email: "usuario@ejemplo.com" }
      localStorage.setItem("user", JSON.stringify(mockUser))
      setUser(mockUser)
      fetchVerificationStatus(mockUser.id)
    }
  }, [router])

  const fetchVerificationStatus = async (userId: string) => {
    try {
      setLoading(true)
      const response = await fetch(`/api/users/verification?userId=${userId}`)

      if (!response.ok) {
        const errorText = await response.text()
        console.error("Error response:", errorText)

        try {
          // Intentamos parsear como JSON por si acaso
          const errorData = JSON.parse(errorText)
          throw new Error(errorData.error || "Error fetching verification status")
        } catch (parseError) {
          // Si no es JSON, usamos el texto directamente
          throw new Error(`Error ${response.status}: ${errorText.substring(0, 100)}`)
        }
      }

      const data = await response.json()

      if (data.steps && Array.isArray(data.steps)) {
        // Map the steps with proper icons
        const stepsWithIcons = data.steps.map((step: any) => ({
          ...step,
          icon: getStepIconComponent(step.icon),
        }))

        setVerificationSteps(stepsWithIcons)

        // Calculate current step
        const firstIncompleteStep = stepsWithIcons.findIndex((step: VerificationStep) => step.status !== "completed")
        setCurrentStep(firstIncompleteStep >= 0 ? firstIncompleteStep : 0)

        // Calculate verification score
        const completedSteps = stepsWithIcons.filter((step: VerificationStep) => step.status === "completed").length
        setVerificationScore(Math.round((completedSteps / stepsWithIcons.length) * 100))
      }

      // Load any existing documents
      if (data.documents && Array.isArray(data.documents)) {
        // Transform API documents to our format
        const formattedDocs = data.documents.map((doc: any) => ({
          id: doc.id || `doc_${Math.random().toString(36).substr(2, 9)}`,
          stepId: doc.step_id,
          name: doc.file_name || "Documento",
          preview: doc.file_url || "/placeholder.svg?height=100&width=100",
          status: "complete",
        }))
        setUploadedDocuments(formattedDocs)
      }
    } catch (error: any) {
      console.error("Error fetching verification status:", error)
      toast({
        title: "Error",
        description: error.message || "No se pudo cargar el estado de verificación",
        variant: "destructive",
      })

      // En caso de error, inicializamos con datos simulados para desarrollo
      const defaultSteps = [
        {
          id: "identity",
          title: "Verificación de Identidad",
          description: "Sube tu cédula de ciudadanía",
          icon: User,
          status: "pending",
        },
        {
          id: "income",
          title: "Verificación de Ingresos",
          description: "Certificado laboral o extractos bancarios",
          icon: CreditCard,
          status: "pending",
        },
        {
          id: "references",
          title: "Referencias Personales",
          description: "Contactos de referencia",
          icon: Phone,
          status: "pending",
        },
        {
          id: "background",
          title: "Antecedentes Crediticios",
          description: "Consulta en centrales de riesgo",
          icon: FileText,
          status: "pending",
        },
      ]

      setVerificationSteps(defaultSteps)
      setVerificationScore(0)
    } finally {
      setLoading(false)
    }
  }

  const getStepIconComponent = (iconName: string) => {
    switch (iconName) {
      case "User":
        return User
      case "CreditCard":
        return CreditCard
      case "Phone":
        return Phone
      case "FileText":
        return FileText
      default:
        return CheckCircle
    }
  }

  const handleFileUpload = (stepId: string, files: FileList | null) => {
    if (!files || files.length === 0) return

    const newDocuments: VerificationDocument[] = Array.from(files).map((file) => ({
      id: `doc_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      stepId,
      file,
      preview: URL.createObjectURL(file),
      name: file.name,
      uploadProgress: 0,
      status: "uploading",
    }))

    setUploadedDocuments((prev) => [...prev, ...newDocuments])

    // Simulate upload progress
    newDocuments.forEach((doc) => {
      simulateUpload(doc.id)
    })
  }

  const simulateUpload = (docId: string) => {
    let progress = 0
    const interval = setInterval(() => {
      progress += Math.floor(Math.random() * 15) + 5
      if (progress >= 100) {
        progress = 100
        clearInterval(interval)
        setUploadedDocuments((prev) =>
          prev.map((doc) => (doc.id === docId ? { ...doc, uploadProgress: 100, status: "complete" } : doc)),
        )
      } else {
        setUploadedDocuments((prev) =>
          prev.map((doc) => (doc.id === docId ? { ...doc, uploadProgress: progress } : doc)),
        )
      }
    }, 500)
  }

  const handleReferenceChange = (index: number, field: string, value: string) => {
    const updatedReferences = [...references]
    updatedReferences[index] = { ...updatedReferences[index], [field]: value }
    setReferences(updatedReferences)
  }

  const handleSubmitStep = async () => {
    if (!user) return

    const currentStepData = verificationSteps[currentStep]
    setIsSubmitting(true)

    try {
      // Prepare data based on step type
      const payload: any = {
        userId: user.id,
        stepId: currentStepData.id,
      }

      if (currentStepData.id === "references") {
        payload.references = references
      } else if (currentStepData.id === "background") {
        // Background check data
        payload.cedula = (document.getElementById("cedula-check") as HTMLInputElement)?.value
        payload.authorized = (document.getElementById("authorize-check") as HTMLInputElement)?.checked
      } else if (currentStepData.id === "income") {
        // Income verification data
        payload.incomeType = (document.getElementById("income-type") as HTMLSelectElement)?.value
        payload.monthlyIncome = (document.getElementById("monthly-income") as HTMLInputElement)?.value
      }

      // Get documents for this step
      const stepDocuments = uploadedDocuments.filter(
        (doc) => doc.stepId === currentStepData.id && doc.status === "complete",
      )

      if ((currentStepData.id === "identity" || currentStepData.id === "income") && stepDocuments.length === 0) {
        throw new Error("Debes subir al menos un documento para continuar")
      }

      // En desarrollo, simulamos la respuesta exitosa
      // En producción, esto enviaría los datos al servidor
      setTimeout(() => {
        // Update step status
        const updatedSteps = [...verificationSteps]
        updatedSteps[currentStep] = {
          ...updatedSteps[currentStep],
          status: "in-progress",
        }
        setVerificationSteps(updatedSteps)

        // Move to next step if available
        if (currentStep < verificationSteps.length - 1) {
          setCurrentStep(currentStep + 1)
        }

        // Update verification score
        const completedSteps = updatedSteps.filter((step) => step.status === "completed").length
        const inProgressSteps = updatedSteps.filter((step) => step.status === "in-progress").length
        setVerificationScore(Math.round(((completedSteps + inProgressSteps * 0.5) / updatedSteps.length) * 100))

        toast({
          title: "Paso completado",
          description: "Tu información ha sido enviada para verificación",
        })

        setIsSubmitting(false)
      }, 1500)
    } catch (error: any) {
      console.error("Error submitting verification step:", error)
      toast({
        title: "Error",
        description: error.message || "No se pudo enviar la información. Intenta nuevamente.",
        variant: "destructive",
      })
      setIsSubmitting(false)
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="h-5 w-5 text-green-600" />
      case "in-progress":
        return <Clock className="h-5 w-5 text-yellow-600" />
      case "rejected":
        return <AlertCircle className="h-5 w-5 text-red-600" />
      default:
        return <AlertCircle className="h-5 w-5 text-gray-400" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800"
      case "in-progress":
        return "bg-yellow-100 text-yellow-800"
      case "rejected":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "Completado"
      case "in-progress":
        return "En Proceso"
      case "rejected":
        return "Rechazado"
      default:
        return "Pendiente"
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/profile" className="flex items-center space-x-2">
            <ArrowLeft className="h-5 w-5" />
            <span>Volver al Perfil</span>
          </Link>
          <Badge className="bg-blue-100 text-blue-800">
            <Shield className="h-4 w-4 mr-1" />
            Verificación Digital
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-4">Verificación Digital</h1>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Completa tu verificación para acceder a todas las funcionalidades y generar confianza en la comunidad
            </p>
          </div>

          {/* Verification Score */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Tu Puntuación de Confianza</span>
                <span className="text-3xl font-bold text-blue-600">{verificationScore}%</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Progress value={verificationScore} className="mb-4" />
              <div className="grid md:grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-green-600">
                    {verificationSteps.filter((step) => step.status === "completed").length}
                  </div>
                  <div className="text-sm text-gray-600">Verificaciones Completadas</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-yellow-600">
                    {verificationSteps.filter((step) => step.status === "in-progress").length}
                  </div>
                  <div className="text-sm text-gray-600">En Proceso</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-400">
                    {verificationSteps.filter((step) => step.status === "pending").length}
                  </div>
                  <div className="text-sm text-gray-600">Pendientes</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Verification Steps */}
          <div className="space-y-6">
            {verificationSteps.map((step, index) => (
              <Card key={step.id} className={`overflow-hidden ${index === currentStep ? "ring-2 ring-blue-500" : ""}`}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full">
                        <step.icon className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="flex items-center space-x-2">
                          <span>{step.title}</span>
                          {getStatusIcon(step.status)}
                        </CardTitle>
                        <CardDescription>{step.description}</CardDescription>
                      </div>
                    </div>
                    <Badge className={getStatusColor(step.status)}>{getStatusText(step.status)}</Badge>
                  </div>
                </CardHeader>

                {step.status === "rejected" && (
                  <div className="px-6 py-2 bg-red-50 border-y border-red-100">
                    <p className="text-sm text-red-700 flex items-start">
                      <AlertCircle className="h-4 w-4 mr-2 mt-0.5 flex-shrink-0" />
                      <span>
                        <strong>Motivo del rechazo:</strong>{" "}
                        {step.rejectionReason ||
                          "Documentación insuficiente o ilegible. Por favor, vuelve a intentarlo."}
                      </span>
                    </p>
                  </div>
                )}

                {(step.status === "pending" || step.status === "rejected") && index === currentStep && (
                  <CardContent>
                    <div className="space-y-4">
                      {step.id === "identity" && (
                        <IdentityVerification
                          onFileUpload={(files) => handleFileUpload(step.id, files)}
                          documents={uploadedDocuments.filter((doc) => doc.stepId === step.id)}
                        />
                      )}
                      {step.id === "income" && (
                        <IncomeVerification
                          onFileUpload={(files) => handleFileUpload(step.id, files)}
                          documents={uploadedDocuments.filter((doc) => doc.stepId === step.id)}
                        />
                      )}
                      {step.id === "references" && (
                        <ReferencesVerification references={references} onReferenceChange={handleReferenceChange} />
                      )}
                      {step.id === "background" && <BackgroundCheck />}

                      <Button className="w-full" onClick={handleSubmitStep} disabled={isSubmitting}>
                        {isSubmitting ? (
                          <>
                            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                            Enviando...
                          </>
                        ) : (
                          "Enviar para Verificación"
                        )}
                      </Button>
                    </div>
                  </CardContent>
                )}

                {step.status === "completed" && (
                  <CardContent>
                    <div className="bg-green-50 p-4 rounded-lg flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                      <p className="text-green-800">
                        Verificación completada exitosamente el{" "}
                        {new Date().toLocaleDateString("es-CO", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </p>
                    </div>
                  </CardContent>
                )}

                {step.status === "in-progress" && (
                  <CardContent>
                    <div className="bg-yellow-50 p-4 rounded-lg flex items-center">
                      <Clock className="h-5 w-5 text-yellow-600 mr-3" />
                      <p className="text-yellow-800">
                        Tu información está siendo revisada. Este proceso puede tomar hasta 48 horas hábiles.
                      </p>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {/* Benefits */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle>Beneficios de la Verificación</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Acceso prioritario a propiedades premium</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Proceso de aplicación más rápido</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Mayor confianza de propietarios</span>
                  </div>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Descuentos en servicios premium</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Acceso a comunidades exclusivas</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <CheckCircle className="h-5 w-5 text-green-600" />
                    <span>Soporte prioritario 24/7</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function IdentityVerification({
  onFileUpload,
  documents,
}: {
  onFileUpload: (files: FileList | null) => void
  documents: VerificationDocument[]
}) {
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label>Cédula - Parte Frontal</Label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
            <Camera className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-2">Sube la parte frontal</p>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onFileUpload(e.target.files)}
              className="hidden"
              id="front-id"
            />
            <Label htmlFor="front-id" className="cursor-pointer">
              <Button variant="outline" size="sm" asChild>
                <span>Seleccionar Archivo</span>
              </Button>
            </Label>
          </div>
        </div>
        <div>
          <Label>Cédula - Parte Trasera</Label>
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center">
            <Camera className="h-8 w-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-2">Sube la parte trasera</p>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => onFileUpload(e.target.files)}
              className="hidden"
              id="back-id"
            />
            <Label htmlFor="back-id" className="cursor-pointer">
              <Button variant="outline" size="sm" asChild>
                <span>Seleccionar Archivo</span>
              </Button>
            </Label>
          </div>
        </div>
      </div>

      {documents.length > 0 && (
        <div className="space-y-2">
          <Label>Documentos Subidos</Label>
          <div className="space-y-2">
            {documents.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-2 text-blue-600" />
                  <span className="text-sm">{doc.name}</span>
                </div>
                <div className="flex items-center">
                  {doc.status === "uploading" && (
                    <div className="w-24 mr-2">
                      <Progress value={doc.uploadProgress} className="h-1" />
                    </div>
                  )}
                  {doc.status === "complete" && (
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="bg-blue-50 p-4 rounded-lg">
        <p className="text-sm text-blue-800">
          <Shield className="h-4 w-4 inline mr-1" />
          Tus documentos están protegidos con encriptación de nivel bancario
        </p>
      </div>
    </div>
  )
}

function IncomeVerification({
  onFileUpload,
  documents,
}: {
  onFileUpload: (files: FileList | null) => void
  documents: VerificationDocument[]
}) {
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="income-type">Tipo de Comprobante</Label>
          <select id="income-type" className="w-full p-2 border rounded-md">
            <option>Certificado Laboral</option>
            <option>Extractos Bancarios</option>
            <option>Declaración de Renta</option>
            <option>Certificado de Ingresos</option>
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="monthly-income">Ingresos Mensuales</Label>
          <Input id="monthly-income" placeholder="$2,500,000" />
        </div>
      </div>
      <div>
        <Label>Documentos de Soporte</Label>
        <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
          <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
          <p className="text-sm text-gray-600 mb-2">Arrastra tus documentos aquí</p>
          <input
            type="file"
            multiple
            accept=".pdf,.jpg,.png"
            onChange={(e) => onFileUpload(e.target.files)}
            className="hidden"
            id="income-docs"
          />
          <Label htmlFor="income-docs" className="cursor-pointer">
            <Button variant="outline" asChild>
              <span>Seleccionar Archivos</span>
            </Button>
          </Label>
        </div>
      </div>

      {documents.length > 0 && (
        <div className="space-y-2">
          <Label>Documentos Subidos</Label>
          <div className="space-y-2">
            {documents.map((doc) => (
              <div key={doc.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                <div className="flex items-center">
                  <FileText className="h-4 w-4 mr-2 text-blue-600" />
                  <span className="text-sm">{doc.name}</span>
                </div>
                <div className="flex items-center">
                  {doc.status === "uploading" && (
                    <div className="w-24 mr-2">
                      <Progress value={doc.uploadProgress} className="h-1" />
                    </div>
                  )}
                  {doc.status === "complete" && (
                    <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                      <Eye className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function ReferencesVerification({
  references,
  onReferenceChange,
}: {
  references: any[]
  onReferenceChange: (index: number, field: string, value: string) => void
}) {
  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h4 className="font-medium">Referencia Personal #1</h4>
          <div className="space-y-2">
            <Input
              placeholder="Nombre completo"
              value={references[0].name}
              onChange={(e) => onReferenceChange(0, "name", e.target.value)}
            />
            <Input
              placeholder="Teléfono"
              value={references[0].phone}
              onChange={(e) => onReferenceChange(0, "phone", e.target.value)}
            />
            <Input
              placeholder="Email"
              value={references[0].email}
              onChange={(e) => onReferenceChange(0, "email", e.target.value)}
            />
            <select
              className="w-full p-2 border rounded-md"
              value={references[0].relation}
              onChange={(e) => onReferenceChange(0, "relation", e.target.value)}
            >
              <option>Familiar</option>
              <option>Amigo</option>
              <option>Compañero de trabajo</option>
              <option>Otro</option>
            </select>
          </div>
        </div>
        <div className="space-y-4">
          <h4 className="font-medium">Referencia Personal #2</h4>
          <div className="space-y-2">
            <Input
              placeholder="Nombre completo"
              value={references[1].name}
              onChange={(e) => onReferenceChange(1, "name", e.target.value)}
            />
            <Input
              placeholder="Teléfono"
              value={references[1].phone}
              onChange={(e) => onReferenceChange(1, "phone", e.target.value)}
            />
            <Input
              placeholder="Email"
              value={references[1].email}
              onChange={(e) => onReferenceChange(1, "email", e.target.value)}
            />
            <select
              className="w-full p-2 border rounded-md"
              value={references[1].relation}
              onChange={(e) => onReferenceChange(1, "relation", e.target.value)}
            >
              <option>Familiar</option>
              <option>Amigo</option>
              <option>Compañero de trabajo</option>
              <option>Otro</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  )
}

function BackgroundCheck() {
  return (
    <div className="space-y-4">
      <div className="bg-yellow-50 p-4 rounded-lg">
        <h4 className="font-medium text-yellow-800 mb-2">Consulta Automática de Centrales de Riesgo</h4>
        <p className="text-sm text-yellow-700">
          Realizaremos una consulta en DataCrédito y CIFIN para verificar tu historial crediticio. Esta consulta no
          afecta tu puntaje crediticio.
        </p>
      </div>
      <div className="space-y-2">
        <Label htmlFor="cedula-check">Número de Cédula</Label>
        <Input id="cedula-check" placeholder="1234567890" />
      </div>
      <div className="flex items-center space-x-2">
        <input type="checkbox" id="authorize-check" />
        <Label htmlFor="authorize-check" className="text-sm">
          Autorizo la consulta en centrales de riesgo según la Ley 1266 de 2008
        </Label>
      </div>
    </div>
  )
}
