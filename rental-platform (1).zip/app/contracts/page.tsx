"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { FileText, Download, Eye, Edit, CheckCircle, Home, Calendar, User, PenTool, Shield } from "lucide-react"
import Link from "next/link"

const contracts = [
  {
    id: 1,
    property: "Apartamento Chapinero",
    tenant: "Carlos Mendoza",
    owner: "María González",
    startDate: "2025-02-01",
    endDate: "2026-02-01",
    monthlyRent: 1200000,
    deposit: 1200000,
    status: "active",
    signedDate: "2025-01-15",
    nextPayment: "2025-02-01",
  },
  {
    id: 2,
    property: "Casa El Poblado",
    tenant: "Ana Sofía López",
    owner: "Luis Herrera",
    startDate: "2025-03-01",
    endDate: "2026-03-01",
    monthlyRent: 1800000,
    deposit: 1800000,
    status: "pending",
    signedDate: null,
    nextPayment: null,
  },
]

export default function ContractsPage() {
  const [selectedContract, setSelectedContract] = useState<number | null>(null)
  const [isCreatingContract, setIsCreatingContract] = useState(false)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800">Activo</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendiente Firma</Badge>
      case "expired":
        return <Badge className="bg-red-100 text-red-800">Vencido</Badge>
      default:
        return <Badge variant="secondary">Borrador</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Button onClick={() => setIsCreatingContract(true)}>
              <FileText className="h-4 w-4 mr-2" />
              Nuevo Contrato
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Contratos Digitales</h1>
            <p className="text-gray-600">Gestiona todos tus contratos de arrendamiento de forma digital y segura</p>
          </div>

          {!isCreatingContract ? (
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Contracts List */}
              <div className="lg:col-span-2 space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Mis Contratos</CardTitle>
                    <CardDescription>Lista de todos tus contratos de arrendamiento</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {contracts.map((contract) => (
                        <div
                          key={contract.id}
                          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                            selectedContract === contract.id ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
                          }`}
                          onClick={() => setSelectedContract(contract.id)}
                        >
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-semibold">{contract.property}</h3>
                            {getStatusBadge(contract.status)}
                          </div>
                          <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                            <div>
                              <span className="font-medium">Inquilino:</span> {contract.tenant}
                            </div>
                            <div>
                              <span className="font-medium">Propietario:</span> {contract.owner}
                            </div>
                            <div>
                              <span className="font-medium">Inicio:</span> {contract.startDate}
                            </div>
                            <div>
                              <span className="font-medium">Renta:</span> ${contract.monthlyRent.toLocaleString()}
                            </div>
                          </div>
                          <div className="flex items-center justify-between mt-3">
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4 mr-1" />
                                Ver
                              </Button>
                              <Button variant="outline" size="sm">
                                <Download className="h-4 w-4 mr-1" />
                                Descargar
                              </Button>
                            </div>
                            {contract.status === "pending" && (
                              <Button size="sm">
                                <PenTool className="h-4 w-4 mr-1" />
                                Firmar
                              </Button>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Contract Details */}
              <div className="space-y-6">
                {selectedContract ? (
                  <ContractDetails contract={contracts.find((c) => c.id === selectedContract)!} />
                ) : (
                  <Card>
                    <CardContent className="text-center py-8">
                      <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">Selecciona un contrato para ver los detalles</p>
                    </CardContent>
                  </Card>
                )}

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Acciones Rápidas</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="h-4 w-4 mr-2" />
                      Plantillas de Contrato
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Shield className="h-4 w-4 mr-2" />
                      Asesoría Legal
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Calendar className="h-4 w-4 mr-2" />
                      Programar Renovación
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          ) : (
            <ContractCreator onCancel={() => setIsCreatingContract(false)} />
          )}
        </div>
      </div>
    </div>
  )
}

function ContractDetails({ contract }: { contract: any }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Detalles del Contrato</span>
          {contract.status === "active" && <CheckCircle className="h-5 w-5 text-green-600" />}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h4 className="font-medium mb-2">Información General</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Propiedad:</span>
              <span className="font-medium">{contract.property}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Duración:</span>
              <span className="font-medium">12 meses</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Estado:</span>
              {contract.status === "active" && <Badge className="bg-green-100 text-green-800">Activo</Badge>}
            </div>
          </div>
        </div>

        <Separator />

        <div>
          <h4 className="font-medium mb-2">Información Financiera</h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Renta Mensual:</span>
              <span className="font-medium">${contract.monthlyRent.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Depósito:</span>
              <span className="font-medium">${contract.deposit.toLocaleString()}</span>
            </div>
            {contract.nextPayment && (
              <div className="flex justify-between">
                <span className="text-gray-600">Próximo Pago:</span>
                <span className="font-medium">{contract.nextPayment}</span>
              </div>
            )}
          </div>
        </div>

        <Separator />

        <div>
          <h4 className="font-medium mb-2">Partes del Contrato</h4>
          <div className="space-y-2 text-sm">
            <div className="flex items-center space-x-2">
              <User className="h-4 w-4 text-gray-400" />
              <span className="text-gray-600">Inquilino:</span>
              <span className="font-medium">{contract.tenant}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Home className="h-4 w-4 text-gray-400" />
              <span className="text-gray-600">Propietario:</span>
              <span className="font-medium">{contract.owner}</span>
            </div>
          </div>
        </div>

        {contract.status === "active" && (
          <>
            <Separator />
            <div className="space-y-2">
              <Button variant="outline" className="w-full">
                <Edit className="h-4 w-4 mr-2" />
                Solicitar Modificación
              </Button>
              <Button variant="outline" className="w-full">
                <Calendar className="h-4 w-4 mr-2" />
                Renovar Contrato
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  )
}

function ContractCreator({ onCancel }: { onCancel: () => void }) {
  const [contractData, setContractData] = useState({
    propertyId: "",
    tenantId: "",
    startDate: "",
    duration: "12",
    monthlyRent: "",
    deposit: "",
    specialClauses: "",
  })

  return (
    <Card>
      <CardHeader>
        <CardTitle>Crear Nuevo Contrato</CardTitle>
        <CardDescription>Genera un contrato digital legalmente válido en Colombia</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid md:grid-cols-2 gap-6">
          <div className="space-y-2">
            <Label htmlFor="property">Propiedad</Label>
            <select
              id="property"
              className="w-full p-2 border rounded-md"
              value={contractData.propertyId}
              onChange={(e) => setContractData({ ...contractData, propertyId: e.target.value })}
            >
              <option value="">Seleccionar propiedad</option>
              <option value="1">Apartamento Chapinero</option>
              <option value="2">Casa El Poblado</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tenant">Inquilino</Label>
            <Input
              id="tenant"
              placeholder="Buscar inquilino por email o cédula"
              value={contractData.tenantId}
              onChange={(e) => setContractData({ ...contractData, tenantId: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="startDate">Fecha de Inicio</Label>
            <Input
              id="startDate"
              type="date"
              value={contractData.startDate}
              onChange={(e) => setContractData({ ...contractData, startDate: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="duration">Duración (meses)</Label>
            <select
              id="duration"
              className="w-full p-2 border rounded-md"
              value={contractData.duration}
              onChange={(e) => setContractData({ ...contractData, duration: e.target.value })}
            >
              <option value="6">6 meses</option>
              <option value="12">12 meses</option>
              <option value="24">24 meses</option>
            </select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rent">Renta Mensual (COP)</Label>
            <Input
              id="rent"
              type="number"
              placeholder="1200000"
              value={contractData.monthlyRent}
              onChange={(e) => setContractData({ ...contractData, monthlyRent: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="deposit">Depósito (COP)</Label>
            <Input
              id="deposit"
              type="number"
              placeholder="1200000"
              value={contractData.deposit}
              onChange={(e) => setContractData({ ...contractData, deposit: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="clauses">Cláusulas Especiales</Label>
          <Textarea
            id="clauses"
            placeholder="Agregar cláusulas adicionales al contrato..."
            rows={4}
            value={contractData.specialClauses}
            onChange={(e) => setContractData({ ...contractData, specialClauses: e.target.value })}
          />
        </div>

        <div className="bg-blue-50 p-4 rounded-lg">
          <h4 className="font-medium text-blue-800 mb-2">Características del Contrato Digital</h4>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Firma electrónica legalmente válida</li>
            <li>• Cumple con la legislación colombiana</li>
            <li>• Blockchain para inmutabilidad</li>
            <li>• Notificaciones automáticas de vencimiento</li>
          </ul>
        </div>

        <div className="flex justify-end space-x-4">
          <Button variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button>
            <FileText className="h-4 w-4 mr-2" />
            Generar Contrato
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
