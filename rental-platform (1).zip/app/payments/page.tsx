"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import {
  CreditCard,
  DollarSign,
  Calendar,
  CheckCircle,
  Home,
  Download,
  Shield,
  Smartphone,
  Building,
  TrendingUp,
} from "lucide-react"
import Link from "next/link"

const paymentHistory = [
  {
    id: 1,
    property: "Apartamento Chapinero",
    amount: 1200000,
    date: "2025-01-01",
    status: "completed",
    method: "PSE",
    type: "rent",
  },
  {
    id: 2,
    property: "Apartamento Chapinero",
    amount: 150000,
    date: "2025-01-01",
    status: "completed",
    method: "Tarjeta",
    type: "admin",
  },
  {
    id: 3,
    property: "Apartamento Chapinero",
    amount: 1200000,
    date: "2025-02-01",
    status: "pending",
    method: "PSE",
    type: "rent",
  },
]

const paymentMethods = [
  { id: "pse", name: "PSE", icon: Building, description: "Débito desde tu banco" },
  { id: "card", name: "Tarjeta", icon: CreditCard, description: "Crédito o débito" },
  { id: "nequi", name: "Nequi", icon: Smartphone, description: "Pago móvil" },
  { id: "daviplata", name: "DaviPlata", icon: Smartphone, description: "Billetera digital" },
]

export default function PaymentsPage() {
  const [selectedMethod, setSelectedMethod] = useState("pse")
  const [autoPayEnabled, setAutoPayEnabled] = useState(true)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge className="bg-green-100 text-green-800">Completado</Badge>
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800">Pendiente</Badge>
      case "failed":
        return <Badge className="bg-red-100 text-red-800">Fallido</Badge>
      default:
        return <Badge variant="secondary">Procesando</Badge>
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "rent":
        return "Arriendo"
      case "admin":
        return "Administración"
      case "deposit":
        return "Depósito"
      default:
        return "Otro"
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <Badge className="bg-green-100 text-green-800">
            <Shield className="h-4 w-4 mr-1" />
            Pagos Seguros
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Centro de Pagos</h1>
            <p className="text-gray-600">Gestiona todos tus pagos de arrendamiento de forma segura y automática</p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Payment Summary */}
              <div className="grid md:grid-cols-3 gap-6">
                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Próximo Pago</CardTitle>
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$1,350,000</div>
                    <p className="text-xs text-muted-foreground">Vence el 1 de Feb</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Pagado este Mes</CardTitle>
                    <DollarSign className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$1,350,000</div>
                    <p className="text-xs text-muted-foreground">+0% vs mes anterior</p>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium">Total Año</CardTitle>
                    <TrendingUp className="h-4 w-4 text-muted-foreground" />
                  </CardHeader>
                  <CardContent>
                    <div className="text-2xl font-bold">$16,200,000</div>
                    <p className="text-xs text-muted-foreground">Proyectado</p>
                  </CardContent>
                </Card>
              </div>

              {/* Quick Payment */}
              <Card>
                <CardHeader>
                  <CardTitle>Pago Rápido</CardTitle>
                  <CardDescription>Realiza un pago inmediato</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label>Propiedad</Label>
                      <select className="w-full p-2 border rounded-md">
                        <option>Apartamento Chapinero</option>
                        <option>Casa El Poblado</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <Label>Tipo de Pago</Label>
                      <select className="w-full p-2 border rounded-md">
                        <option>Arriendo Mensual</option>
                        <option>Administración</option>
                        <option>Servicios Públicos</option>
                        <option>Otro</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Monto (COP)</Label>
                    <Input id="amount" placeholder="1,200,000" />
                  </div>

                  <div className="space-y-4">
                    <Label>Método de Pago</Label>
                    <div className="grid grid-cols-2 gap-4">
                      {paymentMethods.map((method) => (
                        <div
                          key={method.id}
                          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                            selectedMethod === method.id ? "border-blue-500 bg-blue-50" : "hover:bg-gray-50"
                          }`}
                          onClick={() => setSelectedMethod(method.id)}
                        >
                          <div className="flex items-center space-x-3">
                            <method.icon className="h-6 w-6 text-blue-600" />
                            <div>
                              <div className="font-medium">{method.name}</div>
                              <div className="text-sm text-gray-600">{method.description}</div>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Button className="w-full" size="lg">
                    <CreditCard className="h-4 w-4 mr-2" />
                    Procesar Pago
                  </Button>
                </CardContent>
              </Card>

              {/* Payment History */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Historial de Pagos</CardTitle>
                      <CardDescription>Todos tus pagos realizados</CardDescription>
                    </div>
                    <Button variant="outline" size="sm">
                      <Download className="h-4 w-4 mr-2" />
                      Exportar
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {paymentHistory.map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
                            <DollarSign className="h-5 w-5 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium">{payment.property}</div>
                            <div className="text-sm text-gray-600">
                              {getTypeLabel(payment.type)} • {payment.method} • {payment.date}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">${payment.amount.toLocaleString()}</div>
                          {getStatusBadge(payment.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Auto Pay Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Pago Automático</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-medium">Estado</div>
                      <div className="text-sm text-gray-600">{autoPayEnabled ? "Activado" : "Desactivado"}</div>
                    </div>
                    <Button
                      variant={autoPayEnabled ? "destructive" : "default"}
                      size="sm"
                      onClick={() => setAutoPayEnabled(!autoPayEnabled)}
                    >
                      {autoPayEnabled ? "Desactivar" : "Activar"}
                    </Button>
                  </div>

                  {autoPayEnabled && (
                    <>
                      <Separator />
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Método:</span>
                          <span className="font-medium">PSE - Banco</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Día de pago:</span>
                          <span className="font-medium">1 de cada mes</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-600">Próximo:</span>
                          <span className="font-medium">1 Feb 2025</span>
                        </div>
                      </div>
                    </>
                  )}

                  <div className="bg-green-50 p-3 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm text-green-800">Nunca más te olvides de un pago</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment Reminders */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recordatorios</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Email</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">SMS</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Push</span>
                      <input type="checkbox" defaultChecked />
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-2">
                    <Label className="text-sm">Días de anticipación</Label>
                    <select className="w-full p-2 border rounded-md text-sm">
                      <option>3 días antes</option>
                      <option>5 días antes</option>
                      <option>7 días antes</option>
                    </select>
                  </div>
                </CardContent>
              </Card>

              {/* Security Info */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center">
                    <Shield className="h-5 w-5 mr-2" />
                    Seguridad
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Encriptación SSL 256-bit</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Certificado PCI DSS</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Monitoreo 24/7</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span>Cumple normativas SFC</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
