"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import {
  MapPin,
  Bed,
  Bath,
  Square,
  Heart,
  Star,
  Home,
  Phone,
  Mail,
  Calendar,
  Shield,
  Wifi,
  Car,
  Dumbbell,
  Waves,
  ChevronLeft,
  ChevronRight,
  Send,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

// Mock data for property details
const propertyData = {
  id: 1,
  title: "Apartamento Moderno en Chapinero",
  description:
    "Hermoso apartamento completamente amoblado con vista panorámica de la ciudad. Ubicado en una de las zonas más exclusivas de Bogotá, cuenta con acabados de primera calidad y acceso a todas las comodidades urbanas.",
  price: 1200000,
  location: "Chapinero, Bogotá",
  fullAddress: "Carrera 13 #85-32, Chapinero, Bogotá",
  bedrooms: 2,
  bathrooms: 2,
  area: 80,
  type: "Apartamento",
  images: [
    "/placeholder.svg?height=400&width=600",
    "/placeholder.svg?height=400&width=600",
    "/placeholder.svg?height=400&width=600",
    "/placeholder.svg?height=400&width=600",
  ],
  rating: 4.8,
  reviews: 12,
  owner: {
    name: "María González",
    avatar: "/placeholder-user.jpg",
    rating: 4.9,
    properties: 5,
    verified: true,
    responseTime: "2 horas",
    joinDate: "2022",
  },
  amenities: [
    { icon: Wifi, name: "WiFi" },
    { icon: Car, name: "Parqueadero" },
    { icon: Dumbbell, name: "Gimnasio" },
    { icon: Waves, name: "Piscina" },
    { icon: Shield, name: "Seguridad 24/7" },
  ],
  features: [
    "Aire acondicionado",
    "Calefacción",
    "Balcón con vista",
    "Cocina integral",
    "Closets empotrados",
    "Pisos en porcelanato",
  ],
  nearbyPlaces: [
    { name: "TransMilenio Calle 85", distance: "200m", type: "Transporte" },
    { name: "Centro Comercial Andino", distance: "500m", type: "Compras" },
    { name: "Parque de la 93", distance: "800m", type: "Recreación" },
    { name: "Hospital Militar", distance: "1.2km", type: "Salud" },
  ],
  available: true,
  availableFrom: "2025-02-01",
  deposit: 1200000,
  adminFee: 150000,
}

const reviews = [
  {
    id: 1,
    user: "Carlos Mendoza",
    avatar: "/placeholder-user.jpg",
    rating: 5,
    date: "Hace 2 semanas",
    comment:
      "Excelente apartamento, muy bien ubicado y la propietaria es muy amable. Todo tal como se describe en la publicación.",
  },
  {
    id: 2,
    user: "Ana Sofía López",
    avatar: "/placeholder-user.jpg",
    rating: 4,
    date: "Hace 1 mes",
    comment: "Muy buen lugar, cómodo y seguro. La vista es espectacular. Recomendado 100%.",
  },
  {
    id: 3,
    user: "Diego Ramírez",
    avatar: "/placeholder-user.jpg",
    rating: 5,
    date: "Hace 2 meses",
    comment: "Perfecto para profesionales. Excelente conectividad y cerca de todo lo que necesitas.",
  },
]

export default function PropertyDetailPage() {
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [message, setMessage] = useState("")
  const [isFavorite, setIsFavorite] = useState(false)

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev === propertyData.images.length - 1 ? 0 : prev + 1))
  }

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev === 0 ? propertyData.images.length - 1 : prev - 1))
  }

  const handleSendMessage = () => {
    if (message.trim()) {
      alert(`Mensaje enviado a ${propertyData.owner.name}: ${message}`)
      setMessage("")
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/properties" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link href="/auth/login">
              <Button>Iniciar Sesión</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Breadcrumb */}
        <div className="mb-6">
          <nav className="text-sm text-gray-600">
            <Link href="/" className="hover:text-blue-600">
              Inicio
            </Link>
            <span className="mx-2">/</span>
            <Link href="/properties" className="hover:text-blue-600">
              Propiedades
            </Link>
            <span className="mx-2">/</span>
            <span className="text-gray-900">{propertyData.title}</span>
          </nav>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <Card className="overflow-hidden">
              <div className="relative">
                <Image
                  src={propertyData.images[currentImageIndex] || "/placeholder.svg"}
                  alt={propertyData.title}
                  width={600}
                  height={400}
                  className="w-full h-96 object-cover"
                />

                {propertyData.images.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                      onClick={prevImage}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                      onClick={nextImage}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </>
                )}

                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {propertyData.images.map((_, index) => (
                    <button
                      key={index}
                      className={`w-2 h-2 rounded-full ${index === currentImageIndex ? "bg-white" : "bg-white/50"}`}
                      onClick={() => setCurrentImageIndex(index)}
                    />
                  ))}
                </div>

                <Button
                  variant="ghost"
                  size="sm"
                  className="absolute top-4 right-4 bg-white/80 hover:bg-white"
                  onClick={() => setIsFavorite(!isFavorite)}
                >
                  <Heart className={`h-4 w-4 ${isFavorite ? "fill-red-500 text-red-500" : ""}`} />
                </Button>
              </div>
            </Card>

            {/* Property Info */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-2xl mb-2">{propertyData.title}</CardTitle>
                    <div className="flex items-center text-gray-600 mb-4">
                      <MapPin className="h-4 w-4 mr-2" />
                      {propertyData.fullAddress}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-blue-600">${propertyData.price.toLocaleString()}</div>
                    <div className="text-gray-600">por mes</div>
                  </div>
                </div>

                <div className="flex items-center space-x-6 text-gray-600">
                  <div className="flex items-center">
                    <Bed className="h-5 w-5 mr-2" />
                    <span>{propertyData.bedrooms} habitaciones</span>
                  </div>
                  <div className="flex items-center">
                    <Bath className="h-5 w-5 mr-2" />
                    <span>{propertyData.bathrooms} baños</span>
                  </div>
                  <div className="flex items-center">
                    <Square className="h-5 w-5 mr-2" />
                    <span>{propertyData.area}m²</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h3 className="text-lg font-semibold mb-3">Descripción</h3>
                    <p className="text-gray-600 leading-relaxed">{propertyData.description}</p>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Comodidades</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {propertyData.amenities.map((amenity, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <amenity.icon className="h-5 w-5 text-blue-600" />
                          <span className="text-gray-600">{amenity.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Características</h3>
                    <div className="grid grid-cols-2 gap-2">
                      {propertyData.features.map((feature, index) => (
                        <div key={index} className="flex items-center space-x-2">
                          <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
                          <span className="text-gray-600">{feature}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <Separator />

                  <div>
                    <h3 className="text-lg font-semibold mb-3">Lugares Cercanos</h3>
                    <div className="space-y-3">
                      {propertyData.nearbyPlaces.map((place, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div>
                            <span className="font-medium">{place.name}</span>
                            <span className="text-sm text-gray-600 ml-2">({place.type})</span>
                          </div>
                          <Badge variant="secondary">{place.distance}</Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Star className="h-5 w-5 text-yellow-400 mr-2" />
                  Reseñas ({propertyData.reviews})
                </CardTitle>
                <div className="flex items-center space-x-2">
                  <span className="text-2xl font-bold">{propertyData.rating}</span>
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <Star
                        key={star}
                        className={`h-4 w-4 ${
                          star <= propertyData.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {reviews.map((review) => (
                    <div key={review.id} className="border-b pb-4 last:border-b-0">
                      <div className="flex items-start space-x-3">
                        <Avatar>
                          <AvatarImage src={review.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{review.user.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium">{review.user}</span>
                            <span className="text-sm text-gray-600">{review.date}</span>
                          </div>
                          <div className="flex mb-2">
                            {[1, 2, 3, 4, 5].map((star) => (
                              <Star
                                key={star}
                                className={`h-4 w-4 ${
                                  star <= review.rating ? "text-yellow-400 fill-current" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                          <p className="text-gray-600">{review.comment}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Availability */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Disponibilidad</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Estado:</span>
                    <Badge className="bg-green-100 text-green-800">Disponible</Badge>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-600">Disponible desde:</span>
                    <span className="font-medium">{propertyData.availableFrom}</span>
                  </div>
                  <Separator />
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Arriendo mensual:</span>
                      <span className="font-medium">${propertyData.price.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Depósito:</span>
                      <span className="font-medium">${propertyData.deposit.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Administración:</span>
                      <span className="font-medium">${propertyData.adminFee.toLocaleString()}</span>
                    </div>
                  </div>
                  <Separator />
                  <div className="space-y-3">
                    <Button className="w-full" size="lg">
                      <Calendar className="h-4 w-4 mr-2" />
                      Solicitar Visita
                    </Button>
                    <Button variant="outline" className="w-full">
                      Aplicar Ahora
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Owner Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Propietario</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-3">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={propertyData.owner.avatar || "/placeholder.svg"} />
                      <AvatarFallback>{propertyData.owner.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{propertyData.owner.name}</span>
                        {propertyData.owner.verified && (
                          <Badge variant="secondary" className="text-xs">
                            <Shield className="h-3 w-3 mr-1" />
                            Verificado
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Star className="h-4 w-4 text-yellow-400 mr-1" />
                        {propertyData.owner.rating} • {propertyData.owner.properties} propiedades
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Tiempo de respuesta:</span>
                      <div className="font-medium">{propertyData.owner.responseTime}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Miembro desde:</span>
                      <div className="font-medium">{propertyData.owner.joinDate}</div>
                    </div>
                  </div>

                  <Separator />

                  <div className="space-y-3">
                    <div className="space-y-2">
                      <Textarea
                        placeholder="Escribe tu mensaje..."
                        value={message}
                        onChange={(e) => setMessage(e.target.value)}
                        rows={3}
                      />
                      <Button onClick={handleSendMessage} className="w-full">
                        <Send className="h-4 w-4 mr-2" />
                        Enviar Mensaje
                      </Button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <Button variant="outline" size="sm">
                        <Phone className="h-4 w-4 mr-2" />
                        Llamar
                      </Button>
                      <Button variant="outline" size="sm">
                        <Mail className="h-4 w-4 mr-2" />
                        Email
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Similar Properties */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Propiedades Similares</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[1, 2].map((i) => (
                    <div key={i} className="flex space-x-3">
                      <Image
                        src="/placeholder.svg?height=80&width=80"
                        alt="Propiedad similar"
                        width={80}
                        height={80}
                        className="rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-sm line-clamp-2">Apartamento en El Poblado</h4>
                        <p className="text-sm text-gray-600">2 hab • 2 baños</p>
                        <p className="text-sm font-bold text-blue-600">$1,100,000/mes</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
