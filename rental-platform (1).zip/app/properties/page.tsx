"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Search, MapPin, Bed, Bath, Square, Heart, Star, Home, SlidersHorizontal } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

const mockProperties = [
  {
    id: 1,
    title: "Apartamento Moderno en Chapinero",
    description: "Hermoso apartamento con vista panorámica de la ciudad",
    price: 1200000,
    location: "Chapinero, Bogotá",
    bedrooms: 2,
    bathrooms: 2,
    area: 80,
    type: "Apartamento",
    images: ["/placeholder.svg?height=300&width=400"],
    rating: 4.8,
    reviews: 12,
    owner: "María González",
    verified: true,
    featured: true,
  },
  {
    id: 2,
    title: "Casa Familiar en El Poblado",
    description: "Espaciosa casa con jardín privado y garaje",
    price: 1800000,
    location: "El Poblado, Medellín",
    bedrooms: 3,
    bathrooms: 3,
    area: 120,
    type: "Casa",
    images: ["/placeholder.svg?height=300&width=400"],
    rating: 4.9,
    reviews: 8,
    owner: "Carlos Rodríguez",
    verified: true,
    featured: false,
  },
  {
    id: 3,
    title: "Estudio en Zona Rosa",
    description: "Perfecto para profesionales jóvenes",
    price: 800000,
    location: "Zona Rosa, Bogotá",
    bedrooms: 1,
    bathrooms: 1,
    area: 45,
    type: "Estudio",
    images: ["/placeholder.svg?height=300&width=400"],
    rating: 4.6,
    reviews: 15,
    owner: "Ana Martínez",
    verified: true,
    featured: false,
  },
  {
    id: 4,
    title: "Apartamento con Balcón en Laureles",
    description: "Excelente ubicación cerca del metro",
    price: 950000,
    location: "Laureles, Medellín",
    bedrooms: 2,
    bathrooms: 1,
    area: 65,
    type: "Apartamento",
    images: ["/placeholder.svg?height=300&width=400"],
    rating: 4.7,
    reviews: 6,
    owner: "Luis Herrera",
    verified: false,
    featured: false,
  },
]

export default function PropertiesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [priceRange, setPriceRange] = useState([0, 3000000])
  const [propertyType, setPropertyType] = useState("")
  const [bedrooms, setBedrooms] = useState("")
  const [showFilters, setShowFilters] = useState(false)

  const filteredProperties = mockProperties.filter((property) => {
    const matchesSearch =
      property.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      property.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesPrice = property.price >= priceRange[0] && property.price <= priceRange[1]
    const matchesType = !propertyType || property.type === propertyType
    const matchesBedrooms = !bedrooms || property.bedrooms.toString() === bedrooms

    return matchesSearch && matchesPrice && matchesType && matchesBedrooms
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost">Dashboard</Button>
            </Link>
            <Link href="/auth/login">
              <Button>Iniciar Sesión</Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col lg:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Buscar por ubicación, tipo de propiedad..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="lg:w-auto">
              <SlidersHorizontal className="h-4 w-4 mr-2" />
              Filtros
            </Button>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="text-lg">Filtros de Búsqueda</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-6">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Tipo de Propiedad</label>
                    <Select value={propertyType} onValueChange={setPropertyType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Todos" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="Apartamento">Apartamento</SelectItem>
                        <SelectItem value="Casa">Casa</SelectItem>
                        <SelectItem value="Estudio">Estudio</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Habitaciones</label>
                    <Select value={bedrooms} onValueChange={setBedrooms}>
                      <SelectTrigger>
                        <SelectValue placeholder="Cualquiera" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="any">Cualquiera</SelectItem>
                        <SelectItem value="1">1</SelectItem>
                        <SelectItem value="2">2</SelectItem>
                        <SelectItem value="3">3+</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="md:col-span-2">
                    <label className="text-sm font-medium mb-2 block">
                      Rango de Precio: ${priceRange[0].toLocaleString()} - ${priceRange[1].toLocaleString()}
                    </label>
                    <Slider
                      value={priceRange}
                      onValueChange={setPriceRange}
                      max={3000000}
                      min={0}
                      step={100000}
                      className="mt-2"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Results Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Propiedades Disponibles</h1>
            <p className="text-gray-600">{filteredProperties.length} propiedades encontradas</p>
          </div>

          <Select defaultValue="newest">
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Más Recientes</SelectItem>
              <SelectItem value="price-low">Precio: Menor a Mayor</SelectItem>
              <SelectItem value="price-high">Precio: Mayor a Menor</SelectItem>
              <SelectItem value="rating">Mejor Calificados</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Properties Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProperties.map((property) => (
            <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <Image
                  src={property.images[0] || "/placeholder.svg"}
                  alt={property.title}
                  width={400}
                  height={300}
                  className="w-full h-48 object-cover"
                />
                {property.featured && <Badge className="absolute top-2 left-2 bg-blue-600">Destacado</Badge>}
                <Button variant="ghost" size="sm" className="absolute top-2 right-2 bg-white/80 hover:bg-white">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>

              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg line-clamp-1">{property.title}</CardTitle>
                    <div className="flex items-center text-sm text-gray-600 mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      {property.location}
                    </div>
                  </div>
                  {property.verified && (
                    <Badge variant="secondary" className="text-xs">
                      Verificado
                    </Badge>
                  )}
                </div>
              </CardHeader>

              <CardContent>
                <CardDescription className="line-clamp-2 mb-4">{property.description}</CardDescription>

                <div className="flex items-center justify-between text-sm text-gray-600 mb-4">
                  <div className="flex items-center space-x-4">
                    <div className="flex items-center">
                      <Bed className="h-4 w-4 mr-1" />
                      {property.bedrooms}
                    </div>
                    <div className="flex items-center">
                      <Bath className="h-4 w-4 mr-1" />
                      {property.bathrooms}
                    </div>
                    <div className="flex items-center">
                      <Square className="h-4 w-4 mr-1" />
                      {property.area}m²
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-2xl font-bold text-blue-600">${property.price.toLocaleString()}</div>
                    <div className="text-sm text-gray-600">por mes</div>
                  </div>

                  <div className="flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{property.rating}</span>
                    <span className="text-sm text-gray-600 ml-1">({property.reviews})</span>
                  </div>
                </div>

                <div className="mt-4 pt-4 border-t">
                  <div className="flex items-center justify-between">
                    <div className="text-sm text-gray-600">Por: {property.owner}</div>
                    <Link href={`/properties/${property.id}`}>
                      <Button size="sm">Ver Detalles</Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Load More */}
        {filteredProperties.length > 0 && (
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              Cargar Más Propiedades
            </Button>
          </div>
        )}

        {/* No Results */}
        {filteredProperties.length === 0 && (
          <div className="text-center py-12">
            <div className="text-gray-400 mb-4">
              <Search className="h-16 w-16 mx-auto" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No se encontraron propiedades</h3>
            <p className="text-gray-600 mb-4">Intenta ajustar tus filtros de búsqueda</p>
            <Button
              onClick={() => {
                setSearchTerm("")
                setPriceRange([0, 3000000])
                setPropertyType("")
                setBedrooms("")
              }}
            >
              Limpiar Filtros
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
