"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { Brain, MapPin, TrendingUp, Zap, Target, Home, Heart, Clock, Lightbulb, BarChart3, Filter } from "lucide-react"
import Link from "next/link"

const aiRecommendations = [
  {
    id: 1,
    title: "Apartamento Zona Rosa Premium",
    location: "Zona Rosa, Bogotá",
    price: 1100000,
    matchScore: 95,
    reasons: [
      "Coincide con tu presupuesto ideal",
      "Ubicación cerca de tu trabajo",
      "Características similares a tus favoritos",
      "Excelente conectividad de transporte",
    ],
    image: "/placeholder.svg?height=200&width=300",
    aiInsights: "Basado en tu historial, esta propiedad tiene 87% de probabilidad de gustarte",
    trending: true,
    pricePredict: "Precio podría subir 5% en 3 meses",
  },
  {
    id: 2,
    title: "Estudio Moderno Chapinero",
    location: "Chapinero, Bogotá",
    price: 950000,
    matchScore: 88,
    reasons: [
      "Perfecto para profesionales jóvenes",
      "Zona con alta valorización",
      "Amenidades que buscas",
      "Comunidad activa de inquilinos",
    ],
    image: "/placeholder.svg?height=200&width=300",
    aiInsights: "Usuarios con perfil similar califican esta zona con 4.8/5",
    trending: false,
    pricePredict: "Precio estable por 6 meses",
  },
]

const marketInsights = [
  {
    title: "Tendencia de Precios",
    value: "+3.2%",
    description: "Incremento promedio en Chapinero este mes",
    icon: TrendingUp,
    color: "text-green-600",
  },
  {
    title: "Demanda Alta",
    value: "85%",
    description: "Ocupación en tu rango de precio",
    icon: Target,
    color: "text-blue-600",
  },
  {
    title: "Tiempo Promedio",
    value: "12 días",
    description: "Para encontrar inquilino en tu zona",
    icon: Clock,
    color: "text-purple-600",
  },
]

export default function AIRecommendationsPage() {
  const [preferences, setPreferences] = useState({
    budget: [800000, 1500000],
    location: "chapinero",
    propertyType: "apartment",
    bedrooms: 2,
    priorities: ["location", "price", "amenities"],
  })
  const [isLearning, setIsLearning] = useState(true)

  useEffect(() => {
    // Simulate AI learning process
    const timer = setTimeout(() => setIsLearning(false), 2000)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <Badge className="bg-gradient-to-r from-purple-100 to-blue-100 text-purple-800">
            <Brain className="h-4 w-4 mr-1" />
            IA Personalizada
          </Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Recomendaciones Inteligentes</h1>
            <p className="text-gray-600">
              Nuestra IA analiza tus preferencias y comportamiento para encontrar tu hogar perfecto
            </p>
          </div>

          {isLearning && (
            <Card className="mb-8 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
              <CardContent className="py-6">
                <div className="flex items-center space-x-4">
                  <div className="animate-spin">
                    <Brain className="h-8 w-8 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-purple-900">IA Aprendiendo tus Preferencias</h3>
                    <p className="text-purple-700">Analizando tu comportamiento para mejores recomendaciones...</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="grid lg:grid-cols-4 gap-8">
            {/* Main Content */}
            <div className="lg:col-span-3 space-y-8">
              {/* AI Insights Dashboard */}
              <div className="grid md:grid-cols-3 gap-6">
                {marketInsights.map((insight, index) => (
                  <Card key={index}>
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                      <CardTitle className="text-sm font-medium">{insight.title}</CardTitle>
                      <insight.icon className={`h-4 w-4 ${insight.color}`} />
                    </CardHeader>
                    <CardContent>
                      <div className={`text-2xl font-bold ${insight.color}`}>{insight.value}</div>
                      <p className="text-xs text-muted-foreground">{insight.description}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Smart Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Zap className="h-5 w-5 mr-2 text-yellow-500" />
                    Recomendaciones Personalizadas
                  </CardTitle>
                  <CardDescription>Propiedades seleccionadas especialmente para ti por nuestra IA</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {aiRecommendations.map((property) => (
                      <div key={property.id} className="border rounded-lg p-6 hover:shadow-md transition-shadow">
                        <div className="flex items-start space-x-6">
                          <img
                            src={property.image || "/placeholder.svg"}
                            alt={property.title}
                            className="w-48 h-32 object-cover rounded-lg"
                          />

                          <div className="flex-1 space-y-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="text-xl font-semibold">{property.title}</h3>
                                <p className="text-gray-600 flex items-center">
                                  <MapPin className="h-4 w-4 mr-1" />
                                  {property.location}
                                </p>
                              </div>
                              <div className="text-right">
                                <div className="text-2xl font-bold text-blue-600">
                                  ${property.price.toLocaleString()}
                                </div>
                                <div className="text-sm text-gray-600">por mes</div>
                              </div>
                            </div>

                            <div className="flex items-center space-x-4">
                              <div className="flex items-center space-x-2">
                                <div className="w-16 h-2 bg-gray-200 rounded-full overflow-hidden">
                                  <div
                                    className="h-full bg-gradient-to-r from-green-400 to-blue-500 rounded-full"
                                    style={{ width: `${property.matchScore}%` }}
                                  />
                                </div>
                                <span className="text-sm font-medium">{property.matchScore}% match</span>
                              </div>
                              {property.trending && (
                                <Badge className="bg-red-100 text-red-800">
                                  <TrendingUp className="h-3 w-3 mr-1" />
                                  Trending
                                </Badge>
                              )}
                            </div>

                            <div className="bg-blue-50 p-4 rounded-lg">
                              <h4 className="font-medium text-blue-900 mb-2 flex items-center">
                                <Lightbulb className="h-4 w-4 mr-2" />
                                ¿Por qué te recomendamos esta propiedad?
                              </h4>
                              <ul className="text-sm text-blue-800 space-y-1">
                                {property.reasons.map((reason, index) => (
                                  <li key={index} className="flex items-center">
                                    <div className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2" />
                                    {reason}
                                  </li>
                                ))}
                              </ul>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="text-sm text-gray-600">
                                <Brain className="h-4 w-4 inline mr-1" />
                                {property.aiInsights}
                              </div>
                              <div className="flex space-x-2">
                                <Button variant="outline" size="sm">
                                  <Heart className="h-4 w-4 mr-1" />
                                  Guardar
                                </Button>
                                <Button size="sm">Ver Detalles</Button>
                              </div>
                            </div>

                            {property.pricePredict && (
                              <div className="text-xs text-orange-600 bg-orange-50 p-2 rounded">
                                <BarChart3 className="h-3 w-3 inline mr-1" />
                                Predicción: {property.pricePredict}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* AI Chat Assistant */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="h-5 w-5 mr-2" />
                    Asistente IA Inmobiliario
                  </CardTitle>
                  <CardDescription>Pregúntame cualquier cosa sobre propiedades o el mercado</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
                          <Brain className="h-4 w-4 text-white" />
                        </div>
                        <div>
                          <p className="text-sm">
                            ¡Hola! Soy tu asistente IA. Basándome en tu perfil, veo que prefieres zonas céntricas con
                            buena conectividad. ¿Te gustaría que busque propiedades cerca de estaciones de TransMilenio?
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Input placeholder="Pregúntame sobre propiedades, precios, zonas..." className="flex-1" />
                      <Button>Enviar</Button>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button variant="outline" size="sm">
                        ¿Cuál es el mejor momento para arrendar?
                      </Button>
                      <Button variant="outline" size="sm">
                        Analiza esta zona para mí
                      </Button>
                      <Button variant="outline" size="sm">
                        ¿Cómo negociar el precio?
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preference Learning */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Preferencias IA</CardTitle>
                  <CardDescription>La IA aprende de tus interacciones</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Presupuesto Ideal</label>
                    <Slider
                      value={preferences.budget}
                      onValueChange={(value) => setPreferences({ ...preferences, budget: value })}
                      max={3000000}
                      min={500000}
                      step={100000}
                      className="mb-2"
                    />
                    <div className="flex justify-between text-xs text-gray-600">
                      <span>${preferences.budget[0].toLocaleString()}</span>
                      <span>${preferences.budget[1].toLocaleString()}</span>
                    </div>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Zona Preferida</label>
                    <select
                      className="w-full p-2 border rounded-md text-sm"
                      value={preferences.location}
                      onChange={(e) => setPreferences({ ...preferences, location: e.target.value })}
                    >
                      <option value="chapinero">Chapinero</option>
                      <option value="zona-rosa">Zona Rosa</option>
                      <option value="el-poblado">El Poblado</option>
                      <option value="laureles">Laureles</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Prioridades</label>
                    <div className="space-y-2">
                      {["Ubicación", "Precio", "Amenidades", "Transporte"].map((priority) => (
                        <div key={priority} className="flex items-center space-x-2">
                          <input type="checkbox" defaultChecked />
                          <span className="text-sm">{priority}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Learning Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Progreso de Aprendizaje</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Preferencias de Ubicación</span>
                      <span>85%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: "85%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Rango de Precios</span>
                      <span>92%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: "92%" }} />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Amenidades Favoritas</span>
                      <span>78%</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-yellow-600 h-2 rounded-full" style={{ width: "78%" }} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Acciones Inteligentes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <Filter className="h-4 w-4 mr-2" />
                    Búsqueda Inteligente
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <BarChart3 className="h-4 w-4 mr-2" />
                    Análisis de Mercado
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Target className="h-4 w-4 mr-2" />
                    Alertas Personalizadas
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
