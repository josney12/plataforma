"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Building2, Users, Heart, Star, Search, UserPlus, UserCheck, Home, TrendingUp } from "lucide-react"
import Link from "next/link"

interface AgencyProfile {
  id: string
  name: string
  email: string
  phone?: string
  avatar_url?: string
  verified: boolean
  created_at: string
  stats: {
    total_properties: number
    active_properties: number
    followers_count: number
    total_likes: number
    avg_rating: number
    total_reviews: number
  }
  is_following?: boolean
}

export default function AgenciesPage() {
  const [agencies, setAgencies] = useState<AgencyProfile[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
    fetchAgencies()
  }, [])

  const fetchAgencies = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/agencies")
      const result = await response.json()

      if (result.success) {
        setAgencies(result.data)
      }
    } catch (error) {
      console.error("Error fetching agencies:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFollow = async (agencyId: string) => {
    if (!user) return

    try {
      const response = await fetch("/api/social/follow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agencyId }),
      })

      const result = await response.json()
      if (result.success) {
        setAgencies((prev) =>
          prev.map((agency) =>
            agency.id === agencyId
              ? {
                  ...agency,
                  is_following: result.following,
                  stats: {
                    ...agency.stats,
                    followers_count: result.following
                      ? agency.stats.followers_count + 1
                      : agency.stats.followers_count - 1,
                  },
                }
              : agency,
          ),
        )
      }
    } catch (error) {
      console.error("Error following agency:", error)
    }
  }

  const filteredAgencies = agencies.filter((agency) => agency.name.toLowerCase().includes(searchTerm.toLowerCase()))

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando inmobiliarias...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link href="/feed">
              <Button variant="ghost" size="sm">
                <TrendingUp className="h-4 w-4 mr-2" />
                Feed
              </Button>
            </Link>
            <Link href="/properties">
              <Button variant="ghost" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Propiedades
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Inmobiliarias y Propietarios</h1>
          <p className="text-gray-600">Descubre las mejores inmobiliarias y propietarios verificados</p>
        </div>

        {/* Search */}
        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Buscar inmobiliarias..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Stats */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6 text-center">
              <Building2 className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">{agencies.length}</div>
              <div className="text-sm text-gray-600">Inmobiliarias</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Home className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {agencies.reduce((sum, agency) => sum + agency.stats.active_properties, 0)}
              </div>
              <div className="text-sm text-gray-600">Propiedades Activas</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {agencies.reduce((sum, agency) => sum + agency.stats.followers_count, 0)}
              </div>
              <div className="text-sm text-gray-600">Seguidores Totales</div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6 text-center">
              <Heart className="h-8 w-8 text-red-600 mx-auto mb-2" />
              <div className="text-2xl font-bold">
                {agencies.reduce((sum, agency) => sum + agency.stats.total_likes, 0)}
              </div>
              <div className="text-sm text-gray-600">Likes Totales</div>
            </CardContent>
          </Card>
        </div>

        {/* Agencies Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAgencies.map((agency) => (
            <Card key={agency.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <CardHeader className="text-center pb-4">
                <Link href={`/agencies/${agency.id}`}>
                  <Avatar className="w-20 h-20 mx-auto mb-4 cursor-pointer">
                    <AvatarImage src={agency.avatar_url || "/placeholder.svg"} />
                    <AvatarFallback className="text-2xl">{agency.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                </Link>

                <div className="space-y-2">
                  <div className="flex items-center justify-center space-x-2">
                    <Link href={`/agencies/${agency.id}`} className="hover:underline">
                      <CardTitle className="text-lg">{agency.name}</CardTitle>
                    </Link>
                    {agency.verified && (
                      <Badge variant="secondary" className="text-xs">
                        <Star className="h-3 w-3 mr-1" />
                        Verificado
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center justify-center space-x-4 text-sm text-gray-600">
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {agency.stats.followers_count}
                    </div>
                    <div className="flex items-center">
                      <Home className="h-4 w-4 mr-1" />
                      {agency.stats.active_properties}
                    </div>
                    <div className="flex items-center">
                      <Heart className="h-4 w-4 mr-1" />
                      {agency.stats.total_likes}
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="pt-0">
                {/* Stats */}
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-blue-600">{agency.stats.active_properties}</div>
                    <div className="text-xs text-gray-600">Propiedades</div>
                  </div>
                  <div className="text-center p-3 bg-gray-50 rounded-lg">
                    <div className="text-lg font-bold text-green-600">
                      {agency.stats.avg_rating > 0 ? agency.stats.avg_rating.toFixed(1) : "N/A"}
                    </div>
                    <div className="text-xs text-gray-600">Calificación</div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-2">
                  <Link href={`/agencies/${agency.id}`} className="w-full">
                    <Button variant="outline" className="w-full">
                      Ver Perfil
                    </Button>
                  </Link>

                  {user && agency.id !== user.id && (
                    <Button
                      variant={agency.is_following ? "outline" : "default"}
                      className="w-full"
                      onClick={() => handleFollow(agency.id)}
                    >
                      {agency.is_following ? (
                        <>
                          <UserCheck className="h-4 w-4 mr-2" />
                          Siguiendo
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-4 w-4 mr-2" />
                          Seguir
                        </>
                      )}
                    </Button>
                  )}
                </div>

                {/* Member Since */}
                <div className="text-center mt-4 pt-4 border-t">
                  <p className="text-xs text-gray-600">Miembro desde {new Date(agency.created_at).getFullYear()}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* No Results */}
        {filteredAgencies.length === 0 && !loading && (
          <div className="text-center py-12">
            <Building2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-gray-900 mb-2">No se encontraron inmobiliarias</h3>
            <p className="text-gray-600">Intenta con un término de búsqueda diferente</p>
          </div>
        )}
      </div>
    </div>
  )
}
