"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Building2,
  Heart,
  Star,
  MapPin,
  UserPlus,
  UserCheck,
  Home,
  Phone,
  Mail,
  Calendar,
  Award,
  TrendingUp,
  Bed,
  Bath,
  Square,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { useParams } from "next/navigation"

interface AgencyProfile {
  id: string
  name: string
  email: string
  phone?: string
  avatar_url?: string
  verified: boolean
  created_at: string
  stats: {
    total_properties: number
    active_properties: number
    followers_count: number
    total_likes: number
    avg_rating: number
    total_reviews: number
  }
  top_properties: any[]
  is_following?: boolean
}

export default function AgencyProfilePage() {
  const params = useParams()
  const [agency, setAgency] = useState<AgencyProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState<any>(null)

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      setUser(JSON.parse(userData))
    }
    if (params.id) {
      fetchAgencyProfile(params.id as string)
    }
  }, [params.id])

  const fetchAgencyProfile = async (agencyId: string) => {
    try {
      setLoading(true)
      const response = await fetch(`/api/agencies/${agencyId}`)
      const result = await response.json()

      if (result.success) {
        setAgency(result.data)
      }
    } catch (error) {
      console.error("Error fetching agency profile:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleFollow = async () => {
    if (!user || !agency) return

    try {
      const response = await fetch("/api/social/follow", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ agencyId: agency.id }),
      })

      const result = await response.json()
      if (result.success) {
        setAgency((prev) =>
          prev
            ? {
                ...prev,
                is_following: result.following,
                stats: {
                  ...prev.stats,
                  followers_count: result.following ? prev.stats.followers_count + 1 : prev.stats.followers_count - 1,
                },
              }
            : null,
        )
      }
    } catch (error) {
      console.error("Error following agency:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Cargando perfil...</p>
        </div>
      </div>
    )
  }

  if (!agency) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Building2 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Inmobiliaria no encontrada</h3>
          <Link href="/agencies">
            <Button>Volver a Inmobiliarias</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/agencies" className="flex items-center space-x-2">
            <Building2 className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>

          <div className="flex items-center space-x-4">
            <Link href="/feed">
              <Button variant="ghost" size="sm">
                <TrendingUp className="h-4 w-4 mr-2" />
                Feed
              </Button>
            </Link>
            <Link href="/properties">
              <Button variant="ghost" size="sm">
                <Home className="h-4 w-4 mr-2" />
                Propiedades
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Profile Header */}
        <Card className="mb-8">
          <CardContent className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8">
              <Avatar className="w-32 h-32">
                <AvatarImage src={agency.avatar_url || "/placeholder.svg"} />
                <AvatarFallback className="text-4xl">{agency.name.charAt(0)}</AvatarFallback>
              </Avatar>

              <div className="flex-1">
                <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
                  <div>
                    <div className="flex items-center space-x-3 mb-2">
                      <h1 className="text-3xl font-bold">{agency.name}</h1>
                      {agency.verified && (
                        <Badge className="bg-blue-100 text-blue-800">
                          <Star className="h-4 w-4 mr-1" />
                          Verificado
                        </Badge>
                      )}
                    </div>
                    <p className="text-gray-600 mb-4">Miembro desde {new Date(agency.created_at).getFullYear()}</p>
                  </div>

                  {user && agency.id !== user.id && (
                    <Button onClick={handleFollow} variant={agency.is_following ? "outline" : "default"} size="lg">
                      {agency.is_following ? (
                        <>
                          <UserCheck className="h-5 w-5 mr-2" />
                          Siguiendo
                        </>
                      ) : (
                        <>
                          <UserPlus className="h-5 w-5 mr-2" />
                          Seguir
                        </>
                      )}
                    </Button>
                  )}
                </div>

                {/* Stats */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-600">{agency.stats.active_properties}</div>
                    <div className="text-sm text-gray-600">Propiedades</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">{agency.stats.followers_count}</div>
                    <div className="text-sm text-gray-600">Seguidores</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-red-600">{agency.stats.total_likes}</div>
                    <div className="text-sm text-gray-600">Likes</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-yellow-600">
                      {agency.stats.avg_rating > 0 ? agency.stats.avg_rating.toFixed(1) : "N/A"}
                    </div>
                    <div className="text-sm text-gray-600">Calificación</div>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content Tabs */}
        <Tabs defaultValue="properties" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="properties">Propiedades</TabsTrigger>
            <TabsTrigger value="about">Acerca de</TabsTrigger>
            <TabsTrigger value="reviews">Reseñas</TabsTrigger>
          </TabsList>

          <TabsContent value="properties">
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-bold">Propiedades Destacadas</h2>
                <Link href={`/properties?owner=${agency.id}`}>
                  <Button variant="outline">Ver Todas</Button>
                </Link>
              </div>

              {agency.top_properties.length > 0 ? (
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {agency.top_properties.map((property) => (
                    <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="relative">
                        <Image
                          src={property.images?.[0] || "/placeholder.svg"}
                          alt={property.title}
                          width={400}
                          height={250}
                          className="w-full h-48 object-cover"
                        />
                        <div className="absolute top-2 right-2 flex space-x-2">
                          <Badge className="bg-white/90 text-gray-900">
                            <Heart className="h-3 w-3 mr-1" />
                            {property.likes_count || 0}
                          </Badge>
                        </div>
                      </div>

                      <CardContent className="p-4">
                        <h3 className="font-semibold text-lg mb-2 line-clamp-1">{property.title}</h3>
                        <div className="flex items-center text-gray-600 mb-3">
                          <MapPin className="h-4 w-4 mr-1" />
                          {property.city}
                        </div>

                        <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                          <div className="flex items-center space-x-3">
                            {property.bedrooms && (
                              <div className="flex items-center">
                                <Bed className="h-4 w-4 mr-1" />
                                {property.bedrooms}
                              </div>
                            )}
                            {property.bathrooms && (
                              <div className="flex items-center">
                                <Bath className="h-4 w-4 mr-1" />
                                {property.bathrooms}
                              </div>
                            )}
                            {property.area && (
                              <div className="flex items-center">
                                <Square className="h-4 w-4 mr-1" />
                                {property.area}m²
                              </div>
                            )}
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-2xl font-bold text-blue-600">
                            ${property.price?.toLocaleString()}/mes
                          </div>
                          <Link href={`/properties/${property.id}`}>
                            <Button size="sm">Ver Detalles</Button>
                          </Link>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Home className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Sin propiedades disponibles</h3>
                  <p className="text-gray-600">Esta inmobiliaria aún no tiene propiedades publicadas</p>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="about">
            <Card>
              <CardHeader>
                <CardTitle>Información de Contacto</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-gray-400" />
                  <span>{agency.email}</span>
                </div>
                {agency.phone && (
                  <div className="flex items-center space-x-3">
                    <Phone className="h-5 w-5 text-gray-400" />
                    <span>{agency.phone}</span>
                  </div>
                )}
                <div className="flex items-center space-x-3">
                  <Calendar className="h-5 w-5 text-gray-400" />
                  <span>Miembro desde {new Date(agency.created_at).toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Award className="h-5 w-5 text-gray-400" />
                  <span>{agency.verified ? "Cuenta verificada" : "Cuenta no verificada"}</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="reviews">
            <Card>
              <CardHeader>
                <CardTitle>Reseñas y Calificaciones</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <Star className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Próximamente</h3>
                  <p className="text-gray-600">Las reseñas estarán disponibles pronto</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
