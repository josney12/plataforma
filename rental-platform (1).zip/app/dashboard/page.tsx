"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Home,
  Plus,
  MessageSquare,
  Star,
  TrendingUp,
  Users,
  Calendar,
  DollarSign,
  Eye,
  Heart,
  Shield,
} from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface User {
  id: number
  name: string
  email: string
  type: "TENANT" | "OWNER" | "AGENCY"
  verified: boolean
}

export default function DashboardPage() {
  const [user, setUser] = useState<User | null>(null)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (!userData) {
      router.push("/auth/login")
      return
    }
    setUser(JSON.parse(userData))
  }, [router])

  if (!user) {
    return <div>Cargando...</div>
  }

  const getDashboardContent = () => {
    switch (user.type) {
      case "OWNER":
        return <OwnerDashboard user={user} />
      case "AGENCY":
        return <AgencyDashboard user={user} />
      default:
        return <TenantDashboard user={user} />
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/" className="flex items-center space-x-2">
              <Home className="h-6 w-6 text-blue-600" />
              <span className="text-xl font-bold">RentaColombia</span>
            </Link>
            <Badge variant={user.verified ? "default" : "secondary"}>
              {user.verified ? "Verificado" : "Sin verificar"}
            </Badge>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <MessageSquare className="h-4 w-4 mr-2" />
              Mensajes
            </Button>
            <Link href="/profile">
              <Avatar className="cursor-pointer hover:ring-2 hover:ring-blue-500 transition-all">
                <AvatarImage src="/placeholder.svg?height=40&width=40" />
                <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
              </Avatar>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Hola, {user.name}</h1>
          <p className="text-gray-600">
            {user.type === "OWNER" && "Gestiona tus propiedades y encuentra inquilinos ideales"}
            {user.type === "TENANT" && "Encuentra tu hogar perfecto"}
            {user.type === "AGENCY" && "Administra tu cartera de propiedades"}
          </p>
        </div>

        {getDashboardContent()}
      </div>
    </div>
  )
}

function TenantDashboard({ user }: { user: User }) {
  return (
    <div className="space-y-8">
      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <Link href="/properties">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Home className="h-12 w-12 text-blue-600 mx-auto mb-2" />
              <CardTitle>Buscar Propiedades</CardTitle>
              <CardDescription>Encuentra tu hogar ideal</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/favorites">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Heart className="h-12 w-12 text-red-500 mx-auto mb-2" />
              <CardTitle>Mis Favoritos</CardTitle>
              <CardDescription>Propiedades guardadas</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Card>
          <CardHeader>
            <CardTitle>Estado de Verificación</CardTitle>
            <CardDescription>La verificación de tu cuenta te permite acceder a más funcionalidades</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center">
                <Shield className="h-8 w-8 text-blue-600 mr-4" />
                <div>
                  <h4 className="font-medium">Verificación de Identidad</h4>
                  <p className="text-sm text-gray-500">
                    {user?.verified
                      ? "Tu cuenta está verificada"
                      : "Completa el proceso de verificación para acceder a todas las funcionalidades"}
                  </p>
                </div>
              </div>
              <Link href="/verification">
                <Button variant={user?.verified ? "outline" : "default"}>
                  {user?.verified ? "Ver Detalles" : "Verificar Ahora"}
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Actividad Reciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg">
              <Eye className="h-5 w-5 text-blue-600" />
              <div>
                <p className="font-medium">Viste un apartamento en Chapinero</p>
                <p className="text-sm text-gray-600">Hace 2 horas</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
              <Heart className="h-5 w-5 text-red-500" />
              <div>
                <p className="font-medium">Guardaste una casa en Zona Rosa</p>
                <p className="text-sm text-gray-600">Ayer</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Recommended Properties */}
      <Card>
        <CardHeader>
          <CardTitle>Propiedades Recomendadas</CardTitle>
          <CardDescription>Basado en tus búsquedas recientes</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {[1, 2].map((i) => (
              <div key={i} className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                <div className="aspect-video bg-gray-200 rounded-lg mb-3"></div>
                <h3 className="font-semibold">Apartamento en El Poblado</h3>
                <p className="text-gray-600 text-sm">2 hab • 2 baños • 80m²</p>
                <p className="text-lg font-bold text-blue-600 mt-2">$1,200,000/mes</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function OwnerDashboard({ user }: { user: User }) {
  return (
    <div className="space-y-8">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Propiedades Activas</CardTitle>
            <Home className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">+1 desde el mes pasado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Ingresos Mensuales</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$3,600,000</div>
            <p className="text-xs text-muted-foreground">+12% desde el mes pasado</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Visitas</CardTitle>
            <Eye className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">127</div>
            <p className="text-xs text-muted-foreground">Esta semana</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Calificación</CardTitle>
            <Star className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">4.8</div>
            <p className="text-xs text-muted-foreground">Promedio de reseñas</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-3 gap-6">
        <Link href="/properties/new">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Plus className="h-12 w-12 text-blue-600 mx-auto mb-2" />
              <CardTitle>Publicar Propiedad</CardTitle>
              <CardDescription>Agrega una nueva propiedad</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/properties/manage">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Home className="h-12 w-12 text-green-600 mx-auto mb-2" />
              <CardTitle>Gestionar Propiedades</CardTitle>
              <CardDescription>Administra tus publicaciones</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/analytics">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <TrendingUp className="h-12 w-12 text-purple-600 mx-auto mb-2" />
              <CardTitle>Análisis</CardTitle>
              <CardDescription>Estadísticas detalladas</CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>

      {/* My Properties */}
      <Card>
        <CardHeader>
          <CardTitle>Mis Propiedades</CardTitle>
          <CardDescription>Gestiona y monitorea tus publicaciones</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[
              { name: "Apartamento Chapinero", status: "Arrendado", price: "$1,200,000", views: 45 },
              { name: "Casa Zona Rosa", status: "Disponible", price: "$1,800,000", views: 78 },
              { name: "Estudio El Poblado", status: "Disponible", price: "$800,000", views: 23 },
            ].map((property, i) => (
              <div key={i} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gray-200 rounded-lg"></div>
                  <div>
                    <h3 className="font-semibold">{property.name}</h3>
                    <p className="text-sm text-gray-600">{property.price}/mes</p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={property.status === "Arrendado" ? "default" : "secondary"}>{property.status}</Badge>
                  <p className="text-sm text-gray-600 mt-1">{property.views} visitas</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

function AgencyDashboard({ user }: { user: User }) {
  return (
    <div className="space-y-8">
      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Propiedades Gestionadas</CardTitle>
            <Home className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">47</div>
            <p className="text-xs text-muted-foreground">+5 este mes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Clientes Activos</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">23</div>
            <p className="text-xs text-muted-foreground">Propietarios</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Comisiones</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2,400,000</div>
            <p className="text-xs text-muted-foreground">Este mes</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tasa de Ocupación</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87%</div>
            <p className="text-xs text-muted-foreground">+3% este mes</p>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-4 gap-6">
        <Link href="/properties/new">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Plus className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <CardTitle className="text-sm">Nueva Propiedad</CardTitle>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/clients">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Users className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <CardTitle className="text-sm">Gestionar Clientes</CardTitle>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/contracts">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <CardTitle className="text-sm">Contratos</CardTitle>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/reports">
          <Card className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader className="text-center">
              <TrendingUp className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <CardTitle className="text-sm">Reportes</CardTitle>
            </CardHeader>
          </Card>
        </Link>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Actividad Reciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center space-x-4 p-4 bg-green-50 rounded-lg">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <div>
                <p className="font-medium">Nuevo contrato firmado - Apartamento Zona Rosa</p>
                <p className="text-sm text-gray-600">Hace 1 hora</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 p-4 bg-blue-50 rounded-lg">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <div>
                <p className="font-medium">Nueva propiedad agregada por Cliente #15</p>
                <p className="text-sm text-gray-600">Hace 3 horas</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
