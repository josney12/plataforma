"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Eye,
  DollarSign,
  Calendar,
  Home,
  Users,
  MapPin,
  Target,
  Download,
  RefreshCw,
} from "lucide-react"
import Link from "next/link"

const analyticsData = {
  overview: {
    totalViews: 1247,
    totalInquiries: 89,
    averageRent: 1350000,
    occupancyRate: 87,
    trends: {
      views: 12,
      inquiries: -3,
      rent: 5,
      occupancy: 2,
    },
  },
  properties: [
    {
      id: 1,
      name: "Apartamento Chapinero",
      views: 245,
      inquiries: 23,
      applications: 8,
      currentRent: 1200000,
      suggestedRent: 1280000,
      daysOnMarket: 15,
      status: "rented",
    },
    {
      id: 2,
      name: "Casa El Poblado",
      views: 189,
      inquiries: 31,
      applications: 12,
      currentRent: 1800000,
      suggestedRent: 1750000,
      daysOnMarket: 8,
      status: "available",
    },
  ],
  marketData: {
    averagePrices: [
      { zone: "Chapinero", price: 1250000, change: 3.2 },
      { zone: "Zona Rosa", price: 1180000, change: 2.8 },
      { zone: "El Poblado", price: 1650000, change: 4.1 },
      { zone: "Laureles", price: 1420000, change: 1.9 },
    ],
    demandTrends: [
      { month: "Ene", demand: 85 },
      { month: "Feb", demand: 92 },
      { month: "Mar", demand: 88 },
      { month: "Abr", demand: 95 },
    ],
  },
}

export default function AnalyticsPage() {
  const [timeRange, setTimeRange] = useState("30d")
  const [selectedProperty, setSelectedProperty] = useState("all")

  const getTrendIcon = (trend: number) => {
    if (trend > 0) return <TrendingUp className="h-4 w-4 text-green-600" />
    if (trend < 0) return <TrendingDown className="h-4 w-4 text-red-600" />
    return <div className="h-4 w-4" />
  }

  const getTrendColor = (trend: number) => {
    if (trend > 0) return "text-green-600"
    if (trend < 0) return "text-red-600"
    return "text-gray-600"
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/dashboard" className="flex items-center space-x-2">
            <Home className="h-6 w-6 text-blue-600" />
            <span className="text-xl font-bold">RentaColombia</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Exportar
            </Button>
            <Badge className="bg-purple-100 text-purple-800">
              <BarChart3 className="h-4 w-4 mr-1" />
              Analytics Pro
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
                <p className="text-gray-600">Análisis detallado del rendimiento de tus propiedades y el mercado</p>
              </div>
              <div className="flex items-center space-x-4">
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="7d">7 días</SelectItem>
                    <SelectItem value="30d">30 días</SelectItem>
                    <SelectItem value="90d">90 días</SelectItem>
                    <SelectItem value="1y">1 año</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Actualizar
                </Button>
              </div>
            </div>
          </div>

          {/* Overview Cards */}
          <div className="grid md:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Visualizaciones</CardTitle>
                <Eye className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.overview.totalViews.toLocaleString()}</div>
                <div className={`text-xs flex items-center ${getTrendColor(analyticsData.overview.trends.views)}`}>
                  {getTrendIcon(analyticsData.overview.trends.views)}
                  <span className="ml-1">+{analyticsData.overview.trends.views}% vs mes anterior</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consultas</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.overview.totalInquiries}</div>
                <div className={`text-xs flex items-center ${getTrendColor(analyticsData.overview.trends.inquiries)}`}>
                  {getTrendIcon(analyticsData.overview.trends.inquiries)}
                  <span className="ml-1">{analyticsData.overview.trends.inquiries}% vs mes anterior</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Renta Promedio</CardTitle>
                <DollarSign className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${analyticsData.overview.averageRent.toLocaleString()}</div>
                <div className={`text-xs flex items-center ${getTrendColor(analyticsData.overview.trends.rent)}`}>
                  {getTrendIcon(analyticsData.overview.trends.rent)}
                  <span className="ml-1">+{analyticsData.overview.trends.rent}% vs mes anterior</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Tasa de Ocupación</CardTitle>
                <Target className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{analyticsData.overview.occupancyRate}%</div>
                <div className={`text-xs flex items-center ${getTrendColor(analyticsData.overview.trends.occupancy)}`}>
                  {getTrendIcon(analyticsData.overview.trends.occupancy)}
                  <span className="ml-1">+{analyticsData.overview.trends.occupancy}% vs mes anterior</span>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Charts */}
            <div className="lg:col-span-2 space-y-8">
              {/* Performance Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Rendimiento de Propiedades</CardTitle>
                  <CardDescription>Visualizaciones y consultas por propiedad</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-80 flex items-center justify-center bg-gray-50 rounded-lg">
                    <div className="text-center">
                      <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">Gráfico de rendimiento</p>
                      <p className="text-sm text-gray-500">Visualizaciones vs Consultas por propiedad</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Market Trends */}
              <Card>
                <CardHeader>
                  <CardTitle>Tendencias del Mercado</CardTitle>
                  <CardDescription>Precios promedio por zona</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analyticsData.marketData.averagePrices.map((zone, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <MapPin className="h-5 w-5 text-blue-600" />
                          <span className="font-medium">{zone.zone}</span>
                        </div>
                        <div className="text-right">
                          <div className="font-bold">${zone.price.toLocaleString()}</div>
                          <div className={`text-sm flex items-center ${getTrendColor(zone.change)}`}>
                            {getTrendIcon(zone.change)}
                            <span className="ml-1">+{zone.change}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Property Performance Table */}
              <Card>
                <CardHeader>
                  <CardTitle>Rendimiento por Propiedad</CardTitle>
                  <CardDescription>Métricas detalladas de cada propiedad</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left py-2">Propiedad</th>
                          <th className="text-right py-2">Vistas</th>
                          <th className="text-right py-2">Consultas</th>
                          <th className="text-right py-2">Aplicaciones</th>
                          <th className="text-right py-2">Días en Mercado</th>
                          <th className="text-center py-2">Estado</th>
                        </tr>
                      </thead>
                      <tbody>
                        {analyticsData.properties.map((property) => (
                          <tr key={property.id} className="border-b">
                            <td className="py-3">
                              <div className="font-medium">{property.name}</div>
                              <div className="text-sm text-gray-600">${property.currentRent.toLocaleString()}/mes</div>
                            </td>
                            <td className="text-right py-3">{property.views}</td>
                            <td className="text-right py-3">{property.inquiries}</td>
                            <td className="text-right py-3">{property.applications}</td>
                            <td className="text-right py-3">{property.daysOnMarket}</td>
                            <td className="text-center py-3">
                              <Badge
                                className={
                                  property.status === "rented"
                                    ? "bg-green-100 text-green-800"
                                    : "bg-blue-100 text-blue-800"
                                }
                              >
                                {property.status === "rented" ? "Arrendado" : "Disponible"}
                              </Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* AI Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Insights de IA</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-1">Optimización de Precio</h4>
                    <p className="text-sm text-blue-800">
                      Tu apartamento en Chapinero podría generar 6% más de ingresos con un ajuste de precio.
                    </p>
                  </div>

                  <div className="p-3 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-900 mb-1">Mejor Momento</h4>
                    <p className="text-sm text-green-800">
                      Marzo es el mejor mes para publicar propiedades en tu zona.
                    </p>
                  </div>

                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <h4 className="font-medium text-yellow-900 mb-1">Competencia</h4>
                    <p className="text-sm text-yellow-800">
                      Hay 15% menos propiedades similares disponibles esta semana.
                    </p>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Acciones Recomendadas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Optimizar Precios
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Eye className="h-4 w-4 mr-2" />
                    Mejorar Visibilidad
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Target className="h-4 w-4 mr-2" />
                    Análisis de Competencia
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="h-4 w-4 mr-2" />
                    Programar Reporte
                  </Button>
                </CardContent>
              </Card>

              {/* Market Alerts */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Alertas de Mercado</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="p-3 border-l-4 border-blue-500 bg-blue-50">
                    <p className="text-sm font-medium text-blue-900">Nueva Regulación</p>
                    <p className="text-xs text-blue-800">Cambios en ley de arrendamiento</p>
                  </div>

                  <div className="p-3 border-l-4 border-green-500 bg-green-50">
                    <p className="text-sm font-medium text-green-900">Oportunidad</p>
                    <p className="text-xs text-green-800">Demanda alta en tu zona</p>
                  </div>

                  <div className="p-3 border-l-4 border-yellow-500 bg-yellow-50">
                    <p className="text-sm font-medium text-yellow-900">Tendencia</p>
                    <p className="text-xs text-yellow-800">Precios al alza en Chapinero</p>
                  </div>
                </CardContent>
              </Card>

              {/* Performance Score */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Puntuación de Rendimiento</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center">
                    <div className="text-4xl font-bold text-blue-600 mb-2">8.7</div>
                    <div className="text-sm text-gray-600 mb-4">de 10</div>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Visibilidad:</span>
                        <span className="font-medium">9.2</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Precio:</span>
                        <span className="font-medium">8.5</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Respuesta:</span>
                        <span className="font-medium">8.4</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
