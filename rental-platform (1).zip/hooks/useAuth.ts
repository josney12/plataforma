"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"

interface User {
  id: number
  name: string
  email: string
  type: "TENANT" | "OWNER" | "AGENCY"
  verified: boolean
  phone?: string
  address?: string
  bio?: string
  occupation?: string
  avatar_url?: string
  preferences?: {
    notifications: boolean
    newsletter: boolean
    marketing: boolean
  }
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const userData = localStorage.getItem("user")
    if (userData) {
      try {
        setUser(JSON.parse(userData))
      } catch (error) {
        console.error("Error parsing user data:", error)
        localStorage.removeItem("user")
      }
    }
    setLoading(false)
  }, [])

  const signOut = () => {
    localStorage.removeItem("user")
    setUser(null)
    router.push("/auth/login")
  }

  return { user, loading, signOut }
}
