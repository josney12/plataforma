"use client"

import { useState, useEffect } from "react"
import type { Property } from "@/lib/supabase"

interface UsePropertiesOptions {
  city?: string
  minPrice?: number
  maxPrice?: number
  propertyType?: string
  bedrooms?: number
}

export function useProperties(options: UsePropertiesOptions = {}) {
  const [properties, setProperties] = useState<Property[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchProperties()
  }, [options.city, options.minPrice, options.maxPrice, options.propertyType, options.bedrooms])

  const fetchProperties = async () => {
    try {
      setLoading(true)
      setError(null)

      const params = new URLSearchParams()
      if (options.city) params.append("city", options.city)
      if (options.minPrice) params.append("minPrice", options.minPrice.toString())
      if (options.maxPrice) params.append("maxPrice", options.maxPrice.toString())
      if (options.propertyType) params.append("propertyType", options.propertyType)
      if (options.bedrooms) params.append("bedrooms", options.bedrooms.toString())

      const response = await fetch(`/api/properties?${params}`)
      const result = await response.json()

      if (!result.success) {
        throw new Error(result.error)
      }

      setProperties(result.data)
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  return {
    properties,
    loading,
    error,
    refetch: fetchProperties,
  }
}
